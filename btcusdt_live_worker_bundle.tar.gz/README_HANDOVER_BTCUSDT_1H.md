# BTCUSDT 1H 高槓桿 PA 策略交接說明

**作者**：Manus AI  
**日期**：2026-04-14  
**對應版本**：`crypto-dashboard-v5.9`

## 一、專案定位

本專案對應 `BTCUSDT 1H` 高槓桿 PA（Price Action）策略的 Phase 5 終極版交接狀態。根據既有交接文件，當前版本的重點不是再做 1H 參數微調，而是確保新環境能穩定重建、正確重跑基線，並清楚標示下一步真正值得投入的底層重構方向。

## 二、終極版核心參數

| 類別 | 參數 |
| --- | --- |
| 基礎風控 | `SL 1.95` / `TP 0.21` |
| 軟評分機制 | `bonus 0.5` / `minscore 7.5` / `touch 0.04` / `same_bar` |
| 雙框架共振 | `pa_dual_tf_resonance: true` |
| 共振窗口 | `pa_resonance_bias_window_bars: 2` |
| 動量要求 | `pa_resonance_require_momentum: false` |

## 三、新環境重建方式

建議在專案根目錄直接使用本地依賴，不再依賴系統全域安裝。

| 步驟 | 指令 |
| --- | --- |
| 安裝依賴 | `pnpm install` |
| 執行基線 | `pnpm baseline:1h BTCUSDT` |
| 搜尋雙框架共振 | `pnpm search:dual-tf BTCUSDT` |
| 執行共振強化搜尋 | `pnpm search:resonance-enhanced BTCUSDT` |

## 四、目前已確認的專案狀態

目前專案已具備雙框架共振相關參數與搜尋腳本，包含 `pa_dual_tf_resonance`、`pa_resonance_bias_window_bars` 與 `pa_resonance_require_momentum`。此外，`tools/analyze_new_baseline_leverage_1h.ts` 已存在，因此新環境缺少的關鍵僅在於執行器與交接腳本入口，而非核心研究程式遺失。

## 五、已確認的核心限制

根據程式檢查結果，共振邏輯雖已可在 15m 資料上尋找獨立 PA resonance，並在特定情況下覆寫 `custom_sl` / `custom_tp`，但真正出場模擬仍由 `findExitWithTrailing(primaryCandles, ...)` 在 1H 主 K 線上執行。這代表 15m 共振進場與 15m 獨立止損/止盈目前仍未完成真正的逐根 15m 模擬。

> 換言之，當前版本已完成「1H 偏見 + 15m 共振過濾」，但尚未完成「15m 進場後以 15m 路徑模擬出場」這個底層重構。

## 六、下一步真正值得做的工作

如果要超越目前結果，建議不要再把時間投入在 1H 參數微調，而應直接重構 `server/backtest.ts` 的出場模擬邏輯。較合理的方向，是在 15m resonance 成立時，同步記錄實際 15m 進場時間與所用 15m K 線索引，並讓後續的止損、止盈與 trailing stop 都改用 15m K 線逐根模擬，再將最終結果映射回統計層。

## 七、交付備註

本次整理已將 `tsx` 納入專案本地開發依賴，並把基線與研究腳本整理到 `package.json` 中，降低新環境接手時的重建成本。
