// Stub cache module for standalone tool execution
export const serverCache = {
  get: <T>(_key: string): T | undefined => undefined,
  set: (_key: string, _value: unknown, _ttl?: number): void => {},
  delete: (_key: string): void => {},
  clear: (): void => {},
};
export const tweetSentimentKey = (sym: string): string => `tweet_sentiment_${sym}`;
