/**
 * search_pattern_type_bonus_1h.ts
 * 延續型/特定 pattern 回踩加分差異化實驗腳本
 *
 * 核心假設：不同的 PA 進場類型（PA_PATTERN vs PA_2ND_LEG_TRAP）
 * 對回踩確認的「依賴程度」不同。對不同類型設定差異化的加分，
 * 可能比統一加分更精確地提升勝率。
 *
 * 基線：新主版本軟評分（bonus0.5 / minscore7.5 / touch0.04 / same_bar）
 *   - 胜率 81.1%, PF 1.27, 年交易 185, 50x P75 保證金損耗 80.53%
 *
 * 守門條件：
 *   - 核心頻率：年交易數 ≥ 183 且 PF > 1
 *   - 50x P75 保證金損耗 ≤ 82%
 *   - 胜率 > 81.1%（超越新主版本基線）
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// 新主版本基線
const NEW_BASELINE = { winRate: 81.1, pf: 1.27, trades: 185, p75Margin50x: 80.53 };

// 守門條件
const GUARD_MIN_TRADES = 183;
const GUARD_MIN_PF = 1.0;
const GUARD_MAX_P75_MARGIN_50X = 82.0;
const GUARD_MIN_WINRATE = NEW_BASELINE.winRate;

// 主版本 SL/TP 參數（必須與新主版本一致）
const BASE_SL = 1.95;
const BASE_TP = 0.21;

interface Variant {
  label: string;
  pa_pattern_type_soft_bonus: boolean;
  pa_pattern_retest_extra_bonus: number;
  pa_trap_retest_extra_bonus: number;
  pa_retest_soft_min_score: number;
}

const variants: Variant[] = [];

// 對照組：純新主版本（無差異化加分）
variants.push({
  label: "new_baseline_no_type_bonus",
  pa_pattern_type_soft_bonus: false,
  pa_pattern_retest_extra_bonus: 0,
  pa_trap_retest_extra_bonus: 0,
  pa_retest_soft_min_score: 7.5,
});

// 差異化加分實驗：PA_PATTERN 額外加分 x 不同最低分門檻
for (const patternBonus of [0.3, 0.5, 0.8, 1.0]) {
  for (const trapBonus of [0, 0.3, 0.5]) {
    for (const minScore of [7.5, 8.0, 8.5]) {
      variants.push({
        label: `type_bonus_pat${patternBonus}_trap${trapBonus}_min${minScore}`,
        pa_pattern_type_soft_bonus: true,
        pa_pattern_retest_extra_bonus: patternBonus,
        pa_trap_retest_extra_bonus: trapBonus,
        pa_retest_soft_min_score: minScore,
      });
    }
  }
}

// 僅對 PA_PATTERN 加分（不對 Trap 加分）
for (const patternBonus of [0.5, 1.0, 1.5]) {
  for (const minScore of [7.5, 8.0]) {
    variants.push({
      label: `type_bonus_patonly${patternBonus}_min${minScore}`,
      pa_pattern_type_soft_bonus: true,
      pa_pattern_retest_extra_bonus: patternBonus,
      pa_trap_retest_extra_bonus: 0,
      pa_retest_soft_min_score: minScore,
    });
  }
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function isoTime(ts: number) {
  return new Date(ts * 1000).toISOString().slice(0, 10);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

async function main() {
  console.log(`[run] pattern type bonus search 1h ${SYMBOL}`);

  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS + 30);

  console.log(`[range] 1h: ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[variants] ${variants.length} 個搜索變體`);

  const results: {
    label: string;
    pattern_bonus: number;
    trap_bonus: number;
    min_score: number;
    trades: number;
    winRate: number;
    pf: number;
    p75Stop: number;
    p75Margin50x: number;
    deltaWinRate: number;
    deltaTrades: number;
    coreOk: boolean;
    guardOk: boolean;
  }[] = [];

  const annualFactor = candles1h.length / (24 * YEAR_DAYS);

  for (const v of variants) {
    const res = runBacktest({
      candles: candles1h as any,
      strategy: "pa" as BacktestStrategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: BASE_SL,
      atr_tp_mult: BASE_TP,
      mtf_candles: candles1d as any,
      pa_allow_pattern: true,
      pa_allow_trap: true,
      pa_allow_true_breakout: false,
      pa_retest_soft_score: true,
      pa_retest_soft_bonus: 0.5,
      pa_retest_soft_min_score: v.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: 0.04,
      pa_retest_mode: "same_bar",
      pa_pattern_type_soft_bonus: v.pa_pattern_type_soft_bonus,
      pa_pattern_retest_extra_bonus: v.pa_pattern_retest_extra_bonus,
      pa_trap_retest_extra_bonus: v.pa_trap_retest_extra_bonus,
    } as any);

    const trades = res.total_trades;
    const winRate = Math.round(res.win_rate * 1000) / 10;
    const pf = Math.round(res.profit_factor * 100) / 100;
    const stopPcts = res.trades.map((t: any) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = Math.round(percentile(stopPcts, 0.75) * 10000) / 10000;
    const p75Margin50x = Math.round(p75Stop * 50 * 100) / 100;
    const annualTrades = Math.round(trades / annualFactor);

    const coreOk = annualTrades >= GUARD_MIN_TRADES && pf > GUARD_MIN_PF;
    const guardOk = p75Margin50x <= GUARD_MAX_P75_MARGIN_50X;
    const deltaWinRate = Math.round((winRate - NEW_BASELINE.winRate) * 10) / 10;
    const deltaTrades = annualTrades - NEW_BASELINE.trades;

    console.log(`[done] ${v.label} trades=${annualTrades} win=${winRate}% pf=${pf} 50x_p75=${p75Margin50x}%`);

    results.push({
      label: v.label,
      pattern_bonus: v.pa_pattern_retest_extra_bonus,
      trap_bonus: v.pa_trap_retest_extra_bonus,
      min_score: v.pa_retest_soft_min_score,
      trades: annualTrades,
      winRate,
      pf,
      p75Stop,
      p75Margin50x,
      deltaWinRate,
      deltaTrades,
      coreOk,
      guardOk,
    });
  }

  // 排序：勝率降序
  results.sort((a, b) => b.winRate - a.winRate || b.pf - a.pf);

  const winners = results.filter(r => r.coreOk && r.guardOk && r.winRate > GUARD_MIN_WINRATE);
  console.log(`[winners] ${winners.length} 個候選通過所有守門條件`);

  const ts = new Date().toISOString().replace(/:/g, "-").replace(/\..+/, "");
  const mdPath = path.join(OUT_DIR, `search_pattern_type_bonus_1h_${SYMBOL}_${ts}.md`);
  const jsonPath = path.join(OUT_DIR, `search_pattern_type_bonus_1h_${SYMBOL}_${ts}.json`);

  const top20 = results.slice(0, 20);

  const md = `# BTCUSDT 1H 延續型/特定 Pattern 回踩加分差異化實驗
作者：**Manus AI**

本輪實驗在新主版本軟評分基礎上，對不同 PA 進場類型（PA_PATTERN vs PA_2ND_LEG_TRAP）設定差異化的回踩加分，探索是否能進一步提升勝率。

## 基線與守門條件

| 項目 | 數值 |
| --- | ---: |
| Symbol | ${SYMBOL} |
| 新主版本基線胜率 | ${NEW_BASELINE.winRate}% |
| 新主版本基線 PF | ${NEW_BASELINE.pf} |
| 新主版本基線年交易數 | ${NEW_BASELINE.trades} |
| 新主版本基線 50x P75 保證金損耗 | ${NEW_BASELINE.p75Margin50x}% |
| 搜索變體數 | ${variants.length} |
| 通過守門並胜率超新基線的候選數 | ${winners.length} |

## 守門條件

| 條件 | 門檻 |
| --- | --- |
| 核心頻率要求 | 年交易數 ≥ ${GUARD_MIN_TRADES} 且 PF > ${GUARD_MIN_PF} |
| 高杠杆守門線 | 50x P75 保證金損耗 ≤ ${GUARD_MAX_P75_MARGIN_50X}% |
| 胜率超新基線 | 胜率 > ${GUARD_MIN_WINRATE}% |

## 通過守門的候選

${winners.length === 0 ? "本輪未找到同時滿足所有守門條件的差異化加分候選。" : winners.slice(0, 5).map(r => `
### ${r.label}
| 指標 | 數值 |
| --- | ---: |
| 年交易數 | ${r.trades} (${r.deltaTrades >= 0 ? "+" : ""}${r.deltaTrades}) |
| 胜率 | ${r.winRate}% (${r.deltaWinRate >= 0 ? "+" : ""}${r.deltaWinRate}%) |
| PF | ${r.pf} |
| 50x P75 保證金損耗 | ${r.p75Margin50x}% |
| PA_PATTERN 額外加分 | +${r.pattern_bonus} |
| PA_2ND_LEG_TRAP 額外加分 | +${r.trap_bonus} |
| 最低分門檻 | ${r.min_score} |
`).join("\n")}

## Top 20 結果總表

| Variant | Trades | Win Rate | PF | 50x P75 Margin | Pat Bonus | Trap Bonus | Min Score | Δ Win Rate | Δ Trades | Core OK | Guard OK |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
${top20.map(r => `| ${r.label} | ${r.trades} | ${r.winRate}% | ${r.pf} | ${r.p75Margin50x}% | +${r.pattern_bonus} | +${r.trap_bonus} | ${r.min_score} | ${r.deltaWinRate >= 0 ? "+" : ""}${r.deltaWinRate} | ${r.deltaTrades >= 0 ? "+" : ""}${r.deltaTrades} | ${r.coreOk ? "yes" : "no"} | ${r.guardOk ? "yes" : "no"} |`).join("\n")}

## 差異化加分機制說明

| 參數 | 說明 |
| --- | --- |
| pa_pattern_type_soft_bonus | 啟用 pattern 類型差異化加分 |
| pa_pattern_retest_extra_bonus | PA_PATTERN / PA_PATTERN_RETEST 類型回踩時的額外加分（在 soft_bonus 之上） |
| pa_trap_retest_extra_bonus | PA_2ND_LEG_TRAP 類型回踩時的額外加分 |

## 輸出文件

| 文件 | 路徑 |
| --- | --- |
| JSON | ${jsonPath} |
| Markdown | ${mdPath} |
`;

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(mdPath, md, "utf-8");
  await fs.writeFile(jsonPath, JSON.stringify({ meta: { symbol: SYMBOL, baseline: NEW_BASELINE, variants: variants.length, winners: winners.length }, results }, null, 2), "utf-8");

  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch(console.error);
