import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";
import { calcAdxArr } from "../server/utils/indicators.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type SessionMode = "all" | "exclude_offhours" | "london_newyork";
type WeekdayMode = "all" | "weekday_only";
type CandidateConfig = {
  family: BacktestStrategy;
  tp: number;
  trailing: boolean;
};
type LiteTrade = {
  entry_time: number;
  exit_time: number;
  direction: "long" | "short";
  pnl_net_pct: number;
};
type AnnotatedTrade = LiteTrade & {
  session: "asia" | "london" | "newyork" | "offhours";
  adx: number;
  weekday: number;
};
type Row = {
  candidate: string;
  family: BacktestStrategy;
  tp: number;
  trailing: boolean;
  session_mode: SessionMode;
  weekday_mode: WeekdayMode;
  adx_min: number;
  standalone_trades: number;
  standalone_win_rate_pct: number;
  added_trades: number;
  added_win_rate_pct: number;
  combo_total_trades: number;
  combo_win_rate_pct: number;
  delta_vs_base_trades: number;
  delta_vs_base_win_pct: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const CORE_VARIANT = "pa_sl1.95_tp0.21_pattern_on_breakout_off_trap_on_retest_on_lb24_touch0.04_reclaim0.04_same_bar_color_on";
const AGGRESSIVE_ADDON = "pa_sl1.75_tp0.19_pattern_on_breakout_off_trap_on_retest_on_lb12_touch0.08_reclaim0.03_either_color_off";
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 2): number {
  return Number(value.toFixed(digits));
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function parsePaVariant(variant: string) {
  const parts = variant.split("_");
  const takeAfterPrefix = (prefix: string) => {
    const item = parts.find((p) => p.startsWith(prefix));
    if (!item) throw new Error(`variant ${variant} 缺少 ${prefix}`);
    return item.slice(prefix.length);
  };
  const strategy = parts[0] as BacktestStrategy;
  return {
    strategy,
    atr_sl_mult: Number(takeAfterPrefix("sl")),
    atr_tp_mult: Number(takeAfterPrefix("tp")),
    pa_allow_pattern: variant.includes("pattern_on"),
    pa_allow_true_breakout: variant.includes("breakout_on"),
    pa_allow_trap: variant.includes("trap_on"),
    pa_require_retest_on_continuation: variant.includes("retest_on"),
    pa_retest_lookback_bars: Number(takeAfterPrefix("lb")),
    pa_retest_touch_tolerance_atr: Number(takeAfterPrefix("touch")),
    pa_retest_reclaim_offset_atr: Number(takeAfterPrefix("reclaim")),
    pa_retest_mode: variant.includes("same_bar")
      ? "same_bar"
      : variant.includes("next_bar_confirm")
        ? "next_bar_confirm"
        : "either",
    pa_retest_require_candle_color: variant.includes("color_on"),
  };
}

function liteTrades(trades: any[]): LiteTrade[] {
  return trades.map((t) => ({
    entry_time: t.entry_time,
    exit_time: t.exit_time,
    direction: t.direction,
    pnl_net_pct: t.pnl_net_pct,
  }));
}

function tradeKey(t: LiteTrade): string {
  return `${t.entry_time}_${t.direction}`;
}

function winRatePct(trades: LiteTrade[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter((t) => t.pnl_net_pct > 0).length;
  return round((wins / trades.length) * 100, 2);
}

function getSessionLabel(timestampSec: number): AnnotatedTrade["session"] {
  const hour = new Date(timestampSec * 1000).getUTCHours();
  if (hour >= 13 && hour < 22) return "newyork";
  if (hour >= 7 && hour < 16) return "london";
  if (hour >= 0 && hour < 8) return "asia";
  return "offhours";
}

function sessionAllowed(label: AnnotatedTrade["session"], mode: SessionMode): boolean {
  if (mode === "all") return true;
  if (mode === "exclude_offhours") return label !== "offhours";
  if (mode === "london_newyork") return label === "london" || label === "newyork";
  return true;
}

function weekdayAllowed(weekday: number, mode: WeekdayMode): boolean {
  if (mode === "all") return true;
  return weekday >= 1 && weekday <= 5;
}

async function runPaVariant(candles1h: Candle[], candles1d: Candle[], variantKey: string) {
  const v = parsePaVariant(variantKey);
  return runBacktest({
    candles: candles1h,
    strategy: v.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: v.atr_sl_mult,
    atr_tp_mult: v.atr_tp_mult,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: v.pa_allow_pattern,
    pa_allow_true_breakout: v.pa_allow_true_breakout,
    pa_allow_trap: v.pa_allow_trap,
    pa_require_retest_on_continuation: v.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: v.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: v.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: v.pa_retest_reclaim_offset_atr,
    pa_retest_mode: v.pa_retest_mode,
    pa_retest_require_candle_color: v.pa_retest_require_candle_color,
  });
}

async function runCandidate(candles15m: Candle[], candles4h: Candle[], config: CandidateConfig) {
  return runBacktest({
    candles: candles15m,
    strategy: config.family,
    symbol: SYMBOL,
    interval: "15m",
    atr_sl_mult: 2,
    atr_tp_mult: config.tp,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: config.trailing,
    enable_adx_filter: true,
    htf_candles: candles4h,
    entry_candles: candles15m,
    use_true_mtf: true,
  });
}

function annotateTrades(trades: LiteTrade[], candles15m: Candle[], adxArr: number[]): AnnotatedTrade[] {
  const timeToIndex = new Map(candles15m.map((c, i) => [c.time, i]));
  return trades.map((t) => {
    const idx = timeToIndex.get(t.entry_time) ?? candles15m.findIndex((c) => c.time >= t.entry_time);
    const safeIdx = idx >= 0 ? idx : candles15m.length - 1;
    const adxVal = Number.isFinite(adxArr[safeIdx]) ? adxArr[safeIdx] : 0;
    const weekday = new Date(t.entry_time * 1000).getUTCDay();
    return {
      ...t,
      session: getSessionLabel(t.entry_time),
      adx: round(adxVal, 2),
      weekday,
    };
  });
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 96 * YEAR_DAYS);
  const candles4h = await fetchBinanceCandles(SYMBOL, "4h", 6 * YEAR_DAYS + 10);
  const { adx: adx15m } = calcAdxArr(candles15m, 14);

  console.log(`[1h range] ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[15m range] ${isoTime(candles15m[0]?.time)} -> ${isoTime(candles15m[candles15m.length - 1]?.time)}`);

  const core = await runPaVariant(candles1h, candles1d, CORE_VARIANT);
  const aggressive = await runPaVariant(candles1h, candles1d, AGGRESSIVE_ADDON);
  const coreTrades = liteTrades(core.trades as any[]);
  const aggressiveTrades = liteTrades(aggressive.trades as any[]);
  const coreSet = new Set(coreTrades.map((t) => tradeKey(t)));
  const baseTrades = [
    ...coreTrades,
    ...aggressiveTrades.filter((t) => !coreSet.has(tradeKey(t))),
  ].sort((a, b) => a.entry_time - b.entry_time);
  const baseSet = new Set(baseTrades.map((t) => tradeKey(t)));

  const configs: CandidateConfig[] = [];
  for (const family of ["ema_cross", "vwap_reversion", "rsi_reversal", "hwr_model_a", "cannonball", "macd"] as BacktestStrategy[]) {
    for (const tp of [1.2, 1.5, 1.8, 2.0]) {
      for (const trailing of [false, true]) {
        configs.push({ family, tp, trailing });
      }
    }
  }

  const sessionModes: SessionMode[] = ["all", "exclude_offhours", "london_newyork"];
  const weekdayModes: WeekdayMode[] = ["all", "weekday_only"];
  const adxThresholds = [0, 18, 20, 25, 30, 35];
  const rows: Row[] = [];

  for (const config of configs) {
    const res = await runCandidate(candles15m, candles4h, config);
    const standaloneTrades = liteTrades(res.trades as any[]);
    const annotatedAdded = annotateTrades(
      standaloneTrades.filter((t) => !baseSet.has(tradeKey(t))),
      candles15m,
      adx15m,
    );

    for (const sessionMode of sessionModes) {
      for (const weekdayMode of weekdayModes) {
        for (const adxMin of adxThresholds) {
          const addedTrades = annotatedAdded.filter((t) => (
            sessionAllowed(t.session, sessionMode)
            && weekdayAllowed(t.weekday, weekdayMode)
            && t.adx >= adxMin
          ));
          if (addedTrades.length === 0) continue;
          const comboTrades = [...baseTrades, ...addedTrades].sort((a, b) => a.entry_time - b.entry_time);
          rows.push({
            candidate: `${config.family}_tp${config.tp}_trailing_${config.trailing ? "on" : "off"}`,
            family: config.family,
            tp: config.tp,
            trailing: config.trailing,
            session_mode: sessionMode,
            weekday_mode: weekdayMode,
            adx_min: adxMin,
            standalone_trades: standaloneTrades.length,
            standalone_win_rate_pct: winRatePct(standaloneTrades),
            added_trades: addedTrades.length,
            added_win_rate_pct: winRatePct(addedTrades),
            combo_total_trades: comboTrades.length,
            combo_win_rate_pct: winRatePct(comboTrades),
            delta_vs_base_trades: comboTrades.length - baseTrades.length,
            delta_vs_base_win_pct: round(winRatePct(comboTrades) - winRatePct(baseTrades), 2),
          });
        }
      }
    }
    console.log(`[done] ${config.family} tp=${config.tp} trailing=${config.trailing ? "on" : "off"} -> standalone ${standaloneTrades.length} / ${winRatePct(standaloneTrades)}%`);
  }

  rows.sort((a, b) => {
    if (b.combo_win_rate_pct !== a.combo_win_rate_pct) return b.combo_win_rate_pct - a.combo_win_rate_pct;
    if (b.combo_total_trades !== a.combo_total_trades) return b.combo_total_trades - a.combo_total_trades;
    return b.added_win_rate_pct - a.added_win_rate_pct;
  });

  const topRows = rows.slice(0, 40);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_addon_subsets_round4_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_addon_subsets_round4_${SYMBOL}_${ts}.md`);

  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    base_combo: {
      core_variant: CORE_VARIANT,
      aggressive_addon: AGGRESSIVE_ADDON,
      total_trades: baseTrades.length,
      win_rate_pct: winRatePct(baseTrades),
    },
    search_space: {
      families: ["ema_cross", "vwap_reversion", "rsi_reversal", "hwr_model_a", "cannonball", "macd"],
      tp_values: [1.2, 1.5, 1.8, 2.0],
      trailing_values: [false, true],
      session_modes: sessionModes,
      weekday_modes: weekdayModes,
      adx_thresholds: adxThresholds,
    },
    total_rows: rows.length,
    rows: topRows,
  }, null, 2), "utf8");

  const table = topRows.map((r) => `| ${r.candidate} | ${r.session_mode} | ${r.weekday_mode} | ${r.adx_min} | ${r.added_trades} | ${r.added_win_rate_pct}% | ${r.combo_total_trades} | ${r.combo_win_rate_pct}% | ${r.delta_vs_base_trades >= 0 ? "+" : ""}${r.delta_vs_base_trades} | ${r.delta_vs_base_win_pct >= 0 ? "+" : ""}${r.delta_vs_base_win_pct} |`).join("\n");
  const md = `# BTCUSDT 第四轮 Add-on 子集搜索\n\n| 项目 | 数值 |\n| --- | ---: |\n| 基线组合交易数 | ${baseTrades.length} |\n| 基线组合胜率 | ${winRatePct(baseTrades)}% |\n| 搜索家族数 | 6 |\n| 搜索组合数 | ${rows.length} |\n\n> 本轮不再直接整族并入，而是对低频或中频外部家族做“参数 + 时段 + weekday + ADX”联合筛选，只保留能作为当前 PA 基线补充来源的极小子集。\n\n| Candidate | Session | Weekday | ADX Min | Added Trades | Added Win | Combo Trades | Combo Win | Δ Trades | Δ Win |\n| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${table}\n`;
  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
