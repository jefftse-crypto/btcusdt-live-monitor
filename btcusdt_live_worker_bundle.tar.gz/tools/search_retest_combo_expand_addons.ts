import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type VariantConfig = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
};

type BacktestTradeLite = {
  entry_time: number;
  exit_time: number;
  direction: "long" | "short";
  pnl_net_pct: number;
};

type SearchRow = {
  variant: string;
  total_trades: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct?: number;
  max_drawdown_pct?: number;
};

type ComboRow = {
  addon_variant: string;
  addon_total_trades: number;
  addon_win_rate_pct: number;
  overlap_trades: number;
  added_trades: number;
  added_win_rate_pct: number;
  combo_total_trades: number;
  combo_win_rate_pct: number;
  delta_vs_core_trades: number;
  delta_vs_core_win_pct: number;
  score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const SEARCH_JSON = "/home/ubuntu/upload/search_retest_improve_win_trades_BTCUSDT_2026-04-15T04-49-23-122Z.json";
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const CORE_VARIANT = "pa_sl1.95_tp0.21_pattern_on_breakout_off_trap_on_retest_on_lb24_touch0.04_reclaim0.04_same_bar_color_on";
const CURRENT_BEST_COMBO_TRADES = 91;
const CURRENT_BEST_COMBO_WIN = 83.52;
const MAX_CANDIDATES = 48;

function round(value: number, digits = 2): number {
  return Number(value.toFixed(digits));
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload.map((row) => normalizeBinanceRow(row)).filter((row): row is Candle => row !== null).sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function parseVariant(variant: string): VariantConfig {
  const parts = variant.split("_");
  const takeAfterPrefix = (prefix: string) => {
    const item = parts.find((p) => p.startsWith(prefix));
    if (!item) throw new Error(`variant ${variant} 缺少 ${prefix}`);
    return item.slice(prefix.length);
  };
  const has = (token: string) => parts.includes(token);
  const strategy = parts[0] as BacktestStrategy;
  return {
    key: variant,
    strategy,
    atr_sl_mult: Number(takeAfterPrefix("sl")),
    atr_tp_mult: Number(takeAfterPrefix("tp")),
    pa_allow_pattern: has("pattern") ? true : variant.includes("pattern_on"),
    pa_allow_true_breakout: variant.includes("breakout_on"),
    pa_allow_trap: variant.includes("trap_on"),
    pa_require_retest_on_continuation: variant.includes("retest_on"),
    pa_retest_lookback_bars: Number(takeAfterPrefix("lb")),
    pa_retest_touch_tolerance_atr: Number(takeAfterPrefix("touch")),
    pa_retest_reclaim_offset_atr: Number(takeAfterPrefix("reclaim")),
    pa_retest_mode: variant.includes("same_bar") ? "same_bar" : variant.includes("next_bar_confirm") ? "next_bar_confirm" : "either",
    pa_retest_require_candle_color: variant.includes("color_on"),
  };
}

function tradeKey(t: BacktestTradeLite): string {
  return `${t.entry_time}_${t.direction}`;
}

function winRatePct(trades: BacktestTradeLite[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter((t) => t.pnl_net_pct > 0).length;
  return round((wins / trades.length) * 100, 2);
}

function liteTrades(trades: any[]): BacktestTradeLite[] {
  return trades.map((t) => ({
    entry_time: t.entry_time,
    exit_time: t.exit_time,
    direction: t.direction,
    pnl_net_pct: t.pnl_net_pct,
  }));
}

async function runVariant(candles1h: Candle[], candles1d: Candle[], variantKey: string) {
  const v = parseVariant(variantKey);
  return runBacktest({
    candles: candles1h,
    strategy: v.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: v.atr_sl_mult,
    atr_tp_mult: v.atr_tp_mult,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: v.pa_allow_pattern,
    pa_allow_true_breakout: v.pa_allow_true_breakout,
    pa_allow_trap: v.pa_allow_trap,
    pa_require_retest_on_continuation: v.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: v.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: v.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: v.pa_retest_reclaim_offset_atr,
    pa_retest_mode: v.pa_retest_mode,
    pa_retest_require_candle_color: v.pa_retest_require_candle_color,
  });
}

function chooseCandidates(rows: SearchRow[]): SearchRow[] {
  return rows
    .filter((r) => r.variant !== CORE_VARIANT)
    .filter((r) => r.total_trades >= 78)
    .filter((r) => r.win_rate_pct >= 80)
    .filter((r) => r.profit_factor >= 1.08)
    .filter((r) => !r.variant.includes("lb24_touch0.04_reclaim0.04_same_bar_color_on"))
    .map((r) => ({
      ...r,
      heuristic: round(
        r.total_trades * 0.52 +
        r.win_rate_pct * 0.33 +
        r.profit_factor * 10 +
        (r.total_return_net_pct ?? 0) * 1.5 -
        Math.max(0, (r.max_drawdown_pct ?? 0) - 4.5) * 1.6,
        2
      ),
    }))
    .sort((a: any, b: any) => b.heuristic - a.heuristic || b.total_trades - a.total_trades || b.win_rate_pct - a.win_rate_pct)
    .slice(0, MAX_CANDIDATES);
}

async function main() {
  const raw = JSON.parse(await fs.readFile(SEARCH_JSON, "utf8"));
  const sourceRows: SearchRow[] = raw.rows ?? [];
  const candidates = chooseCandidates(sourceRows);
  console.log(`[candidates] selected=${candidates.length}`);
  for (const c of candidates.slice(0, 12)) {
    console.log(`[candidate] ${c.variant} trades=${c.total_trades} win=${c.win_rate_pct}% pf=${c.profit_factor}`);
  }

  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);

  const core = await runVariant(candles1h, candles1d, CORE_VARIANT);
  const coreTrades = liteTrades(core.trades as any[]);
  const coreMap = new Map(coreTrades.map((t) => [tradeKey(t), t]));
  const coreWin = round(core.win_rate * 100, 2);

  const rows: ComboRow[] = [];
  for (const candidate of candidates) {
    const addon = await runVariant(candles1h, candles1d, candidate.variant);
    const addonTrades = liteTrades(addon.trades as any[]);
    const overlap = addonTrades.filter((t) => coreMap.has(tradeKey(t)));
    const added = addonTrades.filter((t) => !coreMap.has(tradeKey(t)));
    const comboTrades = [...coreTrades, ...added].sort((a, b) => a.entry_time - b.entry_time);
    const comboWin = winRatePct(comboTrades);
    const addedWin = winRatePct(added);
    const score = round(
      comboTrades.length * 0.62 +
      comboWin * 0.45 +
      added.length * 0.28 +
      addedWin * 0.18 +
      (comboWin - CURRENT_BEST_COMBO_WIN) * 12 +
      (comboTrades.length - CURRENT_BEST_COMBO_TRADES) * 1.8,
      2
    );

    rows.push({
      addon_variant: candidate.variant,
      addon_total_trades: addon.total_trades,
      addon_win_rate_pct: round(addon.win_rate * 100, 2),
      overlap_trades: overlap.length,
      added_trades: added.length,
      added_win_rate_pct: addedWin,
      combo_total_trades: comboTrades.length,
      combo_win_rate_pct: comboWin,
      delta_vs_core_trades: comboTrades.length - core.total_trades,
      delta_vs_core_win_pct: round(comboWin - coreWin, 2),
      score,
    });
    const last = rows[rows.length - 1];
    console.log(`[combo] add=${last.added_trades} addWin=${last.added_win_rate_pct}% combo=${last.combo_total_trades} comboWin=${last.combo_win_rate_pct}% :: ${last.addon_variant}`);
  }

  const sorted = rows.sort((a, b) => b.score - a.score || b.combo_win_rate_pct - a.combo_win_rate_pct || b.combo_total_trades - a.combo_total_trades);
  const improved = sorted.filter((r) => r.combo_total_trades > CURRENT_BEST_COMBO_TRADES || r.combo_win_rate_pct > CURRENT_BEST_COMBO_WIN);

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_retest_combo_expand_addons_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_retest_combo_expand_addons_${SYMBOL}_${ts}.md`);
  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    core_variant: CORE_VARIANT,
    current_best_combo: { total_trades: CURRENT_BEST_COMBO_TRADES, win_rate_pct: CURRENT_BEST_COMBO_WIN },
    candidates_tested: candidates.map((c) => c.variant),
    rows: sorted,
    improved_rows: improved,
  }, null, 2), "utf8");

  const topRows = sorted.slice(0, 30).map((r) => `| ${r.addon_variant} | ${r.addon_total_trades} | ${r.overlap_trades} | ${r.added_trades} | ${r.added_win_rate_pct}% | ${r.combo_total_trades} | ${r.combo_win_rate_pct}% | ${r.delta_vs_core_trades >= 0 ? "+" : ""}${r.delta_vs_core_trades} | ${r.delta_vs_core_win_pct >= 0 ? "+" : ""}${r.delta_vs_core_win_pct} | ${r.score} |`).join("\n");
  const md = `# BTCUSDT 扩展 Add-on 组合搜索\n\n| 项目 | 数值 |\n| --- | ---: |\n| Core Variant | ${CORE_VARIANT} |\n| Core Trades | ${core.total_trades} |\n| Core Win Rate | ${coreWin}% |\n| Current Best Combo Trades | ${CURRENT_BEST_COMBO_TRADES} |\n| Current Best Combo Win Rate | ${CURRENT_BEST_COMBO_WIN}% |\n| Candidate Pool Tested | ${candidates.length} |\n| Improved Rows | ${improved.length} |\n\n| Addon Variant | Addon Trades | Overlap | Added Trades | Added Win | Combo Trades | Combo Win | Δ Trades vs Core | Δ Win vs Core | Score |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${topRows}\n`;
  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
