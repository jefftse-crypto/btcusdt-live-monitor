import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

type Summary = {
  name: string;
  total_trades: number;
  win_rate_pct: number;
  gross_win_rate_pct: number;
  breakeven_or_fee_flip_count: number;
  fee_flip_pct: number;
  avg_gross_win_pct: number;
  avg_net_win_pct: number;
  exit_reason_breakdown: Record<string, { trades: number; net_wins: number; gross_wins: number }>;
  entry_type_breakdown: Record<string, { trades: number; net_wins: number; gross_wins: number; fee_flips: number; avg_gross_pct: number; avg_net_pct: number }>;
  signal_score_buckets: Record<string, { trades: number; net_wins: number; gross_wins: number; fee_flips: number }>;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_PATH = "/home/ubuntu/work_crypto_dashboard/route_a_fee_sensitivity_diag.json";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const round = (v: number, d = 4) => Number(v.toFixed(d));

function normalizeBinanceRow(row: unknown[]): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Number(row[0]);
  const open = parseFloat(String(row[1]));
  const high = parseFloat(String(row[2]));
  const low = parseFloat(String(row[3]));
  const close = parseFloat(String(row[4]));
  const volume = parseFloat(String(row[5]));
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, maxAttempts = 5): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function bucketScore(score: number | undefined): string {
  const s = score ?? -1;
  if (s < 0) return "missing";
  if (s < 6.5) return "lt6.5";
  if (s < 7.5) return "6.5-7.49";
  if (s < 8.5) return "7.5-8.49";
  return "ge8.5";
}

function summarize(name: string, result: ReturnType<typeof runBacktest>): Summary {
  const entryTypeMap: Summary["entry_type_breakdown"] = {};
  const exitReasonMap: Summary["exit_reason_breakdown"] = {};
  const scoreBuckets: Summary["signal_score_buckets"] = {};
  let netWins = 0;
  let grossWins = 0;
  let feeFlips = 0;
  let grossWinSum = 0;
  let netWinSum = 0;

  for (const t of result.trades) {
    const entryType = t.entry_type ?? "unknown";
    const exitReason = t.exit_reason ?? "unknown";
    const bucket = bucketScore(t.signal_score);
    const grossWin = t.pnl_pct > 0;
    const netWin = t.pnl_net_pct > 0;
    const feeFlip = t.pnl_pct > 0 && t.pnl_net_pct <= 0;

    if (grossWin) {
      grossWins++;
      grossWinSum += t.pnl_pct;
    }
    if (netWin) {
      netWins++;
      netWinSum += t.pnl_net_pct;
    }
    if (feeFlip) feeFlips++;

    if (!entryTypeMap[entryType]) entryTypeMap[entryType] = { trades: 0, net_wins: 0, gross_wins: 0, fee_flips: 0, avg_gross_pct: 0, avg_net_pct: 0 };
    if (!exitReasonMap[exitReason]) exitReasonMap[exitReason] = { trades: 0, net_wins: 0, gross_wins: 0 };
    if (!scoreBuckets[bucket]) scoreBuckets[bucket] = { trades: 0, net_wins: 0, gross_wins: 0, fee_flips: 0 };

    entryTypeMap[entryType].trades++;
    exitReasonMap[exitReason].trades++;
    scoreBuckets[bucket].trades++;

    if (grossWin) {
      entryTypeMap[entryType].gross_wins++;
      exitReasonMap[exitReason].gross_wins++;
      scoreBuckets[bucket].gross_wins++;
      entryTypeMap[entryType].avg_gross_pct += t.pnl_pct;
    }
    if (netWin) {
      entryTypeMap[entryType].net_wins++;
      exitReasonMap[exitReason].net_wins++;
      scoreBuckets[bucket].net_wins++;
      entryTypeMap[entryType].avg_net_pct += t.pnl_net_pct;
    }
    if (feeFlip) {
      entryTypeMap[entryType].fee_flips++;
      scoreBuckets[bucket].fee_flips++;
    }
  }

  for (const stats of Object.values(entryTypeMap)) {
    stats.avg_gross_pct = stats.gross_wins > 0 ? round(stats.avg_gross_pct / stats.gross_wins, 5) : 0;
    stats.avg_net_pct = stats.net_wins > 0 ? round(stats.avg_net_pct / stats.net_wins, 5) : 0;
  }

  return {
    name,
    total_trades: result.total_trades,
    win_rate_pct: round(result.win_rate * 100, 1),
    gross_win_rate_pct: round((grossWins / Math.max(1, result.total_trades)) * 100, 1),
    breakeven_or_fee_flip_count: feeFlips,
    fee_flip_pct: round((feeFlips / Math.max(1, result.total_trades)) * 100, 1),
    avg_gross_win_pct: grossWins > 0 ? round(grossWinSum / grossWins, 5) : 0,
    avg_net_win_pct: netWins > 0 ? round(netWinSum / netWins, 5) : 0,
    exit_reason_breakdown: exitReasonMap,
    entry_type_breakdown: entryTypeMap,
    signal_score_buckets: scoreBuckets,
  };
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 4 * 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);

  const variants = [
    {
      name: "routea_1p95_0p23_sb1_cf1",
      atr_sl_mult: 1.95,
      atr_tp_mult: 0.23,
      pa_resonance_only_strong_bias: true,
      pa_resonance_require_next_bar_confirmation: true,
    },
    {
      name: "routea_1p95_0p24_sb1_cf1",
      atr_sl_mult: 1.95,
      atr_tp_mult: 0.24,
      pa_resonance_only_strong_bias: true,
      pa_resonance_require_next_bar_confirmation: true,
    },
    {
      name: "routea_2p00_0p24_sb1_cf1",
      atr_sl_mult: 2.0,
      atr_tp_mult: 0.24,
      pa_resonance_only_strong_bias: true,
      pa_resonance_require_next_bar_confirmation: true,
    },
  ];

  const output: Summary[] = [];
  for (const variant of variants) {
    const result = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      htf_candles: candles1d,
      strategy: "pa",
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: true,
      enable_fee: true,
      enable_trailing_stop: false,
      enable_adx_filter: true,
      pa_allow_pattern: true,
      pa_allow_true_breakout: false,
      pa_allow_trap: true,
      pa_require_retest_on_continuation: false,
      pa_retest_soft_score: true,
      pa_retest_soft_bonus: 0.5,
      pa_retest_soft_min_score: 7.5,
      pa_retest_touch_tolerance_atr: 0.04,
      pa_retest_mode: "same_bar",
      pa_retest_require_candle_color: true,
      pa_retest_lookback_bars: 20,
      pa_retest_reclaim_offset_atr: 0.03,
      pa_dual_tf_resonance: true,
      pa_resonance_bias_window_bars: 2,
      pa_resonance_min_score: 40,
      pa_resonance_min_score_strong_bias: 40,
      pa_resonance_min_score_normal_bias: 40,
      pa_resonance_min_score_weak_bias: 40,
      pa_resonance_require_key_level: true,
      pa_resonance_require_momentum: false,
      pa_resonance_use_15m_sl: false,
      pa_resonance_15m_sl_mult: 1.2,
      pa_resonance_15m_tp_mult: 0.15,
      pa_resonance_max_hold_bars_15m: 192,
      pa_session_mode: "all",
      pa_resonance_break_even_mode: "off",
      pa_resonance_enable_partial_take_profit: false,
      pa_resonance_only_strong_bias: variant.pa_resonance_only_strong_bias,
      pa_resonance_require_next_bar_confirmation: variant.pa_resonance_require_next_bar_confirmation,
      pa_resonance_time_align_only: true,
      pa_resonance_time_align_use_first_15m: true,
    });
    output.push(summarize(variant.name, result));
  }

  await fs.writeFile(OUT_PATH, JSON.stringify(output, null, 2) + "\n", "utf8");
  console.log(`saved ${OUT_PATH}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
