import fs from "node:fs";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
};
type Row = {
  strategy: string;
  variant: string;
  total_trades: number;
  win_rate_pct: number;
  trades_per_2d: number;
  total_return_net: number;
  profit_factor: number;
  sharpe_ratio: number;
  max_drawdown: number;
  enable_trailing_stop: boolean;
  atr_sl_mult: number;
  atr_tp_mult: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const MIN_WIN_RATE = 75;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function buildVariants(): Variant[] {
  const sls = [2.75, 3.0, 3.25, 3.5];
  const tps = [0.22, 0.24, 0.25, 0.26, 0.28, 0.3];
  const trailing = [false, true];
  const variants: Variant[] = [];
  for (const sl of sls) {
    for (const tp of tps) {
      for (const ts of trailing) {
        variants.push({
          key: `pa_sl${sl.toFixed(2)}_tp${tp.toFixed(2)}_mtfOn_adxOn_ts${ts ? "On" : "Off"}`,
          strategy: "pa",
          atr_sl_mult: sl,
          atr_tp_mult: tp,
          enable_mtf_filter: true,
          enable_adx_filter: true,
          enable_trailing_stop: ts,
        });
      }
    }
  }
  return variants;
}

const VARIANTS = buildVariants();

function isoTime(value: number | undefined): string { return value ? new Date(value * 1000).toISOString() : ""; }
function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]), high = Number(row[2]), low = Number(row[3]), close = Number(row[4]), volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}
async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" }, signal: AbortSignal.timeout(20000) });
      if (!res.ok) throw new Error(`Binance ${interval} K 線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}
async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload.map((row) => normalizeBinanceRow(row)).filter((row): row is Candle => row !== null).sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

async function main() {
  console.log(`[run] Profit Factor 精修搜尋 ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1h ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);

  const rows: Row[] = [];
  for (const variant of VARIANTS) {
    const r = runBacktest({
      candles: candles1h,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_fee: true,
      enable_trailing_stop: variant.enable_trailing_stop,
      enable_adx_filter: variant.enable_adx_filter,
      htf_candles: candles1d,
      entry_candles: candles1h,
      use_true_mtf: true,
    });
    const row: Row = {
      strategy: variant.strategy,
      variant: variant.key,
      total_trades: r.total_trades,
      win_rate_pct: Number((r.win_rate * 100).toFixed(2)),
      trades_per_2d: Number((r.total_trades / (YEAR_DAYS / 2)).toFixed(2)),
      total_return_net: Number(r.total_return_net.toFixed(4)),
      profit_factor: Number(r.profit_factor.toFixed(2)),
      sharpe_ratio: Number(r.sharpe_ratio.toFixed(2)),
      max_drawdown: Number(r.max_drawdown.toFixed(4)),
      enable_trailing_stop: variant.enable_trailing_stop,
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
    };
    rows.push(row);
    console.log(`[done] ${row.variant} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} net=${row.total_return_net}%`);
  }

  const qualified = rows
    .filter((r) => r.total_trades >= MIN_TRADES && r.win_rate_pct >= MIN_WIN_RATE)
    .sort((a, b) => b.profit_factor - a.profit_factor || b.total_return_net - a.total_return_net || b.win_rate_pct - a.win_rate_pct);

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_pf_refine_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_pf_refine_1h_${SYMBOL}_${ts}.md`);
  fs.writeFileSync(jsonPath, JSON.stringify({ symbol: SYMBOL, min_trades: MIN_TRADES, min_win_rate: MIN_WIN_RATE, qualified, rows }, null, 2));

  const table = qualified.length > 0
    ? qualified.slice(0, 20).map((r, i) => `| ${i + 1} | ${r.strategy} | ${r.variant} | ${r.total_trades} | ${r.trades_per_2d} | ${r.win_rate_pct}% | ${r.profit_factor} | ${r.total_return_net}% | ${r.sharpe_ratio} | ${r.max_drawdown}% |`).join("\n")
    : "| 1 | 無 | 無 | 0 | 0 | 0% | 0 | 0% | 0 | 0% |";

  const md = `# ${SYMBOL} 1D+1h Profit Factor 精修搜尋\n\n本報告以目前最佳基礎版 **PA + MTF 開啟 + ADX 開啟** 為中心，進一步微調 **ATR 止損、ATR 止盈與移動止損開關**，目標是在保留 **一年至少 ${MIN_TRADES} 筆交易** 與 **勝率至少 ${MIN_WIN_RATE}%** 的前提下，繼續提高 **Profit Factor**。資料來源為 Binance 公開 K 線端點 [1]。\n\n| 項目 | 值 |\n| --- | --- |\n| 標的 | ${SYMBOL} |\n| 最低交易數 | ${MIN_TRADES} |\n| 最低勝率 | ${MIN_WIN_RATE}% |\n| 掃描組合數 | ${VARIANTS.length} |\n\n## 符合頻率與勝率門檻的候選結果（依 Profit Factor 排序）\n\n| 排名 | 策略 | 變體 | 年交易數 | 每兩天交易數 | 勝率 | Profit Factor | 淨報酬 | Sharpe | 最大回撤 |\n| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${table}\n\n## References\n\n[1]: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data "Binance Spot API Docs - Kline/Candlestick data"\n`;
  fs.writeFileSync(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD: ${mdPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
