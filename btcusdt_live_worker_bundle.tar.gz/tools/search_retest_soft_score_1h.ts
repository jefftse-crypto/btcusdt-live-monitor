/**
 * search_retest_soft_score_1h.ts
 * 回踩軟評分搜索腳本 — 新環境優先級 #1 實驗
 *
 * 目標：把「回踩確認」從「硬門檻（必須滿足才能進場）」
 *       改造成「柔性信號質量特征（加分項 + 最低分門檻）」。
 *
 * 基線：PA / SL 1.95 / TP 0.21 / pattern_on / breakout_off / trap_on / retest_off
 *       胜率 ~81%，PF ~1.26，年交易數 ~189，50x P75 保證金損耗 ~80.27%
 *
 * 搜索維度：
 *   1. pa_retest_soft_bonus：回踩確認時的額外加分（0.5 / 1.0 / 1.5 / 2.0）
 *   2. pa_retest_soft_min_score：最低總分門檻（0 / 6.5 / 7.0 / 7.5 / 8.0）
 *   3. pa_retest_touch_tolerance_atr：回踩觸碰容差（0.04 / 0.08 / 0.12）
 *   4. pa_retest_mode：same_bar / either（寬鬆版）
 *
 * 作者：Manus AI
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  // 軟評分參數
  pa_retest_soft_score: boolean;
  pa_retest_soft_bonus: number;
  pa_retest_soft_min_score: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_reclaim_offset_atr: number;
};

type Row = {
  variant: string;
  soft_bonus: number;
  soft_min_score: number;
  touch_tolerance: number;
  retest_mode: RetestMode;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_baseline_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  soft_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

// 主版本基線（pattern_on / breakout_off / trap_on / retest_off）
const BASELINE_WIN_RATE = 81.0;
const BASELINE_PF = 1.26;
const BASELINE_TRADES = 189;
const BASELINE_P75_MARGIN_50X = 80.27;
const BASELINE_KEY = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_pattern_on_breakout_off_trap_on_retest_off_soft_off`;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function buildVariants(): Variant[] {
  const softBonuses = [0.5, 1.0, 1.5, 2.0];
  const softMinScores = [0, 6.5, 7.0, 7.5, 8.0];
  const touchTolerances = [0.04, 0.08, 0.12];
  const retestModes: RetestMode[] = ["same_bar", "either"];
  const variants: Variant[] = [];

  // 基線：軟評分關閉（等同主版本，用於驗證口徑）
  variants.push({
    key: BASELINE_KEY,
    strategy: "pa",
    atr_sl_mult: BASE_SL,
    atr_tp_mult: BASE_TP,
    enable_mtf_filter: true,
    enable_adx_filter: true,
    enable_trailing_stop: false,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: false,
    pa_retest_soft_score: false,
    pa_retest_soft_bonus: 0,
    pa_retest_soft_min_score: 0,
    pa_retest_touch_tolerance_atr: 0.08,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
    pa_retest_lookback_bars: 20,
    pa_retest_reclaim_offset_atr: 0.03,
  });

  // 軟評分實驗變體
  for (const pa_retest_soft_bonus of softBonuses) {
    for (const pa_retest_soft_min_score of softMinScores) {
      for (const pa_retest_touch_tolerance_atr of touchTolerances) {
        for (const pa_retest_mode of retestModes) {
          variants.push({
            key: [
              `pa_sl${BASE_SL.toFixed(2)}`,
              `tp${BASE_TP.toFixed(2)}`,
              "pattern_on",
              "breakout_off",
              "trap_on",
              "soft_on",
              `bonus${pa_retest_soft_bonus.toFixed(1)}`,
              `minscore${pa_retest_soft_min_score.toFixed(1)}`,
              `touch${pa_retest_touch_tolerance_atr.toFixed(2)}`,
              pa_retest_mode,
            ].join("_"),
            strategy: "pa",
            atr_sl_mult: BASE_SL,
            atr_tp_mult: BASE_TP,
            enable_mtf_filter: true,
            enable_adx_filter: true,
            enable_trailing_stop: false,
            pa_allow_pattern: true,
            pa_allow_true_breakout: false,
            pa_allow_trap: true,
            pa_require_retest_on_continuation: false,
            pa_retest_soft_score: true,
            pa_retest_soft_bonus,
            pa_retest_soft_min_score,
            pa_retest_touch_tolerance_atr,
            pa_retest_mode,
            pa_retest_require_candle_color: true,
            pa_retest_lookback_bars: 20,
            pa_retest_reclaim_offset_atr: 0.03,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function calcSoftScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "soft_score">): number {
  // 評分：胜率 + PF + 頻率保留率 - 高杠杆風控惡化
  const winRateReward = row.win_rate_pct * 8;
  const pfReward = row.profit_factor * 30;
  const freqReward = Math.max(0, row.total_trades - MIN_TRADES) * 0.03;
  const leveragePenalty = Math.max(0, row.p75_margin_loss_50x_pct - BASELINE_P75_MARGIN_50X) * 1.5;
  const tradePenalty = Math.max(0, MIN_TRADES - row.total_trades) * 0.3;
  return winRateReward + pfReward + freqReward - leveragePenalty - tradePenalty;
}

async function main() {
  console.log(`[run] retest soft score 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "soft_score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_adx_filter: variant.enable_adx_filter,
      enable_trailing_stop: variant.enable_trailing_stop,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_retest_soft_bonus: variant.pa_retest_soft_bonus,
      pa_retest_soft_min_score: variant.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
      pa_retest_mode: variant.pa_retest_mode,
      pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
      pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
      pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
    });

    const stopDistances = result.trades.map(t => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = round(percentile(stopDistances, 0.75), 4);
    const p75MarginLoss20x = round(p75Stop * 20, 2);
    const p75MarginLoss30x = round(p75Stop * 30, 2);
    const p75MarginLoss50x = round(p75Stop * 50, 2);
    const recMarginFrac20x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 20), 2) : 0;
    const recMarginFrac30x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 30), 2) : 0;
    const recMarginFrac50x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 50), 2) : 0;

    const row = {
      variant: variant.key,
      soft_bonus: variant.pa_retest_soft_bonus,
      soft_min_score: variant.pa_retest_soft_min_score,
      touch_tolerance: variant.pa_retest_touch_tolerance_atr,
      retest_mode: variant.pa_retest_mode,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 1),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net * 100, 2),
      max_drawdown_pct: round(result.max_drawdown * 100, 2),
      p75_stop_distance_pct: p75Stop,
      p75_margin_loss_20x_pct: p75MarginLoss20x,
      p75_margin_loss_30x_pct: p75MarginLoss30x,
      p75_margin_loss_50x_pct: p75MarginLoss50x,
      recommended_margin_fraction_20x_1pct: recMarginFrac20x,
      recommended_margin_fraction_30x_1pct: recMarginFrac30x,
      recommended_margin_fraction_50x_1pct: recMarginFrac50x,
    };

    console.log(`[done] ${variant.key} trades=${result.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor}`);
    rowsRaw.push(row);
  }

  const baseline = rowsRaw.find((row) => row.variant === BASELINE_KEY);
  if (!baseline) throw new Error(`找不到基線變體：${BASELINE_KEY}`);

  const rows: Row[] = rowsRaw.map((row) => {
    const qualified_core_requirements = row.total_trades >= MIN_TRADES && row.profit_factor > 1;
    const high_leverage_guard_ok = row.p75_margin_loss_50x_pct <= 82;
    const beats_baseline_winrate = row.win_rate_pct > BASELINE_WIN_RATE;
    const delta_win_rate_pct = round(row.win_rate_pct - BASELINE_WIN_RATE, 1);
    const delta_profit_factor = round(row.profit_factor - BASELINE_PF, 2);
    const delta_total_trades = row.total_trades - BASELINE_TRADES;
    const soft_score = calcSoftScore(row);
    return {
      ...row,
      qualified_core_requirements,
      high_leverage_guard_ok,
      beats_baseline_winrate,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      soft_score,
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const qa = Number(b.qualified_core_requirements) - Number(a.qualified_core_requirements);
    if (qa !== 0) return qa;
    const ga = Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok);
    if (ga !== 0) return ga;
    return b.soft_score - a.soft_score;
  });

  const winners = sorted.filter((row) => row.qualified_core_requirements && row.high_leverage_guard_ok && row.beats_baseline_winrate);
  const top20 = sorted.slice(0, 20);

  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `search_retest_soft_score_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_retest_soft_score_1h_${SYMBOL}_${ts}.md`);

  const jsonData = {
    symbol: SYMBOL,
    baseline_key: BASELINE_KEY,
    baseline_win_rate: BASELINE_WIN_RATE,
    baseline_pf: BASELINE_PF,
    baseline_trades: BASELINE_TRADES,
    baseline_p75_margin_50x: BASELINE_P75_MARGIN_50X,
    total_variants: VARIANTS.length,
    winners: winners.length,
    rows: sorted,
  };
  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify(jsonData, null, 2));

  const winnerLines = winners.length === 0
    ? "本輪未找到同時滿足「核心頻率要求」、「高杠杆守門線」且「胜率高於基線」的軟評分變體。"
    : winners.slice(0, 10).map((row, idx) =>
        `${idx + 1}. **${row.variant}**：胜率 ${row.win_rate_pct}%，PF ${row.profit_factor}，年交易 ${row.total_trades}，50x P75 保證金損耗 ${row.p75_margin_loss_50x_pct}%，Δ胜率 ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct}，Δ交易數 ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades}。`
      ).join("\n");

  const summaryTable = top20.map((row) =>
    `| ${row.variant.slice(0, 60)} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.p75_stop_distance_pct}% | ${row.p75_margin_loss_50x_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades} | ${row.qualified_core_requirements ? "yes" : "no"} | ${row.high_leverage_guard_ok ? "yes" : "no"} |`
  ).join("\n");

  const md = `# BTCUSDT 1H 回踩軟評分搜索
作者：**Manus AI**

本輪搜索是新環境第一優先級實驗：把「回踩確認」從「硬門檻」改造成「柔性信號質量特征（加分項 + 最低分門檻）」。基線為當前主版本 **PA / SL ${BASE_SL.toFixed(2)} / TP ${BASE_TP.toFixed(2)} / pattern_on / breakout_off / trap_on / retest_off**。

| 項目 | 數值 |
| --- | ---: |
| Symbol | ${SYMBOL} |
| 基線胜率 | ${BASELINE_WIN_RATE}% |
| 基線 PF | ${BASELINE_PF} |
| 基線年交易數 | ${BASELINE_TRADES} |
| 基線 50x P75 保證金損耗 | ${BASELINE_P75_MARGIN_50X}% |
| 搜索變體數 | ${VARIANTS.length} |
| 通過守門並胜率超基線的候選數 | ${winners.length} |

## 通過守門並且胜率高於基線的候選

${winnerLines}

## Top 20 結果總表

| Variant | Trades | Win Rate | PF | P75 Stop | 50x P75 Margin | Δ Win Rate | Δ Trades | Core OK | Guard OK |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
${summaryTable}

## 軟評分機制說明

| 參數 | 含義 |
| --- | --- |
| pa_retest_soft_score | 啟用軟評分模式（回踩確認作為加分項而非硬門檻） |
| pa_retest_soft_bonus | 回踩確認時的額外加分（0.5 / 1.0 / 1.5 / 2.0） |
| pa_retest_soft_min_score | 最低總分門檻（0 = 不過濾，6.5 / 7.0 / 7.5 / 8.0 = 漸進過濾） |
| pa_retest_touch_tolerance_atr | 回踩觸碰容差（0.04 / 0.08 / 0.12 ATR） |
| pa_retest_mode | same_bar = 同根確認，either = 同根或下一根均可 |

## 核心守門條件

| 條件 | 門檻 |
| --- | --- |
| 核心頻率要求 | 年交易數 ≥ ${MIN_TRADES} 且 PF > 1 |
| 高杠杆守門線 | 50x P75 保證金損耗 ≤ 82% |
| 胜率超基線 | 胜率 > ${BASELINE_WIN_RATE}% |

## 輸出文件

| 文件 | 路徑 |
| --- | --- |
| JSON | ${jsonPath} |
| Markdown | ${mdPath} |
`;

  await fs.writeFile(mdPath, md);
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
  console.log(`[winners] ${winners.length} 個候選通過所有守門條件`);
}

main().catch((err) => {
  console.error("[error]", err);
  process.exit(1);
});
