import fs from 'node:fs/promises';
import path from 'node:path';
import { runBacktest } from '../server/backtest.ts';
import { BTCUSDT_LIVE_PRESETS, type LivePreset } from '../server/live_btcusdt_strategy_presets.ts';

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type AlertState = {
  version: number;
  disabled_legacy_notifiers: boolean;
  last_checked_at?: string;
  last_error_at?: string;
  last_error_message?: string;
  strategies: Record<string, { last_alert_key?: string; last_entry_time?: number; last_sent_at?: string }>;
};

type StrategySignal = {
  preset: LivePreset;
  signal_time: number;
  entry_time: number;
  direction: string;
  entry_type: string;
  entry_price: number;
  reason: string;
  score?: number;
  adx?: number;
  used_15m_execution?: boolean;
  alert_key: string;
  raw_trade: Record<string, unknown>;
};

type StrategyCheckResult = {
  preset: LivePreset;
  signal: StrategySignal | null;
  error?: string;
};

type DispatchResult = {
  preset_key: string;
  alert_key: string;
  status: 'sent' | 'failed' | 'duplicate_skip';
  error?: string;
  sent_at?: string;
};

const SYMBOL = 'BTCUSDT';
const BINANCE_KLINES_URL = process.env.BTCUSDT_LIVE_KLINES_URL ?? 'https://data-api.binance.vision/api/v3/klines';
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve(process.cwd(), 'runtime');
const STATE_FILE = path.join(OUT_DIR, 'btcusdt_live_telegram_state.json');
const SNAPSHOT_FILE = path.join(OUT_DIR, 'btcusdt_live_signal_snapshot.json');
const INTERVAL_MS = Number(process.env.BTCUSDT_LIVE_POLL_MS ?? 5 * 60 * 1000);
const LOOKBACK_1H = Number(process.env.BTCUSDT_LIVE_LOOKBACK_1H ?? 24 * 220);
const LOOKBACK_1D = Number(process.env.BTCUSDT_LIVE_LOOKBACK_1D ?? 420);
const LOOKBACK_15M = Number(process.env.BTCUSDT_LIVE_LOOKBACK_15M ?? 24 * 4 * 45);
const FRESHNESS_1H_SEC = 2 * 60 * 60;
const FRESHNESS_15M_SEC = 45 * 60;
const HTTP_TIMEOUT_MS = Number(process.env.BTCUSDT_LIVE_HTTP_TIMEOUT_MS ?? 20000);
const TELEGRAM_TIMEOUT_MS = Number(process.env.BTCUSDT_LIVE_TELEGRAM_TIMEOUT_MS ?? 15000);
const MAX_FETCH_RETRIES = Number(process.env.BTCUSDT_LIVE_FETCH_RETRIES ?? 5);
const MAX_TELEGRAM_RETRIES = Number(process.env.BTCUSDT_LIVE_TELEGRAM_RETRIES ?? 3);

function nowIso() {
  return new Date().toISOString();
}

function round(value: number, digits = 4) {
  return Number(value.toFixed(digits));
}

function asNumber(value: unknown): number | undefined {
  const n = Number(value);
  return Number.isFinite(n) ? n : undefined;
}

function asString(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function formatUtc(tsSec: number): string {
  return new Date(tsSec * 1000).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchWithRetry(url: string, label: string, maxAttempts = MAX_FETCH_RETRIES): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 CryptoDashboard/5.9 LiveMonitor' },
        signal: AbortSignal.timeout(HTTP_TIMEOUT_MS),
      });
      if (!res.ok) throw new Error(`抓取 ${label} K 线失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(400 * attempt);
    }
  }
  throw lastError;
}

async function fetchCandles(interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol: SYMBOL, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(80);
  }
  return candles.slice(-targetCount);
}

async function ensureRuntimeState(): Promise<AlertState> {
  await fs.mkdir(OUT_DIR, { recursive: true });
  try {
    const raw = await fs.readFile(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw) as AlertState;
    return {
      version: 2,
      disabled_legacy_notifiers: true,
      strategies: parsed.strategies ?? {},
      last_checked_at: parsed.last_checked_at,
      last_error_at: parsed.last_error_at,
      last_error_message: parsed.last_error_message,
    };
  } catch {
    return {
      version: 2,
      disabled_legacy_notifiers: true,
      strategies: {},
    };
  }
}

async function saveState(state: AlertState) {
  state.last_checked_at = nowIso();
  await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
}

async function saveSnapshot(payload: unknown) {
  await fs.writeFile(SNAPSHOT_FILE, JSON.stringify(payload, null, 2) + '\n');
}

function buildReason(preset: LivePreset, trade: Record<string, unknown>): string {
  const parts = [preset.label, preset.expected_summary];
  const score = asNumber((trade as Record<string, unknown>).signal_score ?? trade.score);
  const adx = asNumber(trade.entry_adx);
  const session = asString(trade.pa_session) ?? asString(trade.session_label);
  if (score !== undefined) parts.push(`score ${round(score, 2)}`);
  if (adx !== undefined) parts.push(`ADX ${round(adx, 2)}`);
  if (session) parts.push(`session ${session}`);
  return parts.join(' | ');
}

function formatTelegramMessage(signal: StrategySignal): string {
  const side = signal.direction === 'long' ? 'BUY / LONG' : 'SELL / SHORT';
  return [
    `BTCUSDT 实战提醒`,
    `策略：${signal.preset.label}`,
    `动作：${side}`,
    `进场时间：${formatUtc(signal.entry_time)}`,
    `触发时间：${formatUtc(signal.signal_time)}`,
    `进场价：${signal.entry_price}`,
    `类型：${signal.entry_type}`,
    signal.used_15m_execution ? `执行：15m 共振触发` : `执行：1h 主信号触发`,
    `说明：${signal.reason}`,
  ].join('\n');
}

async function sendTelegram(text: string) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN ?? process.env.BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID ?? process.env.CHAT_ID;
  if (!botToken || !chatId) {
    throw new Error('缺少 TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID，无法发送 Telegram 提示。');
  }
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  const body = new URLSearchParams({ chat_id: chatId, text, parse_mode: 'HTML' });

  let lastError: unknown;
  for (let attempt = 1; attempt <= MAX_TELEGRAM_RETRIES; attempt++) {
    try {
      const res = await fetch(url, { method: 'POST', body, signal: AbortSignal.timeout(TELEGRAM_TIMEOUT_MS) });
      const payload = await res.json();
      if (!res.ok || !payload?.ok) {
        throw new Error(`Telegram 发送失败：${JSON.stringify(payload)}`);
      }
      return;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

function extractLatestSignal(preset: LivePreset, trades: Array<Record<string, unknown>>, latestClosed1h: Candle, latestClosed15m: Candle): StrategySignal | null {
  if (trades.length === 0) return null;
  const trade = trades[trades.length - 1];
  const entryTime = asNumber(trade.entry_time);
  const direction = asString(trade.direction);
  const entryType = asString(trade.entry_type) ?? 'UNKNOWN';
  const entryPrice = asNumber(trade.entry_price);
  if (entryTime === undefined || !direction || entryPrice === undefined) return null;

  const used15mExecution = Boolean(trade.used_15m_execution);
  const signalTime = used15mExecution
    ? (asNumber(trade.resonance_entry_time_15m) ?? entryTime)
    : entryTime;
  const freshnessLimit = used15mExecution ? FRESHNESS_15M_SEC : FRESHNESS_1H_SEC;
  const latestClock = used15mExecution ? latestClosed15m.time : latestClosed1h.time;
  if (signalTime < latestClock - freshnessLimit) return null;

  const alertKey = [preset.key, direction, entryType, String(signalTime)].join(':');
  return {
    preset,
    signal_time: signalTime,
    entry_time: entryTime,
    direction,
    entry_type: entryType,
    entry_price: round(entryPrice, 2),
    reason: buildReason(preset, trade),
    score: asNumber((trade as Record<string, unknown>).signal_score ?? trade.score),
    adx: asNumber(trade.entry_adx),
    used_15m_execution: used15mExecution,
    alert_key: alertKey,
    raw_trade: trade,
  };
}

async function evaluatePreset(preset: LivePreset, candles1h: Candle[], candles1d: Candle[], candles15m: Candle[]): Promise<StrategyCheckResult> {
  try {
    const result = runBacktest({
      candles: candles1h,
      symbol: preset.symbol,
      interval: preset.interval,
      htf_candles: candles1d,
      entry_candles: candles1h,
      use_true_mtf: true,
      pa_resonance_candles_15m: candles15m,
      enable_fee: true,
      strategy: preset.strategy,
      atr_sl_mult: preset.atr_sl_mult,
      atr_tp_mult: preset.atr_tp_mult,
      enable_mtf_filter: preset.enable_mtf_filter,
      enable_adx_filter: preset.enable_adx_filter,
      enable_trailing_stop: preset.enable_trailing_stop,
      pa_allow_pattern: preset.pa_allow_pattern,
      pa_allow_true_breakout: preset.pa_allow_true_breakout,
      pa_allow_trap: preset.pa_allow_trap,
      pa_require_retest_on_continuation: preset.pa_require_retest_on_continuation,
      pa_retest_soft_score: preset.pa_retest_soft_score,
      pa_retest_soft_bonus: preset.pa_retest_soft_bonus,
      pa_retest_soft_min_score: preset.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: preset.pa_retest_touch_tolerance_atr,
      pa_retest_mode: preset.pa_retest_mode,
      pa_retest_require_candle_color: preset.pa_retest_require_candle_color,
      pa_retest_lookback_bars: preset.pa_retest_lookback_bars,
      pa_retest_reclaim_offset_atr: preset.pa_retest_reclaim_offset_atr,
      pa_dual_tf_resonance: preset.pa_dual_tf_resonance,
      pa_resonance_bias_window_bars: preset.pa_resonance_bias_window_bars,
      pa_resonance_min_score: preset.pa_resonance_min_score,
      pa_resonance_require_key_level: preset.pa_resonance_require_key_level,
      pa_resonance_require_momentum: preset.pa_resonance_require_momentum,
      pa_session_mode: preset.pa_session_mode,
    });
    const latestClosed1h = candles1h[candles1h.length - 2];
    const latestClosed15m = candles15m[candles15m.length - 2];
    return {
      preset,
      signal: extractLatestSignal(preset, result.trades as Array<Record<string, unknown>>, latestClosed1h, latestClosed15m),
    };
  } catch (error) {
    return {
      preset,
      signal: null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function dispatchSignals(state: AlertState, signals: StrategySignal[]): Promise<DispatchResult[]> {
  const results: DispatchResult[] = [];
  for (const signal of signals) {
    const strategyState = state.strategies[signal.preset.key] ?? {};
    if (strategyState.last_alert_key === signal.alert_key) {
      results.push({ preset_key: signal.preset.key, alert_key: signal.alert_key, status: 'duplicate_skip' });
      continue;
    }
    try {
      await sendTelegram(formatTelegramMessage(signal));
      state.strategies[signal.preset.key] = {
        last_alert_key: signal.alert_key,
        last_entry_time: signal.entry_time,
        last_sent_at: nowIso(),
      };
      delete state.last_error_at;
      delete state.last_error_message;
      await saveState(state);
      results.push({ preset_key: signal.preset.key, alert_key: signal.alert_key, status: 'sent', sent_at: state.strategies[signal.preset.key].last_sent_at });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      state.last_error_at = nowIso();
      state.last_error_message = `[dispatch:${signal.preset.key}] ${message}`;
      await saveState(state);
      results.push({ preset_key: signal.preset.key, alert_key: signal.alert_key, status: 'failed', error: message });
    }
  }
  return results;
}

async function runOnce() {
  const state = await ensureRuntimeState();
  const candles1h = await fetchCandles('1h', LOOKBACK_1H);
  const candles1d = await fetchCandles('1d', LOOKBACK_1D);
  const candles15m = await fetchCandles('15m', LOOKBACK_15M);
  const latestClosed1h = candles1h[candles1h.length - 2];
  const latestClosed15m = candles15m[candles15m.length - 2];

  const checks = await Promise.all(BTCUSDT_LIVE_PRESETS.map((preset) => evaluatePreset(preset, candles1h, candles1d, candles15m)));
  const signals = checks
    .map((item) => item.signal)
    .filter((item): item is StrategySignal => item !== null)
    .sort((a, b) => a.signal_time - b.signal_time);
  const strategy_errors = checks
    .filter((item) => item.error)
    .map((item) => ({ preset_key: item.preset.key, label: item.preset.label, error: item.error as string }));

  const dispatch_results = await dispatchSignals(state, signals);
  await saveSnapshot({
    generated_at: nowIso(),
    disabled_legacy_notifiers: true,
    latest_closed_1h: latestClosed1h,
    latest_closed_15m: latestClosed15m,
    active_presets: BTCUSDT_LIVE_PRESETS,
    signals,
    strategy_errors,
    dispatch_results,
    state_overview: state,
  });
  await saveState(state);
  return { count: signals.length, latestClosed1h, latestClosed15m, dispatch_results, strategy_errors };
}

async function main() {
  const mode = process.argv[2] ?? 'once';
  if (mode === 'loop') {
    console.log(`[live-monitor] started at ${nowIso()} interval=${INTERVAL_MS}ms`);
    while (true) {
      try {
        const res = await runOnce();
        console.log(`[live-monitor] checked ${nowIso()} signals=${res.count} dispatched=${res.dispatch_results.filter((x) => x.status === 'sent').length} errors=${res.strategy_errors.length} latest1h=${formatUtc(res.latestClosed1h.time)} latest15m=${formatUtc(res.latestClosed15m.time)}`);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`[live-monitor] ${nowIso()} error`, error);
        const state = await ensureRuntimeState();
        state.last_error_at = nowIso();
        state.last_error_message = `[runOnce] ${message}`;
        await saveState(state);
        await saveSnapshot({
          generated_at: nowIso(),
          disabled_legacy_notifiers: true,
          fatal_error: message,
          state_overview: state,
        });
      }
      await sleep(INTERVAL_MS);
    }
  }
  const res = await runOnce();
  console.log(JSON.stringify({ ok: true, ...res }, null, 2));
}

await main();
