/**
 * search_15m_exec_confirm_1h.ts
 * 15m 執行確認搜索腳本 — 新環境優先級 #2 實驗
 *
 * 目標：在當前新主版本（軟評分 bonus0.5/minscore7.5）基礎上，
 *       引入 15m 級別的微觀執行確認，提升進場精度。
 *
 * 策略：
 *   - 1H PA 信號作為「方向判斷」（主時間框架）
 *   - 15m 作為「進場時機確認」（執行時間框架）
 *   - 使用 use_true_mtf=true + entry_candles=15m + htf_candles=1d
 *
 * 搜索維度：
 *   1. 是否啟用 15m 執行確認（vs 純 1H）
 *   2. 是否同時啟用軟評分（vs 不啟用）
 *   3. pa_min_signal_score 門檻（0 / 6.5 / 7.0 / 7.5）
 *   4. pa_session_mode（all / london_newyork）
 *
 * 基線：新主版本（軟評分 bonus0.5/minscore7.5/touch0.04/same_bar）
 *       胜率 81.1%，PF 1.27，年交易 185，50x P75 保證金損耗 80.53%
 *
 * 作者：Manus AI
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type PaSessionMode = "all" | "exclude_offhours" | "london_newyork";

type Variant = {
  key: string;
  use_15m_entry: boolean;
  pa_retest_soft_score: boolean;
  pa_min_signal_score: number;
  pa_session_mode: PaSessionMode;
};

type Row = {
  variant: string;
  use_15m_entry: boolean;
  pa_retest_soft_score: boolean;
  pa_min_signal_score: number;
  pa_session_mode: PaSessionMode;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_50x_pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_new_baseline_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  composite_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

// 新主版本基線（軟評分扶正後）
const NEW_BASELINE_WIN_RATE = 81.1;
const NEW_BASELINE_PF = 1.27;
const NEW_BASELINE_TRADES = 185;
const NEW_BASELINE_P75_MARGIN_50X = 80.53;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function buildVariants(): Variant[] {
  const sessionModes: PaSessionMode[] = ["all", "london_newyork"];
  const minScores = [0, 6.5, 7.0, 7.5];
  const variants: Variant[] = [];

  // 新主版本基線（1H only，軟評分 on，作為對照）
  variants.push({
    key: "new_baseline_1h_soft_on_session_all_minscore0",
    use_15m_entry: false,
    pa_retest_soft_score: true,
    pa_min_signal_score: 0,
    pa_session_mode: "all",
  });

  // 15m 執行確認實驗
  for (const use_15m_entry of [true, false]) {
    for (const pa_retest_soft_score of [true, false]) {
      for (const pa_min_signal_score of minScores) {
        for (const pa_session_mode of sessionModes) {
          // 跳過已有的基線
          if (!use_15m_entry && pa_retest_soft_score && pa_min_signal_score === 0 && pa_session_mode === "all") continue;
          variants.push({
            key: [
              use_15m_entry ? "15m_entry" : "1h_only",
              pa_retest_soft_score ? "soft_on" : "soft_off",
              `minscore${pa_min_signal_score.toFixed(1)}`,
              `session_${pa_session_mode}`,
            ].join("_"),
            use_15m_entry,
            pa_retest_soft_score,
            pa_min_signal_score,
            pa_session_mode,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

async function main() {
  console.log(`[run] 15m exec confirm search 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  // 15m K 線：需要足夠的歷史（4 * 24 * 365 = 35040 根）
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 4 * 24 * YEAR_DAYS);
  console.log(`[range] 1H: ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[range] 15m: ${isoTime(candles15m[0]?.time)} -> ${isoTime(candles15m[candles15m.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_new_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "composite_score">> = [];

  for (const variant of VARIANTS) {
    // 15m 執行確認模式：以 1H 為 HTF 過濾方向，15m 為進場 K 線
    // 純 1H 模式：以 1D 為 HTF，1H 為進場 K 線
    const result = runBacktest({
      candles: variant.use_15m_entry ? candles15m : candles1h,
      mtf_candles: variant.use_15m_entry ? candles1h : candles1d,
      htf_candles: variant.use_15m_entry ? candles1h : candles1d,
      entry_candles: variant.use_15m_entry ? candles15m : candles1h,
      use_true_mtf: true,
      strategy: "pa",
      symbol: SYMBOL,
      interval: variant.use_15m_entry ? "15m" : "1h",
      atr_sl_mult: BASE_SL,
      atr_tp_mult: BASE_TP,
      enable_mtf_filter: true,
      enable_fee: false,
      enable_trailing_stop: false,
      enable_adx_filter: true,
      pa_allow_pattern: true,
      pa_allow_true_breakout: false,
      pa_allow_trap: true,
      pa_require_retest_on_continuation: false,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_retest_soft_bonus: 0.5,
      pa_retest_soft_min_score: variant.pa_retest_soft_score ? 7.5 : 0,
      pa_retest_touch_tolerance_atr: 0.04,
      pa_retest_mode: "same_bar",
      pa_retest_require_candle_color: true,
      pa_retest_lookback_bars: 20,
      pa_retest_reclaim_offset_atr: 0.03,
      pa_min_signal_score: variant.pa_min_signal_score,
      pa_session_mode: variant.pa_session_mode,
    });

    const stopDistances = result.trades.map(t => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = round(percentile(stopDistances, 0.75), 4);
    const p75MarginLoss50x = round(p75Stop * 50, 2);

    const row = {
      variant: variant.key,
      use_15m_entry: variant.use_15m_entry,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_min_signal_score: variant.pa_min_signal_score,
      pa_session_mode: variant.pa_session_mode,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 1),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net * 100, 2),
      max_drawdown_pct: round(result.max_drawdown * 100, 2),
      p75_stop_distance_pct: p75Stop,
      p75_margin_loss_50x_pct: p75MarginLoss50x,
    };

    console.log(`[done] ${variant.key} trades=${result.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} 50x_p75=${p75MarginLoss50x}%`);
    rowsRaw.push(row);
  }

  const rows: Row[] = rowsRaw.map((row) => {
    const qualified_core_requirements = row.total_trades >= MIN_TRADES && row.profit_factor > 1;
    const high_leverage_guard_ok = row.p75_margin_loss_50x_pct <= 82;
    const beats_new_baseline_winrate = row.win_rate_pct > NEW_BASELINE_WIN_RATE;
    const delta_win_rate_pct = round(row.win_rate_pct - NEW_BASELINE_WIN_RATE, 1);
    const delta_profit_factor = round(row.profit_factor - NEW_BASELINE_PF, 2);
    const delta_total_trades = row.total_trades - NEW_BASELINE_TRADES;
    const composite_score = row.win_rate_pct * 8 + row.profit_factor * 30
      + Math.max(0, row.total_trades - MIN_TRADES) * 0.03
      - Math.max(0, row.p75_margin_loss_50x_pct - NEW_BASELINE_P75_MARGIN_50X) * 1.5
      - Math.max(0, MIN_TRADES - row.total_trades) * 0.3;
    return {
      ...row,
      qualified_core_requirements,
      high_leverage_guard_ok,
      beats_new_baseline_winrate,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      composite_score,
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const qa = Number(b.qualified_core_requirements) - Number(a.qualified_core_requirements);
    if (qa !== 0) return qa;
    const ga = Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok);
    if (ga !== 0) return ga;
    return b.composite_score - a.composite_score;
  });

  const winners = sorted.filter(r => r.qualified_core_requirements && r.high_leverage_guard_ok && r.beats_new_baseline_winrate);
  const top15 = sorted.slice(0, 15);

  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `search_15m_exec_confirm_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_15m_exec_confirm_1h_${SYMBOL}_${ts}.md`);

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    new_baseline_win_rate: NEW_BASELINE_WIN_RATE,
    new_baseline_pf: NEW_BASELINE_PF,
    new_baseline_trades: NEW_BASELINE_TRADES,
    total_variants: VARIANTS.length,
    winners: winners.length,
    rows: sorted,
  }, null, 2));

  const winnerLines = winners.length === 0
    ? "本輪未找到同時滿足「核心頻率要求」、「高杠杆守門線」且「胜率高於新主版本基線」的 15m 執行確認變體。"
    : winners.slice(0, 8).map((row, idx) =>
        `${idx + 1}. **${row.variant}**：胜率 ${row.win_rate_pct}%，PF ${row.profit_factor}，年交易 ${row.total_trades}，50x P75 保證金損耗 ${row.p75_margin_loss_50x_pct}%，Δ胜率 ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct}，Δ交易數 ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades}。`
      ).join("\n");

  const summaryTable = top15.map(row =>
    `| ${row.variant} | ${row.use_15m_entry ? "15m" : "1H"} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.p75_stop_distance_pct}% | ${row.p75_margin_loss_50x_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades} | ${row.qualified_core_requirements ? "yes" : "no"} | ${row.high_leverage_guard_ok ? "yes" : "no"} |`
  ).join("\n");

  const md = `# BTCUSDT 1H 15m 執行確認搜索
作者：**Manus AI**

本輪搜索是新環境第二優先級實驗：在當前新主版本（軟評分 bonus0.5/minscore7.5）基礎上，引入 **15m 級別的微觀執行確認**，提升進場精度。

| 項目 | 數值 |
| --- | ---: |
| Symbol | ${SYMBOL} |
| 新主版本基線胜率 | ${NEW_BASELINE_WIN_RATE}% |
| 新主版本基線 PF | ${NEW_BASELINE_PF} |
| 新主版本基線年交易數 | ${NEW_BASELINE_TRADES} |
| 新主版本基線 50x P75 保證金損耗 | ${NEW_BASELINE_P75_MARGIN_50X}% |
| 搜索變體數 | ${VARIANTS.length} |
| 通過守門並胜率超新基線的候選數 | ${winners.length} |

## 通過守門並且胜率高於新主版本基線的候選

${winnerLines}

## Top 15 結果總表

| Variant | 執行框架 | Trades | Win Rate | PF | P75 Stop | 50x P75 Margin | Δ Win Rate | Δ Trades | Core OK | Guard OK |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
${summaryTable}

## 15m 執行確認機制說明

| 模式 | 說明 |
| --- | --- |
| 1H only | 純 1H PA 信號，以 1D 為 HTF 方向過濾 |
| 15m entry | 以 1H 為方向過濾，15m K 線為進場執行框架 |
| soft_on | 啟用軟評分（bonus0.5 / minscore7.5 / touch0.04） |
| soft_off | 不啟用軟評分 |
| session_all | 全時段交易 |
| session_london_newyork | 僅倫敦 + 紐約時段 |

## 核心守門條件

| 條件 | 門檻 |
| --- | --- |
| 核心頻率要求 | 年交易數 ≥ ${MIN_TRADES} 且 PF > 1 |
| 高杠杆守門線 | 50x P75 保證金損耗 ≤ 82% |
| 胜率超新基線 | 胜率 > ${NEW_BASELINE_WIN_RATE}% |

## 輸出文件

| 文件 | 路徑 |
| --- | --- |
| JSON | ${jsonPath} |
| Markdown | ${mdPath} |
`;

  await fs.writeFile(mdPath, md);
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
  console.log(`[winners] ${winners.length} 個候選通過所有守門條件`);
}

main().catch((err) => {
  console.error("[error]", err);
  process.exit(1);
});
