import fs from "node:fs";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

type Combo = {
  name: string;
  entryInterval: "15m" | "1h";
  trendInterval: "4h" | "1d";
  entryCount: number;
  trendCount: number;
};

type Variant = {
  key: string;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_trailing_stop: boolean;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
};

type Row = {
  combo: string;
  strategy: string;
  variant: string;
  total_trades: number;
  trades_per_2d: number;
  win_rate: number;
  profit_factor: number;
  total_return_net: number;
  sharpe_ratio: number;
  max_drawdown: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);

const COMBOS: Combo[] = [
  { name: "4H+15m", entryInterval: "15m", trendInterval: "4h", entryCount: 96 * YEAR_DAYS, trendCount: 6 * YEAR_DAYS },
  { name: "1D+1h", entryInterval: "1h", trendInterval: "1d", entryCount: 24 * YEAR_DAYS, trendCount: YEAR_DAYS },
];

const STRATEGIES: BacktestStrategy[] = [
  "macd",
  "pa",
  "composite",
  "cannonball",
  "hwr_model_a",
  "hwr_model_b",
  "bollinger",
  "chan",
  "liquidity_sweep",
  "hwr_model_c",
];

const VARIANTS: Variant[] = [
  { key: "sl1.5_tp1.0_trailOff_mtfOn_adxOff", atr_sl_mult: 1.5, atr_tp_mult: 1.0, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl1.5_tp0.75_trailOff_mtfOn_adxOff", atr_sl_mult: 1.5, atr_tp_mult: 0.75, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.0_tp1.0_trailOff_mtfOn_adxOff", atr_sl_mult: 2.0, atr_tp_mult: 1.0, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.0_tp0.75_trailOff_mtfOn_adxOff", atr_sl_mult: 2.0, atr_tp_mult: 0.75, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.5_tp1.0_trailOff_mtfOn_adxOff", atr_sl_mult: 2.5, atr_tp_mult: 1.0, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.5_tp0.75_trailOff_mtfOn_adxOff", atr_sl_mult: 2.5, atr_tp_mult: 0.75, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.0_tp0.5_trailOff_mtfOn_adxOff", atr_sl_mult: 2.0, atr_tp_mult: 0.5, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.5_tp0.5_trailOff_mtfOn_adxOff", atr_sl_mult: 2.5, atr_tp_mult: 0.5, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl3.0_tp0.5_trailOff_mtfOn_adxOff", atr_sl_mult: 3.0, atr_tp_mult: 0.5, enable_trailing_stop: false, enable_mtf_filter: true, enable_adx_filter: false },
  { key: "sl2.0_tp0.5_trailOff_mtfOff_adxOff", atr_sl_mult: 2.0, atr_tp_mult: 0.5, enable_trailing_stop: false, enable_mtf_filter: false, enable_adx_filter: false },
  { key: "sl2.5_tp0.5_trailOff_mtfOff_adxOff", atr_sl_mult: 2.5, atr_tp_mult: 0.5, enable_trailing_stop: false, enable_mtf_filter: false, enable_adx_filter: false },
];

function isoTime(value: number | undefined): string {
  if (!value) return "";
  return new Date(value * 1000).toISOString();
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every((n) => Number.isFinite(n))) return null;
  return { time, open, high, low, close, volume };
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  let page = 0;

  while (candles.length < targetCount) {
    page += 1;
    const params = new URLSearchParams({
      symbol,
      interval,
      limit: String(PAGE_LIMIT),
      endTime: String(endTime),
    });

    const res = await fetch(`${BINANCE_KLINES_URL}?${params.toString()}`, {
      headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
      signal: AbortSignal.timeout(20_000),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Binance ${interval} K 線抓取失敗：HTTP ${res.status} ${text.slice(0, 200)}`);
    }

    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;

    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);

    const earliestExisting = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const uniqueBatch = candles.length === 0 ? batch : batch.filter((c) => c.time < earliestExisting);
    if (uniqueBatch.length === 0) break;

    candles.unshift(...uniqueBatch);
    endTime = Number(payload[0][0]) - 1;
    console.log(`[fetch] ${interval} 第 ${page} 頁，累計 ${candles.length} 根`);
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }

  return candles.slice(-targetCount);
}

async function main() {
  const allRows: Row[] = [];
  const rawResults: Array<Row & { trades: unknown[] }> = [];

  for (const combo of COMBOS) {
    console.log(`\n[combo] ${combo.name}`);
    const entryCandles = await fetchBinanceCandles(SYMBOL, combo.entryInterval, combo.entryCount);
    const trendCandles = await fetchBinanceCandles(SYMBOL, combo.trendInterval, combo.trendCount);
    console.log(`[range] ${combo.name} ${isoTime(entryCandles[0]?.time)} -> ${isoTime(entryCandles[entryCandles.length - 1]?.time)}`);

    for (const strategy of STRATEGIES) {
      console.log(`\n[strategy] ${combo.name} / ${strategy}`);
      for (const variant of VARIANTS) {
        const result = runBacktest({
          candles: entryCandles,
          strategy,
          symbol: SYMBOL,
          interval: combo.entryInterval,
          atr_sl_mult: variant.atr_sl_mult,
          atr_tp_mult: variant.atr_tp_mult,
          enable_mtf_filter: variant.enable_mtf_filter,
          enable_fee: true,
          enable_trailing_stop: variant.enable_trailing_stop,
          enable_adx_filter: variant.enable_adx_filter,
          htf_candles: trendCandles,
          entry_candles: entryCandles,
          use_true_mtf: true,
        });

        const row: Row = {
          combo: combo.name,
          strategy,
          variant: variant.key,
          total_trades: result.total_trades,
          trades_per_2d: Number((result.total_trades / (YEAR_DAYS / 2)).toFixed(2)),
          win_rate: Number((result.win_rate * 100).toFixed(2)),
          profit_factor: Number(result.profit_factor.toFixed(2)),
          total_return_net: Number(result.total_return_net.toFixed(4)),
          sharpe_ratio: Number(result.sharpe_ratio.toFixed(2)),
          max_drawdown: Number(result.max_drawdown.toFixed(4)),
        };

        allRows.push(row);
        rawResults.push({ ...row, trades: result.trades });
        console.log(`[done] ${strategy}/${variant.key} trades=${row.total_trades} win=${row.win_rate}% net=${row.total_return_net}%`);
      }
    }
  }

  const ranked = [...allRows].sort((a, b) => {
    if (b.win_rate !== a.win_rate) return b.win_rate - a.win_rate;
    if (b.total_trades !== a.total_trades) return b.total_trades - a.total_trades;
    return b.total_return_net - a.total_return_net;
  });

  const qualified = ranked.filter((row) => row.total_trades >= MIN_TRADES && row.win_rate >= 75);
  const nearMiss = ranked.filter((row) => row.total_trades >= MIN_TRADES).slice(0, 30);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_high_freq_high_winrate_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_high_freq_high_winrate_${SYMBOL}_${ts}.md`);

  fs.writeFileSync(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    min_trades_required: MIN_TRADES,
    combos: COMBOS,
    strategies: STRATEGIES,
    variants: VARIANTS,
    qualified,
    near_miss: nearMiss,
    all_rows: ranked,
    raw_results: rawResults,
  }, null, 2));

  const qualifiedMd = qualified.length > 0
    ? qualified.map((row, idx) => `| ${idx + 1} | ${row.combo} | ${row.strategy} | ${row.variant} | ${row.total_trades} | ${row.trades_per_2d} | ${row.win_rate}% | ${row.profit_factor} | ${row.total_return_net}% | ${row.sharpe_ratio} | ${row.max_drawdown}% |`).join("\n")
    : "| 無 | 無 | 無 | 無 | 0 | 0 | 0% | 0 | 0% | 0 | 0% |";

  const nearMissMd = nearMiss.map((row, idx) => `| ${idx + 1} | ${row.combo} | ${row.strategy} | ${row.variant} | ${row.total_trades} | ${row.trades_per_2d} | ${row.win_rate}% | ${row.profit_factor} | ${row.total_return_net}% | ${row.sharpe_ratio} | ${row.max_drawdown}% |`).join("\n");

  const markdown = `# ${SYMBOL} 高頻高勝率門檻搜尋\n\n本報告以 **${SYMBOL}** 為標的，搜尋 **至少每兩天一筆交易**（一年至少 ${MIN_TRADES} 筆）且 **勝率至少 75%** 的候選配置。測試範圍同時覆蓋 **4H+15m** 與 **1D+1h** 兩種多時間框架組合，並針對高頻候選策略測試多組較偏向高命中率的 ATR 止盈止損參數。行情資料使用 Binance 公開 K 線端點 [1]。\n\n| 項目 | 值 |\n| --- | --- |\n| 標的 | ${SYMBOL} |\n| 最低交易數門檻 | ${MIN_TRADES} |\n| 勝率門檻 | 75% |\n| 測試框架 | 4H+15m、1D+1h |\n| 策略數 | ${STRATEGIES.length} |\n| 參數變體數 | ${VARIANTS.length} |\n| 符合門檻組合數 | ${qualified.length} |\n\n如果最終沒有任何組合同時滿足兩個硬性條件，代表在目前這批策略與這一輪參數空間下，**交易頻率** 與 **勝率** 之間仍存在明顯張力。這時更合理的下一步通常不是只繼續微調 TP/SL，而是回到訊號定義本身，重新設計更偏向均值回歸或超短波段的進場邏輯。\n\n## 符合硬性門檻的結果\n\n| 排名 | 框架 | 策略 | 變體 | 年交易數 | 每兩天交易數 | 勝率 | Profit Factor | 淨報酬 | Sharpe | 最大回撤 |\n| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${qualifiedMd}\n\n## 最接近門檻的高頻結果\n\n| 排名 | 框架 | 策略 | 變體 | 年交易數 | 每兩天交易數 | 勝率 | Profit Factor | 淨報酬 | Sharpe | 最大回撤 |\n| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${nearMissMd}\n\n## References\n\n[1]: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data \"Binance Spot API Docs - Kline/Candlestick data\"\n`;

  fs.writeFileSync(mdPath, markdown);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD: ${mdPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
