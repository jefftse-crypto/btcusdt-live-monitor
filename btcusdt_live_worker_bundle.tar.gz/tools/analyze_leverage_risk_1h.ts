import fs from "node:fs";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
};

type LeverageLevel = 20 | 30 | 50;

type LeverageScenario = {
  leverage: LeverageLevel;
  median_stop_margin_loss_pct: number;
  p75_stop_margin_loss_pct: number;
  p90_stop_margin_loss_pct: number;
  p95_stop_margin_loss_pct: number;
  worst_trade_margin_loss_pct: number;
  est_full_equity_dd_pct: number;
  est_loss_streak_dd_pct: number;
  recommended_max_margin_fraction_pct_for_0_5pct_risk: number;
  recommended_max_margin_fraction_pct_for_1pct_risk: number;
  recommended_max_margin_fraction_pct_for_2pct_risk: number;
};

type Row = {
  variant: string;
  atr_sl_mult: number;
  atr_tp_mult: number;
  total_trades: number;
  win_rate_pct: number;
  trades_per_2d: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  avg_stop_distance_pct: number;
  median_stop_distance_pct: number;
  p75_stop_distance_pct: number;
  p90_stop_distance_pct: number;
  p95_stop_distance_pct: number;
  worst_trade_pct: number;
  avg_loss_pct: number;
  max_loss_streak: number;
  leverage_20: LeverageScenario;
  leverage_30: LeverageScenario;
  leverage_50: LeverageScenario;
  leverage_fit_score: number;
  qualified_core_requirements: boolean;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const MIN_WIN_RATE = 75;
const LEVERAGES: LeverageLevel[] = [20, 30, 50];
const BASELINE = { atr_sl_mult: 3.0, atr_tp_mult: 0.24 };
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function buildVariants(): Variant[] {
  const sls = [1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75, 3.0];
  const tps = [0.18, 0.2, 0.22, 0.24, 0.26];
  const variants: Variant[] = [];
  for (const sl of sls) {
    for (const tp of tps) {
      variants.push({
        key: `pa_sl${sl.toFixed(2)}_tp${tp.toFixed(2)}_mtfOn_adxOn_tsOff`,
        strategy: "pa",
        atr_sl_mult: sl,
        atr_tp_mult: tp,
        enable_mtf_filter: true,
        enable_adx_filter: true,
        enable_trailing_stop: false,
      });
    }
  }
  return variants;
}

const VARIANTS = buildVariants();

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function maxConsecutiveLosses(pnls: number[]): number {
  let streak = 0;
  let maxStreak = 0;
  for (const pnl of pnls) {
    if (pnl < 0) {
      streak += 1;
      if (streak > maxStreak) maxStreak = streak;
    } else {
      streak = 0;
    }
  }
  return maxStreak;
}

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function calcMarginFractionForRiskBudget(riskBudgetPct: number, leverage: number, stopDistancePct: number): number {
  if (leverage <= 0 || stopDistancePct <= 0) return 0;
  return Math.min(100, (riskBudgetPct / (leverage * stopDistancePct)) * 100);
}

function calcLeverageScenario(leverage: LeverageLevel, stats: {
  medianStopPct: number;
  p75StopPct: number;
  p90StopPct: number;
  p95StopPct: number;
  worstTradePct: number;
  avgLossPct: number;
  maxLossStreak: number;
  maxDrawdownPct: number;
}): LeverageScenario {
  const lossMultiplier = leverage;
  const estFullEquityDdPct = stats.maxDrawdownPct * lossMultiplier;
  const estLossStreakDdPct = Math.abs(stats.avgLossPct) * lossMultiplier * stats.maxLossStreak;
  return {
    leverage,
    median_stop_margin_loss_pct: round(stats.medianStopPct * leverage, 2),
    p75_stop_margin_loss_pct: round(stats.p75StopPct * leverage, 2),
    p90_stop_margin_loss_pct: round(stats.p90StopPct * leverage, 2),
    p95_stop_margin_loss_pct: round(stats.p95StopPct * leverage, 2),
    worst_trade_margin_loss_pct: round(Math.abs(stats.worstTradePct) * leverage, 2),
    est_full_equity_dd_pct: round(estFullEquityDdPct, 2),
    est_loss_streak_dd_pct: round(estLossStreakDdPct, 2),
    recommended_max_margin_fraction_pct_for_0_5pct_risk: round(calcMarginFractionForRiskBudget(0.5, leverage, stats.p75StopPct), 2),
    recommended_max_margin_fraction_pct_for_1pct_risk: round(calcMarginFractionForRiskBudget(1.0, leverage, stats.p75StopPct), 2),
    recommended_max_margin_fraction_pct_for_2pct_risk: round(calcMarginFractionForRiskBudget(2.0, leverage, stats.p75StopPct), 2),
  };
}

function leverageFitScore(row: Omit<Row, "leverage_fit_score" | "qualified_core_requirements">): number {
  const coreOk = row.total_trades >= MIN_TRADES && row.win_rate_pct >= MIN_WIN_RATE && row.profit_factor > 1;
  if (!coreOk) return -999;

  const reward =
    (row.win_rate_pct - 75) * 1.2 +
    (row.profit_factor - 1) * 60 +
    Math.max(0, row.total_trades - MIN_TRADES) * 0.03;

  const penalty =
    row.leverage_20.p75_stop_margin_loss_pct * 0.25 +
    row.leverage_30.p75_stop_margin_loss_pct * 0.2 +
    row.leverage_50.p75_stop_margin_loss_pct * 0.15 +
    row.leverage_50.est_loss_streak_dd_pct * 0.15 +
    row.avg_stop_distance_pct * 5;

  return round(reward - penalty, 2);
}

async function main() {
  console.log(`[run] analyze leverage risk 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);

  const rows: Row[] = [];
  for (const variant of VARIANTS) {
    const r = runBacktest({
      candles: candles1h,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_fee: true,
      enable_trailing_stop: variant.enable_trailing_stop,
      enable_adx_filter: variant.enable_adx_filter,
      htf_candles: candles1d,
      entry_candles: candles1h,
      use_true_mtf: true,
    });

    const stopDistances = r.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const lossPnls = r.trades.filter((t) => t.pnl_net_pct < 0).map((t) => Math.abs(t.pnl_net_pct) * 100);
    const worstTradePct = Math.min(...r.trades.map((t) => t.pnl_net_pct * 100), 0);
    const maxLossStreak = maxConsecutiveLosses(r.trades.map((t) => t.pnl_net_pct));
    const stats = {
      medianStopPct: percentile(stopDistances, 0.5),
      p75StopPct: percentile(stopDistances, 0.75),
      p90StopPct: percentile(stopDistances, 0.9),
      p95StopPct: percentile(stopDistances, 0.95),
      worstTradePct,
      avgLossPct: mean(lossPnls),
      maxLossStreak,
      maxDrawdownPct: r.max_drawdown,
    };

    const baseRow = {
      variant: variant.key,
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      total_trades: r.total_trades,
      win_rate_pct: round(r.win_rate * 100, 2),
      trades_per_2d: round(r.total_trades / (YEAR_DAYS / 2), 2),
      profit_factor: round(r.profit_factor, 2),
      total_return_net_pct: round(r.total_return_net, 4),
      max_drawdown_pct: round(r.max_drawdown, 4),
      avg_stop_distance_pct: round(mean(stopDistances), 4),
      median_stop_distance_pct: round(stats.medianStopPct, 4),
      p75_stop_distance_pct: round(stats.p75StopPct, 4),
      p90_stop_distance_pct: round(stats.p90StopPct, 4),
      p95_stop_distance_pct: round(stats.p95StopPct, 4),
      worst_trade_pct: round(worstTradePct, 4),
      avg_loss_pct: round(mean(lossPnls), 4),
      max_loss_streak: maxLossStreak,
      leverage_20: calcLeverageScenario(20, stats),
      leverage_30: calcLeverageScenario(30, stats),
      leverage_50: calcLeverageScenario(50, stats),
    };

    const row: Row = {
      ...baseRow,
      leverage_fit_score: leverageFitScore(baseRow),
      qualified_core_requirements: baseRow.total_trades >= MIN_TRADES && baseRow.win_rate_pct >= MIN_WIN_RATE && baseRow.profit_factor > 1,
    };

    rows.push(row);
    console.log(`[done] ${row.variant} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} p75_stop=${row.p75_stop_distance_pct}% score=${row.leverage_fit_score}`);
  }

  const qualified = rows
    .filter((row) => row.qualified_core_requirements)
    .sort((a, b) => b.leverage_fit_score - a.leverage_fit_score || a.p75_stop_distance_pct - b.p75_stop_distance_pct || b.profit_factor - a.profit_factor || b.win_rate_pct - a.win_rate_pct);

  const baseline = rows.find((row) => row.atr_sl_mult === BASELINE.atr_sl_mult && row.atr_tp_mult === BASELINE.atr_tp_mult) ?? null;
  const safer = qualified.filter((row) => row.atr_sl_mult <= 2.5);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `analyze_leverage_risk_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `analyze_leverage_risk_1h_${SYMBOL}_${ts}.md`);

  const summary = {
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    range: {
      start: isoTime(candles1h[0]?.time),
      end: isoTime(candles1h[candles1h.length - 1]?.time),
    },
    constraints: {
      min_trades: MIN_TRADES,
      min_win_rate_pct: MIN_WIN_RATE,
      leverages: LEVERAGES,
    },
    baseline_variant: baseline,
    best_high_leverage_fits: qualified.slice(0, 12),
    narrower_stop_candidates: safer.slice(0, 12),
    all_rows: rows,
  };
  fs.writeFileSync(jsonPath, JSON.stringify(summary, null, 2));

  const topRows = qualified.slice(0, 10).map((row, idx) => `| ${idx + 1} | ${row.variant} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.avg_stop_distance_pct}% | ${row.p75_stop_distance_pct}% | ${row.leverage_20.p75_stop_margin_loss_pct}% | ${row.leverage_30.p75_stop_margin_loss_pct}% | ${row.leverage_50.p75_stop_margin_loss_pct}% | ${row.leverage_20.recommended_max_margin_fraction_pct_for_1pct_risk}% | ${row.leverage_fit_score} |`).join("\n");
  const saferRows = safer.slice(0, 10).map((row, idx) => `| ${idx + 1} | ${row.variant} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.avg_stop_distance_pct}% | ${row.p75_stop_distance_pct}% | ${row.leverage_20.p75_stop_margin_loss_pct}% | ${row.leverage_30.p75_stop_margin_loss_pct}% | ${row.leverage_50.p75_stop_margin_loss_pct}% |`).join("\n") || "| 1 | 無符合條件候選 | 0 | 0% | 0 | 0% | 0% | 0% | 0% | 0% |";

  const baselineText = baseline
    ? `| ${baseline.variant} | ${baseline.total_trades} | ${baseline.win_rate_pct}% | ${baseline.profit_factor} | ${baseline.avg_stop_distance_pct}% | ${baseline.p75_stop_distance_pct}% | ${baseline.leverage_20.p75_stop_margin_loss_pct}% | ${baseline.leverage_30.p75_stop_margin_loss_pct}% | ${baseline.leverage_50.p75_stop_margin_loss_pct}% | ${baseline.leverage_20.recommended_max_margin_fraction_pct_for_1pct_risk}% | ${baseline.leverage_30.recommended_max_margin_fraction_pct_for_1pct_risk}% | ${baseline.leverage_50.recommended_max_margin_fraction_pct_for_1pct_risk}% |`
    : "| 無 | 0 | 0% | 0 | 0% | 0% | 0% | 0% | 0% | 0% | 0% | 0% |";

  const md = `# ${SYMBOL} 1H 高槓桿風控適配分析

本報告以目前最佳 1 小時 **PA + 1D 趨勢過濾 + ADX 過濾** 架構為基礎，重新評估在 **20x、30x、50x** 槓桿下的止損壓力、連續虧損回撤風險與建議倉位比例。分析同時掃描更窄的 ATR 止損與更低目標止盈組合，檢查是否存在更適合高槓桿的候選版本。

| 項目 | 值 |
| --- | --- |
| 標的 | ${SYMBOL} |
| 分析週期 | 近一年 1H / 1D |
| 核心門檻 | 年交易數 >= ${MIN_TRADES}，勝率 >= ${MIN_WIN_RATE}%，PF > 1 |
| 掃描組合數 | ${VARIANTS.length} |
| 槓桿情境 | ${LEVERAGES.join("x / ")}x |

## 基準策略在高槓桿下的壓力概況

| 基準變體 | 年交易數 | 勝率 | PF | 平均止損距離 | P75 止損距離 | 20x P75 保證金損耗 | 30x P75 保證金損耗 | 50x P75 保證金損耗 | 20x 建議最大保證金倉位比（1% 固定風險） | 30x 建議最大保證金倉位比（1% 固定風險） | 50x 建議最大保證金倉位比（1% 固定風險） |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
${baselineText}

報告中的 **保證金損耗** 是以「若單筆止損完全打滿，該筆名義部位對所投入保證金的損失比例」做估算，因此可以直接用來判斷在高槓桿下止損是否過寬。當該數值接近或超過 100% 時，代表若使用過高的保證金投入比例，實盤會非常接近不可承受區間。

## 綜合門檻與高槓桿適配分數後的前十名候選

| 排名 | 變體 | 年交易數 | 勝率 | PF | 平均止損距離 | P75 止損距離 | 20x P75 保證金損耗 | 30x P75 保證金損耗 | 50x P75 保證金損耗 | 20x 建議最大保證金倉位比（1% 固定風險） | 適配分數 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
${topRows || "| 1 | 無符合條件候選 | 0 | 0% | 0 | 0% | 0% | 0% | 0% | 0% | 0% | 0 |"}

## 更窄止損版本的候選觀察（SL <= 2.5 ATR）

| 排名 | 變體 | 年交易數 | 勝率 | PF | 平均止損距離 | P75 止損距離 | 20x P75 保證金損耗 | 30x P75 保證金損耗 | 50x P75 保證金損耗 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
${saferRows}

## 計算口徑說明

本分析以回測輸出的實際交易為基礎，逐筆計算 **止損距離占入場價比例**，再乘以不同槓桿倍數，以估算該筆交易若止損時對保證金的壓力。固定風險倉位比例則以 **風險預算 ÷（槓桿 × P75 止損距離）** 估算，因此數值越小，代表該策略越需要保守的保證金投入。這種算法不是交易所的精確強平公式，但足以用來比較不同策略在高槓桿下的相對可用性。

## References

[1]: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data "Binance Spot API Docs - Kline/Candlestick data"
[2]: https://www.binance.com/en/blog/futures/3319141945917512624 "What is the Liquidation Price in Crypto Futures Trading? Liquidation Price vs. Bankruptcy Price"
[3]: https://www.binance.com/en/support/faq/detail/360033162192 "Leverage and Margin of USDⓈ-M Futures"
`;
  fs.writeFileSync(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD: ${mdPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
