import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
};

type Row = {
  variant: string;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_50x_pct: number;
  atr_sl_mult: number;
  atr_tp_mult: number;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
  beats_baseline_win: boolean;
  beats_baseline_trades: boolean;
  beats_baseline_both: boolean;
  guard_ok: boolean;
  delta_win_rate_pct: number;
  delta_total_trades: number;
  score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const BASELINE = {
  variant: "pa_sl1.95_tp0.21_pattern_on_breakout_off_trap_on_retest_on_lb24_touch0.04_reclaim0.04_same_bar_color_on",
  win_rate_pct: 83.1,
  total_trades: 71,
};

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function buildVariants(): Variant[] {
  const sls = [1.75, 1.85, 1.95, 2.05];
  const tps = [0.17, 0.19, 0.21, 0.23, 0.25];
  const lookbacks = [12, 16, 20, 24];
  const touches = [0.04, 0.08];
  const reclaims = [0.03, 0.04, 0.05];
  const modes: RetestMode[] = ["same_bar", "either"];
  const requireColors = [true, false];
  const variants: Variant[] = [];

  for (const atr_sl_mult of sls) {
    for (const atr_tp_mult of tps) {
      for (const pa_retest_lookback_bars of lookbacks) {
        for (const pa_retest_touch_tolerance_atr of touches) {
          for (const pa_retest_reclaim_offset_atr of reclaims) {
            for (const pa_retest_mode of modes) {
              for (const pa_retest_require_candle_color of requireColors) {
                variants.push({
                  key: [
                    "pa",
                    `sl${atr_sl_mult.toFixed(2)}`,
                    `tp${atr_tp_mult.toFixed(2)}`,
                    "pattern_on",
                    "breakout_off",
                    "trap_on",
                    "retest_on",
                    `lb${pa_retest_lookback_bars}`,
                    `touch${pa_retest_touch_tolerance_atr.toFixed(2)}`,
                    `reclaim${pa_retest_reclaim_offset_atr.toFixed(2)}`,
                    pa_retest_mode,
                    pa_retest_require_candle_color ? "color_on" : "color_off",
                  ].join("_"),
                  strategy: "pa",
                  atr_sl_mult,
                  atr_tp_mult,
                  enable_mtf_filter: true,
                  enable_adx_filter: true,
                  enable_trailing_stop: false,
                  pa_allow_pattern: true,
                  pa_allow_true_breakout: false,
                  pa_allow_trap: true,
                  pa_require_retest_on_continuation: true,
                  pa_retest_lookback_bars,
                  pa_retest_touch_tolerance_atr,
                  pa_retest_reclaim_offset_atr,
                  pa_retest_mode,
                  pa_retest_require_candle_color,
                });
              }
            }
          }
        }
      }
    }
  }

  return variants;
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function calcScore(row: Omit<Row, "beats_baseline_win" | "beats_baseline_trades" | "beats_baseline_both" | "guard_ok" | "delta_win_rate_pct" | "delta_total_trades" | "score">): number {
  return round(
    row.win_rate_pct * 7
      + row.total_trades * 0.22
      + row.profit_factor * 24
      + row.total_return_net_pct * 1.3
      - row.max_drawdown_pct * 2.2
      - Math.max(0, row.p75_margin_loss_50x_pct - 88) * 0.8,
    2,
  );
}

async function evaluateVariant(candles1h: Candle[], candles1d: Candle[], variant: Variant) {
  const result = runBacktest({
    candles: candles1h,
    strategy: variant.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: variant.atr_sl_mult,
    atr_tp_mult: variant.atr_tp_mult,
    enable_mtf_filter: variant.enable_mtf_filter,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: variant.enable_adx_filter,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: variant.pa_allow_pattern,
    pa_allow_true_breakout: variant.pa_allow_true_breakout,
    pa_allow_trap: variant.pa_allow_trap,
    pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
    pa_retest_mode: variant.pa_retest_mode,
    pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
  });

  const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
  const p75 = percentile(stopDistances, 0.75);

  return {
    variant: variant.key,
    total_trades: result.total_trades,
    trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
    win_rate_pct: round(result.win_rate * 100, 2),
    profit_factor: round(result.profit_factor, 3),
    total_return_net_pct: round(result.total_return_net * 100, 3),
    max_drawdown_pct: round(result.max_drawdown * 100, 3),
    p75_stop_distance_pct: round(p75, 4),
    p75_margin_loss_50x_pct: round(p75 * 50, 2),
    atr_sl_mult: variant.atr_sl_mult,
    atr_tp_mult: variant.atr_tp_mult,
    pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
    pa_retest_mode: variant.pa_retest_mode,
    pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
  };
}

async function main() {
  const variants = buildVariants();
  console.log(`[run] improve win+trades ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${variants.length}`);

  const rowsRaw: Array<Omit<Row, "beats_baseline_win" | "beats_baseline_trades" | "beats_baseline_both" | "guard_ok" | "delta_win_rate_pct" | "delta_total_trades" | "score">> = [];
  for (const variant of variants) {
    const row = await evaluateVariant(candles1h, candles1d, variant);
    rowsRaw.push(row);
    console.log(`[done] ${variant.key} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} ret=${row.total_return_net_pct}%`);
  }

  const rows: Row[] = rowsRaw.map((row) => {
    const beats_baseline_win = row.win_rate_pct > BASELINE.win_rate_pct;
    const beats_baseline_trades = row.total_trades > BASELINE.total_trades;
    const beats_baseline_both = beats_baseline_win && beats_baseline_trades;
    const guard_ok = row.profit_factor >= 1 && row.total_return_net_pct > 0;
    const delta_win_rate_pct = round(row.win_rate_pct - BASELINE.win_rate_pct, 2);
    const delta_total_trades = row.total_trades - BASELINE.total_trades;
    return {
      ...row,
      beats_baseline_win,
      beats_baseline_trades,
      beats_baseline_both,
      guard_ok,
      delta_win_rate_pct,
      delta_total_trades,
      score: calcScore(row),
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const both = Number(b.beats_baseline_both) - Number(a.beats_baseline_both);
    if (both !== 0) return both;
    const guard = Number(b.guard_ok) - Number(a.guard_ok);
    if (guard !== 0) return guard;
    if (b.win_rate_pct !== a.win_rate_pct) return b.win_rate_pct - a.win_rate_pct;
    if (b.total_trades !== a.total_trades) return b.total_trades - a.total_trades;
    if (b.profit_factor !== a.profit_factor) return b.profit_factor - a.profit_factor;
    return b.score - a.score;
  });

  const pareto = sorted.filter((row, idx, arr) => !arr.some((other, j) => j !== idx && other.win_rate_pct >= row.win_rate_pct && other.total_trades >= row.total_trades && (other.win_rate_pct > row.win_rate_pct || other.total_trades > row.total_trades) && other.guard_ok));
  const improvedBoth = sorted.filter((row) => row.beats_baseline_both && row.guard_ok);
  const topRows = sorted.slice(0, 20);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_retest_improve_win_trades_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_retest_improve_win_trades_${SYMBOL}_${ts}.md`);

  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    baseline: BASELINE,
    improved_both: improvedBoth,
    pareto_frontier: pareto.slice(0, 20),
    top_rows: topRows,
    rows: sorted,
  }, null, 2), "utf8");

  const summaryTable = topRows.map((row) =>
    `| ${row.variant} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.total_return_net_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades} | ${row.guard_ok ? "yes" : "no"} | ${row.beats_baseline_both ? "yes" : "no"} |`
  ).join("\n");

  const md = `# BTCUSDT 1H 回踩策略：提升交易量与胜率的定向搜索\n\n作者：**Manus AI**\n\n本轮搜索围绕当前重跑后最优高胜率子集继续做定向扩展，目标不是单纯追求更高胜率或更高频率，而是优先寻找**同时提高胜率与交易量**的组合。\n\n| 项目 | 数值 |\n| --- | ---: |\n| Symbol | ${SYMBOL} |\n| 基线版本 | ${BASELINE.variant} |\n| 基线胜率 | ${BASELINE.win_rate_pct}% |\n| 基线年交易数 | ${BASELINE.total_trades} |\n| 搜索变体数 | ${variants.length} |\n| 同时优于基线的候选数 | ${improvedBoth.length} |\n\n## Top 结果\n\n| Variant | Trades | Win Rate | PF | Net Return | Δ Win | Δ Trades | Guard OK | Beat Both |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |\n${summaryTable}\n\n## 输出文件\n\n| 文件 | 路径 |\n| --- | --- |\n| JSON | ${jsonPath} |\n| Markdown | ${mdPath} |\n`; 

  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
