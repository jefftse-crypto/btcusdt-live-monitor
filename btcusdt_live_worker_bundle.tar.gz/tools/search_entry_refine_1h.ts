import fs from "node:fs";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type PaSessionMode = "all" | "exclude_offhours" | "london_newyork";
type PaRsiGateMode = "off" | "avoid_reject" | "pass_only";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_min_signal_score: number;
  pa_session_mode: PaSessionMode;
  pa_rsi_gate: PaRsiGateMode;
  pa_allow_trap: boolean;
};

type Row = {
  variant: string;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_min_signal_score: number;
  pa_session_mode: PaSessionMode;
  pa_rsi_gate: PaRsiGateMode;
  pa_allow_trap: boolean;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  avg_stop_distance_pct: number;
  median_stop_distance_pct: number;
  p75_stop_distance_pct: number;
  p90_stop_distance_pct: number;
  worst_trade_pct: number;
  avg_loss_pct: number;
  max_loss_streak: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_baseline_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  delta_p75_stop_distance_pct: number;
  entry_quality_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function buildVariants(): Variant[] {
  const minScores = [0, 6.0, 6.5, 7.0];
  const sessionModes: PaSessionMode[] = ["all", "exclude_offhours", "london_newyork"];
  const rsiGates: PaRsiGateMode[] = ["off", "avoid_reject", "pass_only"];
  const allowTrapOptions = [true, false];
  const variants: Variant[] = [];

  for (const pa_min_signal_score of minScores) {
    for (const pa_session_mode of sessionModes) {
      for (const pa_rsi_gate of rsiGates) {
        for (const pa_allow_trap of allowTrapOptions) {
          variants.push({
            key: [
              `pa_sl${BASE_SL.toFixed(2)}`,
              `tp${BASE_TP.toFixed(2)}`,
              `score${pa_min_signal_score.toFixed(1)}`,
              `session_${pa_session_mode}`,
              `rsi_${pa_rsi_gate}`,
              pa_allow_trap ? "trap_on" : "trap_off",
            ].join("_"),
            strategy: "pa",
            atr_sl_mult: BASE_SL,
            atr_tp_mult: BASE_TP,
            enable_mtf_filter: true,
            enable_adx_filter: true,
            enable_trailing_stop: false,
            pa_min_signal_score,
            pa_session_mode,
            pa_rsi_gate,
            pa_allow_trap,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();
const BASELINE_KEY = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_score0.0_session_all_rsi_off_trap_on`;

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K 線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function maxConsecutiveLosses(pnls: number[]): number {
  let streak = 0;
  let maxStreak = 0;
  for (const pnl of pnls) {
    if (pnl < 0) {
      streak += 1;
      if (streak > maxStreak) maxStreak = streak;
    } else {
      streak = 0;
    }
  }
  return maxStreak;
}

function calcMarginFractionForRiskBudget(riskBudgetPct: number, leverage: number, stopDistancePct: number): number {
  if (leverage <= 0 || stopDistancePct <= 0) return 0;
  return Math.min(100, (riskBudgetPct / (leverage * stopDistancePct)) * 100);
}

function calcEntryQualityScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_p75_stop_distance_pct" | "entry_quality_score">): number {
  const reward = row.win_rate_pct * 5.5 + row.profit_factor * 30 + Math.max(0, row.total_trades - MIN_TRADES) * 0.03;
  const penalty = row.p75_stop_distance_pct * 22 + Math.max(0, row.p75_margin_loss_50x_pct - 82) * 0.75 + Math.max(0, 190 - row.total_trades) * 0.12;
  return round(reward - penalty, 2);
}

async function main() {
  console.log(`[run] entry refine 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_p75_stop_distance_pct" | "entry_quality_score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_fee: true,
      enable_trailing_stop: variant.enable_trailing_stop,
      enable_adx_filter: variant.enable_adx_filter,
      htf_candles: candles1d,
      entry_candles: candles1h,
      use_true_mtf: true,
      pa_min_signal_score: variant.pa_min_signal_score,
      pa_session_mode: variant.pa_session_mode,
      pa_rsi_gate: variant.pa_rsi_gate,
      pa_allow_trap: variant.pa_allow_trap,
    });

    const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const lossPnls = result.trades.filter((t) => t.pnl_net_pct < 0).map((t) => Math.abs(t.pnl_net_pct) * 100);
    const p75 = percentile(stopDistances, 0.75);

    const rowBase = {
      variant: variant.key,
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_adx_filter: variant.enable_adx_filter,
      enable_trailing_stop: variant.enable_trailing_stop,
      pa_min_signal_score: variant.pa_min_signal_score,
      pa_session_mode: variant.pa_session_mode,
      pa_rsi_gate: variant.pa_rsi_gate,
      pa_allow_trap: variant.pa_allow_trap,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 2),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net, 4),
      max_drawdown_pct: round(result.max_drawdown, 4),
      avg_stop_distance_pct: round(mean(stopDistances), 4),
      median_stop_distance_pct: round(percentile(stopDistances, 0.5), 4),
      p75_stop_distance_pct: round(p75, 4),
      p90_stop_distance_pct: round(percentile(stopDistances, 0.9), 4),
      worst_trade_pct: round(Math.min(...result.trades.map((t) => t.pnl_net_pct * 100), 0), 4),
      avg_loss_pct: round(mean(lossPnls), 4),
      max_loss_streak: maxConsecutiveLosses(result.trades.map((t) => t.pnl_net_pct)),
      p75_margin_loss_20x_pct: round(p75 * 20, 2),
      p75_margin_loss_30x_pct: round(p75 * 30, 2),
      p75_margin_loss_50x_pct: round(p75 * 50, 2),
      recommended_margin_fraction_20x_1pct: round(calcMarginFractionForRiskBudget(1, 20, p75), 2),
      recommended_margin_fraction_30x_1pct: round(calcMarginFractionForRiskBudget(1, 30, p75), 2),
      recommended_margin_fraction_50x_1pct: round(calcMarginFractionForRiskBudget(1, 50, p75), 2),
    };

    rowsRaw.push(rowBase);
    console.log(`[done] ${rowBase.variant} trades=${rowBase.total_trades} win=${rowBase.win_rate_pct}% pf=${rowBase.profit_factor} p75=${rowBase.p75_stop_distance_pct}%`);
  }

  const baseline = rowsRaw.find((row) => row.variant === BASELINE_KEY);
  if (!baseline) throw new Error(`找不到 baseline variant: ${BASELINE_KEY}`);

  const rows: Row[] = rowsRaw.map((rowBase) => {
    const qualifiedCore = rowBase.total_trades >= MIN_TRADES && rowBase.profit_factor > 1;
    const guardOk = rowBase.p75_margin_loss_50x_pct <= 85 && rowBase.p75_stop_distance_pct <= 1.70;
    return {
      ...rowBase,
      qualified_core_requirements: qualifiedCore,
      high_leverage_guard_ok: guardOk,
      beats_baseline_winrate: rowBase.win_rate_pct > baseline.win_rate_pct,
      delta_win_rate_pct: round(rowBase.win_rate_pct - baseline.win_rate_pct, 2),
      delta_profit_factor: round(rowBase.profit_factor - baseline.profit_factor, 2),
      delta_total_trades: rowBase.total_trades - baseline.total_trades,
      delta_p75_stop_distance_pct: round(rowBase.p75_stop_distance_pct - baseline.p75_stop_distance_pct, 4),
      entry_quality_score: calcEntryQualityScore(rowBase),
    };
  });

  const qualified = rows
    .filter((row) => row.qualified_core_requirements)
    .sort((a, b) => b.win_rate_pct - a.win_rate_pct || Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok) || b.profit_factor - a.profit_factor || b.entry_quality_score - a.entry_quality_score || b.total_trades - a.total_trades);

  const improved = qualified.filter((row) => row.beats_baseline_winrate);
  const improvedGuarded = improved.filter((row) => row.high_leverage_guard_ok);
  const qualifiedGuarded = qualified.filter((row) => row.high_leverage_guard_ok);
  const bestCandidate = improvedGuarded[0] ?? improved[0] ?? qualifiedGuarded[0] ?? qualified[0] ?? null;

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_entry_refine_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_entry_refine_1h_${SYMBOL}_${ts}.md`);

  fs.writeFileSync(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    baseline_key: BASELINE_KEY,
    min_trades: MIN_TRADES,
    base_sl: BASE_SL,
    base_tp: BASE_TP,
    variants_scanned: VARIANTS.length,
    baseline,
    best_candidate: bestCandidate,
    improved_guarded: improvedGuarded.slice(0, 20),
    improved_all: improved.slice(0, 30),
    qualified_guarded: qualifiedGuarded.slice(0, 30),
    rows,
  }, null, 2));

  const baselineTable = `| 指标 | 基线值 |\n| --- | ---: |\n| 年交易数 | ${baseline.total_trades} |\n| 每两天交易数 | ${baseline.trades_per_2d} |\n| 胜率 | ${baseline.win_rate_pct}% |\n| PF | ${baseline.profit_factor} |\n| 净收益 | ${baseline.total_return_net_pct}% |\n| P75 止损距离 | ${baseline.p75_stop_distance_pct}% |\n| 20x P75 保证金损耗 | ${baseline.p75_margin_loss_20x_pct}% |\n| 30x P75 保证金损耗 | ${baseline.p75_margin_loss_30x_pct}% |\n| 50x P75 保证金损耗 | ${baseline.p75_margin_loss_50x_pct}% |`;

  const improvedTable = (improvedGuarded.length > 0 ? improvedGuarded.slice(0, 12) : improved.slice(0, 12)).map((r, i) => `| ${i + 1} | ${r.variant} | ${r.total_trades} | ${r.win_rate_pct}% | ${r.delta_win_rate_pct > 0 ? "+" : ""}${r.delta_win_rate_pct}% | ${r.profit_factor} | ${r.delta_profit_factor > 0 ? "+" : ""}${r.delta_profit_factor} | ${r.p75_stop_distance_pct}% | ${r.delta_p75_stop_distance_pct > 0 ? "+" : ""}${r.delta_p75_stop_distance_pct}% | ${r.high_leverage_guard_ok ? "是" : "否"} |`).join("\n") || `| 1 | 无胜率高于基线的候选 | 0 | 0% | 0% | 0 | 0 | 0% | 0% | 否 |`;

  const guardedTable = qualifiedGuarded.slice(0, 15).map((r, i) => `| ${i + 1} | ${r.variant} | ${r.total_trades} | ${r.win_rate_pct}% | ${r.profit_factor} | ${r.total_return_net_pct}% | ${r.p75_stop_distance_pct}% | ${r.p75_margin_loss_50x_pct}% | ${r.recommended_margin_fraction_50x_1pct}% |`).join("\n") || `| 1 | 无通过高杠杆守门的候选 | 0 | 0% | 0 | 0% | 0% | 0% | 0% |`;

  const bestSection = bestCandidate
    ? `当前搜索中最值得继续跟进的组合为 **${bestCandidate.variant}**。它的年交易数为 **${bestCandidate.total_trades}**，胜率 **${bestCandidate.win_rate_pct}%**，相对基线变化 **${bestCandidate.delta_win_rate_pct > 0 ? "+" : ""}${bestCandidate.delta_win_rate_pct}%**，Profit Factor 为 **${bestCandidate.profit_factor}**，P75 止损距离 **${bestCandidate.p75_stop_distance_pct}%**。`
    : `本轮没有找到满足最低频率与正 PF 要求的有效候选。`;

  const md = `# ${SYMBOL} 1H 进场条件改良搜索\n\n作者：**Manus AI**\n\n本轮搜索固定当前高杠杆主候选的风控参数 **PA / SL ${BASE_SL.toFixed(2)} ATR / TP ${BASE_TP.toFixed(2)} ATR**，不再改动止损与止盈，而是专门测试进场质量过滤，包括 **最低信号分数**、**时段过滤**、**RSI 频谱门槛** 与 **是否允许 2nd Leg Trap**。目标是判断在维持 **年交易数至少 ${MIN_TRADES} 笔**、**Profit Factor 为正** 且尽量不明显恶化高杠杆风险的前提下，能否进一步把胜率往上推。数据来源仍为 Binance 公共 K 线端点。[1]\n\n## 基线组合\n\n${baselineTable}\n\n## 胜率高于基线的候选\n\n${bestSection}\n\n| 排名 | 变体 | 年交易数 | 胜率 | 胜率变化 | PF | PF 变化 | P75 止损距离 | P75 止损变化 | 通过高杠杆守门 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
${improvedTable}\n\n## 所有通过高杠杆守门的前列候选\n\n| 排名 | 变体 | 年交易数 | 胜率 | PF | 净收益 | P75 止损距离 | 50x P75 保证金损耗 | 50x 建议最大保证金仓位比 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
${guardedTable}\n\n## 说明\n\n这里的高杠杆守门条件沿用此前分析口径，即 **P75 止损距离不高于 1.70%**，且 **50x P75 保证金损耗不高于 85%**。如果某个候选虽然胜率更高，但频率显著低于每两天一笔，或者 PF 被压到 1 以下，我不会把它视为可用的改良结果。\n\n## References\n\n[1]: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data "Binance Spot API Docs - Kline/Candlestick data"\n`;

  fs.writeFileSync(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD: ${mdPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
