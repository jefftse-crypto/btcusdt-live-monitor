/**
 * search_dual_tf_resonance_1h.ts
 * 1H 偏見 + 15m 獨立形態共振 — 雙框架進場模組搜索腳本
 *
 * 設計思路：
 *   - 1H PA 信號作為「方向偏見」，不直接進場
 *   - 在 1H 信號後的窗口內（pa_resonance_bias_window_bars 根 1H K 棒）
 *     掃描 15m 框架是否出現同向獨立 PA 形態
 *   - 只有「1H 偏見 + 15m 共振」同時成立才進場
 *   - 進場時機以 1H K 棒為單位（使用 1H 的 SL/TP）
 *
 * 基線（新主版本）：
 *   PA / SL 1.95 / TP 0.21 / bonus0.5 / minscore7.5 / touch0.04 / same_bar
 *   胜率 81.1%，PF 1.27，年交易數 185，50x P75 保證金損耗 80.53%
 *
 * 搜索維度：
 *   1. pa_resonance_bias_window_bars：1H 偏見後掃描窗口（2 / 4 / 6 / 8 根 1H K 棒）
 *   2. pa_resonance_min_score：15m 形態最低匯流分數（40 / 50 / 60）
 *   3. pa_resonance_require_key_level：是否要求 15m 形態在關鍵位（true / false）
 *   4. pa_resonance_require_momentum：是否要求動量確認（false / true）
 *
 * 作者：Manus AI
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  // 新主版本軟評分參數（固定）
  pa_retest_soft_score: boolean;
  pa_retest_soft_bonus: number;
  pa_retest_soft_min_score: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_reclaim_offset_atr: number;
  // 雙框架共振參數（搜索維度）
  pa_dual_tf_resonance: boolean;
  pa_resonance_bias_window_bars: number;
  pa_resonance_min_score: number;
  pa_resonance_require_key_level: boolean;
  pa_resonance_require_momentum: boolean;
};

type Row = {
  variant: string;
  bias_window_bars: number;
  resonance_min_score: number;
  require_key_level: boolean;
  require_momentum: boolean;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_baseline_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  soft_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

// 新主版本基線（軟評分扶正後）
const BASELINE_WIN_RATE = 81.1;
const BASELINE_PF = 1.27;
const BASELINE_TRADES = 185;
const BASELINE_P75_MARGIN_50X = 80.53;
const BASELINE_KEY = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_soft_on_bonus0.5_minscore7.5_touch0.04_same_bar_resonance_off`;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function normalizeBinanceRow(row: unknown[]): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Number(row[0]);
  const open = parseFloat(String(row[1]));
  const high = parseFloat(String(row[2]));
  const low = parseFloat(String(row[3]));
  const close = parseFloat(String(row[4]));
  const volume = parseFloat(String(row[5]));
  if (!isFinite(time) || !isFinite(open) || !isFinite(close)) return null;
  return { time, open, high, low, close, volume };
}

function isoTime(ts: number): string {
  return new Date(ts).toISOString().slice(0, 16);
}

async function fetchWithRetry(url: string, label: string, maxAttempts = 5): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Binance ${label} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function calcSoftScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "soft_score">): number {
  const winRateReward = row.win_rate_pct * 8;
  const pfReward = row.profit_factor * 30;
  const freqReward = Math.max(0, row.total_trades - MIN_TRADES) * 0.03;
  const leveragePenalty = Math.max(0, row.p75_margin_loss_50x_pct - BASELINE_P75_MARGIN_50X) * 1.5;
  const tradePenalty = Math.max(0, MIN_TRADES - row.total_trades) * 0.3;
  return winRateReward + pfReward + freqReward - leveragePenalty - tradePenalty;
}

function buildVariants(): Variant[] {
  const biasWindows = [2, 4, 6, 8];
  const minScores = [40, 50, 60];
  const requireKeyLevels = [true, false];
  const requireMomentums = [false, true];

  const variants: Variant[] = [];

  // 基線（無共振，新主版本）
  variants.push({
    key: BASELINE_KEY,
    strategy: "pa",
    atr_sl_mult: BASE_SL,
    atr_tp_mult: BASE_TP,
    enable_mtf_filter: true,
    enable_adx_filter: true,
    enable_trailing_stop: true,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: false,
    pa_retest_soft_score: true,
    pa_retest_soft_bonus: 0.5,
    pa_retest_soft_min_score: 7.5,
    pa_retest_touch_tolerance_atr: 0.04,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
    pa_retest_lookback_bars: 20,
    pa_retest_reclaim_offset_atr: 0.03,
    pa_dual_tf_resonance: false,
    pa_resonance_bias_window_bars: 4,
    pa_resonance_min_score: 50,
    pa_resonance_require_key_level: true,
    pa_resonance_require_momentum: false,
  });

  // 雙框架共振變體
  for (const biasWindow of biasWindows) {
    for (const minScore of minScores) {
      for (const requireKeyLevel of requireKeyLevels) {
        for (const requireMomentum of requireMomentums) {
          const key = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_soft_on_bonus0.5_minscore7.5_resonance_on_w${biasWindow}_s${minScore}_kl${requireKeyLevel ? "t" : "f"}_mom${requireMomentum ? "t" : "f"}`;
          variants.push({
            key,
            strategy: "pa",
            atr_sl_mult: BASE_SL,
            atr_tp_mult: BASE_TP,
            enable_mtf_filter: true,
            enable_adx_filter: true,
            enable_trailing_stop: true,
            pa_allow_pattern: true,
            pa_allow_true_breakout: false,
            pa_allow_trap: true,
            pa_require_retest_on_continuation: false,
            pa_retest_soft_score: true,
            pa_retest_soft_bonus: 0.5,
            pa_retest_soft_min_score: 7.5,
            pa_retest_touch_tolerance_atr: 0.04,
            pa_retest_mode: "same_bar",
            pa_retest_require_candle_color: true,
            pa_retest_lookback_bars: 20,
            pa_retest_reclaim_offset_atr: 0.03,
            pa_dual_tf_resonance: true,
            pa_resonance_bias_window_bars: biasWindow,
            pa_resonance_min_score: minScore,
            pa_resonance_require_key_level: requireKeyLevel,
            pa_resonance_require_momentum: requireMomentum,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();

async function main() {
  console.log(`[run] dual tf resonance 1h ${SYMBOL}`);
  console.log(`[fetch] 抓取 1H K 線...`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  console.log(`[fetch] 抓取 15m K 線...`);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 24 * 4 * YEAR_DAYS);
  console.log(`[fetch] 抓取 1D K 線...`);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[range] 15m ${isoTime(candles15m[0]?.time)} -> ${isoTime(candles15m[candles15m.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "soft_score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_adx_filter: variant.enable_adx_filter,
      enable_trailing_stop: variant.enable_trailing_stop,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_retest_soft_bonus: variant.pa_retest_soft_bonus,
      pa_retest_soft_min_score: variant.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
      pa_retest_mode: variant.pa_retest_mode,
      pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
      pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
      pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
      pa_dual_tf_resonance: variant.pa_dual_tf_resonance,
      pa_resonance_candles_15m: variant.pa_dual_tf_resonance ? candles15m : undefined,
      pa_resonance_bias_window_bars: variant.pa_resonance_bias_window_bars,
      pa_resonance_min_score: variant.pa_resonance_min_score,
      pa_resonance_require_key_level: variant.pa_resonance_require_key_level,
      pa_resonance_require_momentum: variant.pa_resonance_require_momentum,
    });

    const stopDistances = result.trades.map(t => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = round(percentile(stopDistances, 0.75), 4);
    const p75MarginLoss20x = round(p75Stop * 20, 2);
    const p75MarginLoss30x = round(p75Stop * 30, 2);
    const p75MarginLoss50x = round(p75Stop * 50, 2);
    const recMarginFrac20x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 20), 2) : 0;
    const recMarginFrac30x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 30), 2) : 0;
    const recMarginFrac50x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 50), 2) : 0;

    const row = {
      variant: variant.key,
      bias_window_bars: variant.pa_resonance_bias_window_bars,
      resonance_min_score: variant.pa_resonance_min_score,
      require_key_level: variant.pa_resonance_require_key_level,
      require_momentum: variant.pa_resonance_require_momentum,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 1),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net * 100, 2),
      max_drawdown_pct: round(result.max_drawdown * 100, 2),
      p75_stop_distance_pct: p75Stop,
      p75_margin_loss_20x_pct: p75MarginLoss20x,
      p75_margin_loss_30x_pct: p75MarginLoss30x,
      p75_margin_loss_50x_pct: p75MarginLoss50x,
      recommended_margin_fraction_20x_1pct: recMarginFrac20x,
      recommended_margin_fraction_30x_1pct: recMarginFrac30x,
      recommended_margin_fraction_50x_1pct: recMarginFrac50x,
    };
    console.log(`[done] ${variant.key.slice(-50)} trades=${result.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor}`);
    rowsRaw.push(row);
  }

  const baseline = rowsRaw.find((row) => row.variant === BASELINE_KEY);
  if (!baseline) throw new Error(`找不到基線變體：${BASELINE_KEY}`);

  const rows: Row[] = rowsRaw.map((row) => {
    const qualified_core_requirements = row.total_trades >= MIN_TRADES && row.profit_factor > 1;
    const high_leverage_guard_ok = row.p75_margin_loss_50x_pct <= 82;
    const beats_baseline_winrate = row.win_rate_pct > BASELINE_WIN_RATE;
    const delta_win_rate_pct = round(row.win_rate_pct - BASELINE_WIN_RATE, 1);
    const delta_profit_factor = round(row.profit_factor - BASELINE_PF, 2);
    const delta_total_trades = row.total_trades - BASELINE_TRADES;
    const soft_score = calcSoftScore(row);
    return {
      ...row,
      qualified_core_requirements,
      high_leverage_guard_ok,
      beats_baseline_winrate,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      soft_score,
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const qa = Number(b.qualified_core_requirements) - Number(a.qualified_core_requirements);
    if (qa !== 0) return qa;
    const ga = Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok);
    if (ga !== 0) return ga;
    return b.soft_score - a.soft_score;
  });

  const winners = sorted.filter((row) => row.qualified_core_requirements && row.high_leverage_guard_ok && row.beats_baseline_winrate);
  const top20 = sorted.slice(0, 20);

  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `search_dual_tf_resonance_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_dual_tf_resonance_1h_${SYMBOL}_${ts}.md`);

  const jsonData = {
    symbol: SYMBOL,
    baseline_key: BASELINE_KEY,
    baseline_win_rate: BASELINE_WIN_RATE,
    baseline_pf: BASELINE_PF,
    baseline_trades: BASELINE_TRADES,
    baseline_p75_margin_50x: BASELINE_P75_MARGIN_50X,
    total_variants: VARIANTS.length,
    winners: winners.length,
    rows: sorted,
  };

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify(jsonData, null, 2));

  const winnerLines = winners.length === 0
    ? "本輪未找到同時滿足「核心頻率要求」、「高杠杆守門線」且「胜率高於基線」的雙框架共振變體。"
    : winners.slice(0, 10).map((row, idx) =>
        `${idx + 1}. **${row.variant}**：胜率 ${row.win_rate_pct}%，PF ${row.profit_factor}，年交易 ${row.total_trades}，50x P75 保證金損耗 ${row.p75_margin_loss_50x_pct}%，Δ胜率 ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct}，Δ交易數 ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades}。`
      ).join("\n");

  const summaryTable = top20.map((row) =>
    `| ${row.variant.slice(-55)} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.p75_margin_loss_50x_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades} | ${row.qualified_core_requirements ? "✓" : "✗"} | ${row.high_leverage_guard_ok ? "✓" : "✗"} |`
  ).join("\n");

  const md = `# 1H 偏見 + 15m 獨立形態共振搜索報告

**幣種**：${SYMBOL}  
**策略**：PA（1H 偏見 + 15m 共振雙框架）  
**基線**：${BASELINE_KEY}  
**搜索時間**：${new Date().toISOString()}  
**總變體數**：${VARIANTS.length}  
**通過守門數**：${winners.length}  

---

## 基線（新主版本）

| 指標 | 數值 |
| --- | ---: |
| 年交易數 | ${BASELINE_TRADES} |
| 胜率 | ${BASELINE_WIN_RATE}% |
| PF | ${BASELINE_PF} |
| 50x P75 保證金損耗 | ${BASELINE_P75_MARGIN_50X}% |

---

## 守門條件

- 年交易數 ≥ ${MIN_TRADES}（半年以上頻率）
- Profit Factor > 1.0
- 50x P75 保證金損耗 ≤ 82%
- 胜率 > ${BASELINE_WIN_RATE}%（超越新主版本基線）

---

## 通過守門的變體

${winnerLines}

---

## Top 20 詳細結果

| 變體（後55字元） | 年交易 | 胜率 | PF | 50x P75損耗 | Δ胜率 | Δ交易 | 核心 | 風控 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | :---: | :---: |
${summaryTable}

---

## 分析與結論

### 雙框架共振機制有效性

${winners.length > 0
  ? `本輪實驗發現 **${winners.length} 個**雙框架共振變體通過了所有守門條件，證明「1H 偏見 + 15m 獨立 PA 形態共振」機制確實有效。\n\n最優參數組合：\n- 偏見窗口：${winners[0].bias_window_bars} 根 1H K 棒\n- 15m 最低匯流分數：${winners[0].resonance_min_score}\n- 要求關鍵位：${winners[0].require_key_level ? "是" : "否"}\n- 要求動量確認：${winners[0].require_momentum ? "是" : "否"}`
  : `本輪實驗中，所有雙框架共振變體均未能超越新主版本基線（胜率 ${BASELINE_WIN_RATE}%）。\n\n可能原因：\n1. 15m 形態識別函數 \`signalPa15mResonance\` 的匯流分數計算與 1H 框架存在尺度差異，導致過多信號被過濾\n2. 1H 偏見窗口設計需要進一步調整\n3. 建議下一步：放寬 \`pa_resonance_min_score\` 至 30 以下，或嘗試不要求關鍵位（require_key_level=false）`}

### 建議後續方向

1. 若本輪有通過守門的變體，建議將最優參數扶正為新主版本，並執行高槓桿風險評估
2. 若本輪無通過守門的變體，建議調整 15m 形態識別的匯流分數計算邏輯，使其與 1H 框架的評分尺度對齊
3. 可考慮引入「15m 形態出現後，以 15m K 棒的下一根開盤價進場」的精確時機模式（需修改進場邏輯）
`;

  await fs.writeFile(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD:   ${mdPath}`);
  console.log(`[summary] 總變體=${VARIANTS.length} 通過守門=${winners.length}`);
  if (winners.length > 0) {
    console.log(`[best] ${winners[0].variant}`);
    console.log(`       胜率=${winners[0].win_rate_pct}% PF=${winners[0].profit_factor} 年交易=${winners[0].total_trades} 50xP75=${winners[0].p75_margin_loss_50x_pct}%`);
  }
}

main().catch((err) => {
  console.error("[fatal]", err);
  process.exit(1);
});
