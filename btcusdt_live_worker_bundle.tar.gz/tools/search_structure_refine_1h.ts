import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type PaSessionMode = "all" | "exclude_offhours" | "london_newyork";
type PaRsiGateMode = "off" | "avoid_reject" | "pass_only";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_min_signal_score: number;
  pa_session_mode: PaSessionMode;
  pa_rsi_gate: PaRsiGateMode;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
};

type Row = {
  variant: string;
  atr_sl_mult: number;
  atr_tp_mult: number;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  avg_stop_distance_pct: number;
  median_stop_distance_pct: number;
  p75_stop_distance_pct: number;
  p90_stop_distance_pct: number;
  worst_trade_pct: number;
  avg_loss_pct: number;
  max_loss_streak: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_baseline_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  delta_p75_stop_distance_pct: number;
  structure_upgrade_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function buildVariants(): Variant[] {
  const variants: Variant[] = [];
  const patternOptions = [true, false];
  const breakoutOptions = [true, false];
  const trapOptions = [true, false];
  const retestOptions = [false, true];

  for (const pa_allow_pattern of patternOptions) {
    for (const pa_allow_true_breakout of breakoutOptions) {
      for (const pa_allow_trap of trapOptions) {
        for (const pa_require_retest_on_continuation of retestOptions) {
          if (!pa_allow_pattern && !pa_allow_true_breakout && !pa_allow_trap) continue;
          if (pa_require_retest_on_continuation && !pa_allow_pattern && !pa_allow_true_breakout) continue;
          variants.push({
            key: [
              `pa_sl${BASE_SL.toFixed(2)}`,
              `tp${BASE_TP.toFixed(2)}`,
              pa_allow_pattern ? "pattern_on" : "pattern_off",
              pa_allow_true_breakout ? "breakout_on" : "breakout_off",
              pa_allow_trap ? "trap_on" : "trap_off",
              pa_require_retest_on_continuation ? "retest_on" : "retest_off",
            ].join("_"),
            strategy: "pa",
            atr_sl_mult: BASE_SL,
            atr_tp_mult: BASE_TP,
            enable_mtf_filter: true,
            enable_adx_filter: true,
            enable_trailing_stop: false,
            pa_min_signal_score: 0,
            pa_session_mode: "all",
            pa_rsi_gate: "off",
            pa_allow_pattern,
            pa_allow_true_breakout,
            pa_allow_trap,
            pa_require_retest_on_continuation,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();
const BASELINE_KEY = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_pattern_on_breakout_on_trap_on_retest_off`;

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function maxConsecutiveLosses(pnls: number[]): number {
  let streak = 0;
  let maxStreak = 0;
  for (const pnl of pnls) {
    if (pnl < 0) {
      streak += 1;
      if (streak > maxStreak) maxStreak = streak;
    } else {
      streak = 0;
    }
  }
  return maxStreak;
}

function calcMarginFractionForRiskBudget(riskBudgetPct: number, leverage: number, stopDistancePct: number): number {
  if (leverage <= 0 || stopDistancePct <= 0) return 0;
  return Math.min(100, (riskBudgetPct / (leverage * stopDistancePct)) * 100);
}

function calcStructureUpgradeScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_p75_stop_distance_pct" | "structure_upgrade_score">): number {
  const reward = row.win_rate_pct * 7 + row.profit_factor * 28 + Math.max(0, row.total_trades - MIN_TRADES) * 0.02;
  const penalty = row.p75_stop_distance_pct * 20 + Math.max(0, row.p75_margin_loss_50x_pct - 82) * 0.7 + Math.max(0, MIN_TRADES - row.total_trades) * 0.2;
  return round(reward - penalty, 2);
}

function mdBool(value: boolean): string {
  return value ? "on" : "off";
}

async function main() {
  console.log(`[run] structure refine 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_p75_stop_distance_pct" | "structure_upgrade_score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_fee: true,
      enable_trailing_stop: variant.enable_trailing_stop,
      enable_adx_filter: variant.enable_adx_filter,
      htf_candles: candles1d,
      entry_candles: candles1h,
      use_true_mtf: true,
      pa_min_signal_score: variant.pa_min_signal_score,
      pa_session_mode: variant.pa_session_mode,
      pa_rsi_gate: variant.pa_rsi_gate,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
    });

    const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const lossPnls = result.trades.filter((t) => t.pnl_net_pct < 0).map((t) => Math.abs(t.pnl_net_pct) * 100);
    const p75 = percentile(stopDistances, 0.75);

    const rowBase = {
      variant: variant.key,
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 2),
      profit_factor: round(result.profit_factor, 3),
      total_return_net_pct: round(result.total_return_net * 100, 3),
      max_drawdown_pct: round(result.max_drawdown * 100, 3),
      avg_stop_distance_pct: round(mean(stopDistances), 4),
      median_stop_distance_pct: round(percentile(stopDistances, 0.5), 4),
      p75_stop_distance_pct: round(p75, 4),
      p90_stop_distance_pct: round(percentile(stopDistances, 0.9), 4),
      worst_trade_pct: round(lossPnls.length > 0 ? Math.max(...lossPnls) : 0, 4),
      avg_loss_pct: round(mean(lossPnls), 4),
      max_loss_streak: maxConsecutiveLosses(result.trades.map((t) => t.pnl_net_pct)),
      p75_margin_loss_20x_pct: round(p75 * 20, 2),
      p75_margin_loss_30x_pct: round(p75 * 30, 2),
      p75_margin_loss_50x_pct: round(p75 * 50, 2),
      recommended_margin_fraction_20x_1pct: round(calcMarginFractionForRiskBudget(1, 20, p75), 2),
      recommended_margin_fraction_30x_1pct: round(calcMarginFractionForRiskBudget(1, 30, p75), 2),
      recommended_margin_fraction_50x_1pct: round(calcMarginFractionForRiskBudget(1, 50, p75), 2),
    };

    rowsRaw.push(rowBase);
    console.log(`[done] ${variant.key} trades=${rowBase.total_trades} win=${rowBase.win_rate_pct}% pf=${rowBase.profit_factor}`);
  }

  const baseline = rowsRaw.find((row) => row.variant === BASELINE_KEY);
  if (!baseline) throw new Error(`找不到基线变体：${BASELINE_KEY}`);

  const rows: Row[] = rowsRaw.map((row) => {
    const qualified_core_requirements = row.total_trades >= MIN_TRADES && row.profit_factor > 1;
    const high_leverage_guard_ok = row.p75_margin_loss_50x_pct <= 82;
    const beats_baseline_winrate = row.win_rate_pct > baseline.win_rate_pct;
    const delta_win_rate_pct = round(row.win_rate_pct - baseline.win_rate_pct, 2);
    const delta_profit_factor = round(row.profit_factor - baseline.profit_factor, 3);
    const delta_total_trades = row.total_trades - baseline.total_trades;
    const delta_p75_stop_distance_pct = round(row.p75_stop_distance_pct - baseline.p75_stop_distance_pct, 4);
    return {
      ...row,
      qualified_core_requirements,
      high_leverage_guard_ok,
      beats_baseline_winrate,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      delta_p75_stop_distance_pct,
      structure_upgrade_score: calcStructureUpgradeScore(row),
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const qa = Number(b.qualified_core_requirements) - Number(a.qualified_core_requirements);
    if (qa !== 0) return qa;
    const ga = Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok);
    if (ga !== 0) return ga;
    if (b.win_rate_pct !== a.win_rate_pct) return b.win_rate_pct - a.win_rate_pct;
    if (b.profit_factor !== a.profit_factor) return b.profit_factor - a.profit_factor;
    return b.structure_upgrade_score - a.structure_upgrade_score;
  });

  const winners = sorted.filter((row) => row.qualified_core_requirements && row.high_leverage_guard_ok && row.beats_baseline_winrate);
  const topRows = sorted.slice(0, 12);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_structure_refine_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_structure_refine_1h_${SYMBOL}_${ts}.md`);

  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    baseline_key: BASELINE_KEY,
    baseline,
    winners,
    top_rows: topRows,
    rows: sorted,
  }, null, 2), "utf8");

  const summaryTable = topRows.map((row) =>
    `| ${row.variant} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.p75_stop_distance_pct}% | ${row.p75_margin_loss_50x_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.qualified_core_requirements ? "yes" : "no"} | ${row.high_leverage_guard_ok ? "yes" : "no"} |`
  ).join("\n");

  const winnerLines = winners.length > 0
    ? winners.slice(0, 8).map((row, idx) => `${idx + 1}. **${row.variant}**：胜率 ${row.win_rate_pct}%，PF ${row.profit_factor}，年交易 ${row.total_trades}，50x P75 保证金损耗 ${row.p75_margin_loss_50x_pct}%。`).join("\n")
    : "未找到同时满足频率、PF 与高杠杆守门条件，且胜率高于基线的结构升级变体。";

  const md = `# BTCUSDT 1H 结构升级搜索\n\n作者：**Manus AI**\n\n本轮搜索围绕当前高杠杆 PA 主候选 **SL ${BASE_SL.toFixed(2)} / TP ${BASE_TP.toFixed(2)}**，测试三类结构升级动作：**拆分普通形态**、**拆分真突破延续**、以及**为延续型要求回踩确认**。目标是验证这些结构性改动，是否能在不明显破坏高杠杆约束的情况下，提高当前基线胜率。\n\n| 项目 | 数值 |\n| --- | ---: |\n| Symbol | ${SYMBOL} |\n| 基线变体 | ${BASELINE_KEY} |\n| 基线胜率 | ${baseline.win_rate_pct}% |\n| 基线 PF | ${baseline.profit_factor} |\n| 基线年交易数 | ${baseline.total_trades} |\n| 基线 50x P75 保证金损耗 | ${baseline.p75_margin_loss_50x_pct}% |\n| 搜索变体数 | ${VARIANTS.length} |\n\n## 通过守门并且胜率高于基线的候选\n\n${winnerLines}\n\n## Top 结果总表\n\n| Variant | Trades | Win Rate | PF | P75 Stop | 50x P75 Margin Loss | Δ Win Rate | Core OK | Guard OK |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |\n${summaryTable}\n\n## 结构开关说明\n\n| 开关 | 含义 |\n| --- | --- |\n| pattern_on/off | 是否保留普通 PA_PATTERN / PA_PATTERN_RETEST |\n| breakout_on/off | 是否保留 PA_TRUE_BREAKOUT / PA_TRUE_BREAKOUT_RETEST |\n| trap_on/off | 是否保留 PA_2ND_LEG_TRAP |\n| retest_on/off | 是否要求延续型信号先完成回踩确认 |\n\n## 基线设定\n\n| 维度 | 状态 |\n| --- | --- |\n| 普通形态 | ${mdBool(true)} |\n| 真突破延续 | ${mdBool(true)} |\n| Trap 反转 | ${mdBool(true)} |\n| 延续型回踩确认 | ${mdBool(false)} |\n\n## 输出文件\n\n| 文件 | 路径 |\n| --- | --- |\n| JSON | ${jsonPath} |\n| Markdown | ${mdPath} |\n`;

  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
