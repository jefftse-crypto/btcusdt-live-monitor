import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";
import { calcAdxArr, calcAtrArr, calcBollingerArr, calcRsiArr } from "../server/utils/indicators.ts";
import { analyzePaRsiSpectrum } from "../server/utils/signalQualityFilter.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";
type SessionMode = "all" | "exclude_offhours" | "london_newyork";
type RsiGateMode = "all" | "pass_or_caution" | "pass_only";
type EntryGroup = "all" | "pattern_only" | "retest_only" | "trap_only" | "breakout_retest_only" | "no_trap";
type Regime = "all" | "trending" | "ranging" | "compressed" | "chaotic";

type VariantConfig = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
};

type LiteTrade = {
  entry_time: number;
  exit_time: number;
  direction: "long" | "short";
  pnl_net_pct: number;
  entry_type?: string;
  signal_score?: number;
};

type AddedTradeState = LiteTrade & {
  session: "asia" | "london" | "newyork" | "offhours";
  adx: number;
  rsi: number;
  rsi_filter: "pass" | "caution" | "reject";
  regime: Exclude<Regime, "all">;
};

type Row = {
  session_mode: SessionMode;
  rsi_gate: RsiGateMode;
  entry_group: EntryGroup;
  regime_filter: Regime;
  score_min: number;
  adx_min: number;
  selected_added_trades: number;
  selected_added_win_rate_pct: number;
  combo_total_trades: number;
  combo_win_rate_pct: number;
  delta_vs_aggressive_trades: number;
  delta_vs_aggressive_win_pct: number;
  delta_vs_defensive_trades: number;
  delta_vs_defensive_win_pct: number;
  score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const CORE_VARIANT = "pa_sl1.95_tp0.21_pattern_on_breakout_off_trap_on_retest_on_lb24_touch0.04_reclaim0.04_same_bar_color_on";
const AGGRESSIVE_ADDON = "pa_sl1.75_tp0.19_pattern_on_breakout_off_trap_on_retest_on_lb12_touch0.08_reclaim0.03_either_color_off";
const DEFENSIVE_TRADES = 87;
const DEFENSIVE_WIN = 85.06;
const AGGRESSIVE_TRADES = 92;
const AGGRESSIVE_WIN = 83.7;
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 2): number {
  return Number(value.toFixed(digits));
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function parseVariant(variant: string): VariantConfig {
  const parts = variant.split("_");
  const takeAfterPrefix = (prefix: string) => {
    const item = parts.find((p) => p.startsWith(prefix));
    if (!item) throw new Error(`variant ${variant} 缺少 ${prefix}`);
    return item.slice(prefix.length);
  };
  const strategy = parts[0] as BacktestStrategy;
  return {
    key: variant,
    strategy,
    atr_sl_mult: Number(takeAfterPrefix("sl")),
    atr_tp_mult: Number(takeAfterPrefix("tp")),
    pa_allow_pattern: variant.includes("pattern_on"),
    pa_allow_true_breakout: variant.includes("breakout_on"),
    pa_allow_trap: variant.includes("trap_on"),
    pa_require_retest_on_continuation: variant.includes("retest_on"),
    pa_retest_lookback_bars: Number(takeAfterPrefix("lb")),
    pa_retest_touch_tolerance_atr: Number(takeAfterPrefix("touch")),
    pa_retest_reclaim_offset_atr: Number(takeAfterPrefix("reclaim")),
    pa_retest_mode: variant.includes("same_bar") ? "same_bar" : variant.includes("next_bar_confirm") ? "next_bar_confirm" : "either",
    pa_retest_require_candle_color: variant.includes("color_on"),
  };
}

function tradeKey(t: LiteTrade): string {
  return `${t.entry_time}_${t.direction}`;
}

function liteTrades(trades: any[]): LiteTrade[] {
  return trades.map((t) => ({
    entry_time: t.entry_time,
    exit_time: t.exit_time,
    direction: t.direction,
    pnl_net_pct: t.pnl_net_pct,
    entry_type: t.entry_type,
    signal_score: t.signal_score,
  }));
}

function winRatePct(trades: LiteTrade[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter((t) => t.pnl_net_pct > 0).length;
  return round((wins / trades.length) * 100, 2);
}

function getSessionLabel(timestampSec: number): AddedTradeState["session"] {
  const hour = new Date(timestampSec * 1000).getUTCHours();
  if (hour >= 13 && hour < 22) return "newyork";
  if (hour >= 7 && hour < 16) return "london";
  if (hour >= 0 && hour < 8) return "asia";
  return "offhours";
}

function sessionAllowed(label: AddedTradeState["session"], mode: SessionMode): boolean {
  if (mode === "all") return true;
  if (mode === "exclude_offhours") return label !== "offhours";
  if (mode === "london_newyork") return label === "london" || label === "newyork";
  return true;
}

function rsiGateAllowed(result: "pass" | "caution" | "reject", mode: RsiGateMode): boolean {
  if (mode === "all") return true;
  if (mode === "pass_or_caution") return result !== "reject";
  if (mode === "pass_only") return result === "pass";
  return true;
}

function entryGroupAllowed(entryType: string | undefined, group: EntryGroup): boolean {
  const t = entryType ?? "PA_PATTERN";
  if (group === "all") return true;
  if (group === "pattern_only") return t === "PA_PATTERN" || t === "PA_PATTERN_RETEST";
  if (group === "retest_only") return t.includes("RETEST");
  if (group === "trap_only") return t === "PA_2ND_LEG_TRAP";
  if (group === "breakout_retest_only") return t === "PA_TRUE_BREAKOUT_RETEST";
  if (group === "no_trap") return t !== "PA_2ND_LEG_TRAP";
  return true;
}

function classifyRegime(i: number, candles: Candle[], closes: number[], adxArr: number[], atrArr: number[], bollArr: Array<{ bandwidth: number }>): Exclude<Regime, "all"> {
  const start = Math.max(0, i - 60);
  const slice = candles.slice(start, i + 1);
  const rangeHigh = Math.max(...slice.map((c) => c.high));
  const rangeLow = Math.min(...slice.map((c) => c.low));
  const range = rangeHigh - rangeLow;
  const atr = atrArr[i] ?? 0;
  const adx = adxArr[i] ?? 0;
  const close = closes[i] ?? candles[i]?.close ?? 0;
  const bbWidth = bollArr[i]?.bandwidth ?? 0;
  const atrPct = close > 0 ? atr / close : 0;
  const rangeToAtr = atr > 0 ? range / atr : 0;
  if (bbWidth < 0.02 || atrPct < 0.005) return "compressed";
  if (adx >= 25 && rangeToAtr >= 3) return "trending";
  if (adx < 20 && rangeToAtr < 2.5) return "ranging";
  if (atrPct > 0.03) return "chaotic";
  return "ranging";
}

async function runVariant(candles1h: Candle[], candles1d: Candle[], variantKey: string) {
  const v = parseVariant(variantKey);
  return runBacktest({
    candles: candles1h,
    strategy: v.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: v.atr_sl_mult,
    atr_tp_mult: v.atr_tp_mult,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: v.pa_allow_pattern,
    pa_allow_true_breakout: v.pa_allow_true_breakout,
    pa_allow_trap: v.pa_allow_trap,
    pa_require_retest_on_continuation: v.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: v.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: v.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: v.pa_retest_reclaim_offset_atr,
    pa_retest_mode: v.pa_retest_mode,
    pa_retest_require_candle_color: v.pa_retest_require_candle_color,
  });
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  const closes = candles1h.map((c) => c.close);
  const rsiArr = calcRsiArr(closes, 14);
  const { adx: adxArr } = calcAdxArr(candles1h, 14);
  const atrArr = calcAtrArr(candles1h, 14);
  const bollArr = calcBollingerArr(closes, 20, 2);
  const timeToIndex = new Map(candles1h.map((c, i) => [c.time, i]));

  console.log(`[range] ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);

  const core = await runVariant(candles1h, candles1d, CORE_VARIANT);
  const addon = await runVariant(candles1h, candles1d, AGGRESSIVE_ADDON);
  const coreTrades = liteTrades(core.trades as any[]);
  const coreMap = new Map(coreTrades.map((t) => [tradeKey(t), t]));
  const aggressiveAdded = liteTrades(addon.trades as any[]).filter((t) => !coreMap.has(tradeKey(t)));

  const annotatedAdded: AddedTradeState[] = aggressiveAdded.map((t) => {
    const idx = timeToIndex.get(t.entry_time);
    const safeIdx = idx ?? candles1h.findIndex((c) => c.time >= t.entry_time);
    const i = safeIdx >= 0 ? safeIdx : candles1h.length - 1;
    const rsiWindow = rsiArr.slice(Math.max(0, i - 8), i + 1).filter((v) => Number.isFinite(v));
    const priceWindow = closes.slice(Math.max(0, i - 8), i + 1).filter((v) => Number.isFinite(v));
    const rsiVal = Number.isFinite(rsiArr[i]) ? rsiArr[i] : 50;
    const adxVal = Number.isFinite(adxArr[i]) ? adxArr[i] : 0;
    const spectrum = analyzePaRsiSpectrum(rsiVal, rsiWindow, closes[i] ?? 0, priceWindow, adxVal);
    return {
      ...t,
      session: getSessionLabel(t.entry_time),
      adx: round(adxVal, 2),
      rsi: round(rsiVal, 2),
      rsi_filter: spectrum.filterResult,
      regime: classifyRegime(i, candles1h, closes, adxArr, atrArr, bollArr),
    };
  });

  const sessionModes: SessionMode[] = ["all", "exclude_offhours", "london_newyork"];
  const rsiModes: RsiGateMode[] = ["all", "pass_or_caution", "pass_only"];
  const entryGroups: EntryGroup[] = ["all", "pattern_only", "retest_only", "trap_only", "breakout_retest_only", "no_trap"];
  const regimeFilters: Regime[] = ["all", "trending", "ranging", "compressed", "chaotic"];
  const scoreMins = [0, 6.0, 6.5, 7.0, 7.5, 8.0];
  const adxThresholds = [0, 18, 20, 25, 30, 35];

  const rows: Row[] = [];
  for (const sessionMode of sessionModes) {
    for (const rsiMode of rsiModes) {
      for (const entryGroup of entryGroups) {
        for (const regimeFilter of regimeFilters) {
          for (const scoreMin of scoreMins) {
            for (const adxMin of adxThresholds) {
              const selectedAdded = annotatedAdded.filter((t) => (
                sessionAllowed(t.session, sessionMode)
                && rsiGateAllowed(t.rsi_filter, rsiMode)
                && entryGroupAllowed(t.entry_type, entryGroup)
                && (regimeFilter === "all" || t.regime === regimeFilter)
                && (Number(t.signal_score ?? 0) >= scoreMin)
                && t.adx >= adxMin
              ));
              if (selectedAdded.length === 0) continue;
              const comboTrades = [...coreTrades, ...selectedAdded].sort((a, b) => a.entry_time - b.entry_time);
              const comboWin = winRatePct(comboTrades);
              const selectedWin = winRatePct(selectedAdded);
              const score = round(
                comboWin * 1.1
                + comboTrades.length * 0.55
                + selectedWin * 0.18
                + (comboWin - AGGRESSIVE_WIN) * 24
                + (comboTrades.length - AGGRESSIVE_TRADES) * 2.5
                + (comboWin - DEFENSIVE_WIN) * 8,
                2,
              );
              rows.push({
                session_mode: sessionMode,
                rsi_gate: rsiMode,
                entry_group: entryGroup,
                regime_filter: regimeFilter,
                score_min: scoreMin,
                adx_min: adxMin,
                selected_added_trades: selectedAdded.length,
                selected_added_win_rate_pct: selectedWin,
                combo_total_trades: comboTrades.length,
                combo_win_rate_pct: comboWin,
                delta_vs_aggressive_trades: comboTrades.length - AGGRESSIVE_TRADES,
                delta_vs_aggressive_win_pct: round(comboWin - AGGRESSIVE_WIN, 2),
                delta_vs_defensive_trades: comboTrades.length - DEFENSIVE_TRADES,
                delta_vs_defensive_win_pct: round(comboWin - DEFENSIVE_WIN, 2),
                score,
              });
            }
          }
        }
      }
    }
  }

  rows.sort((a, b) => b.score - a.score || b.combo_win_rate_pct - a.combo_win_rate_pct || b.combo_total_trades - a.combo_total_trades);
  const betterThanAggressive = rows.filter((r) => r.combo_total_trades > AGGRESSIVE_TRADES || r.combo_win_rate_pct > AGGRESSIVE_WIN);
  const above85 = rows.filter((r) => r.combo_win_rate_pct >= 85).slice(0, 80);

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_pa_added_trade_strata_round5_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_pa_added_trade_strata_round5_${SYMBOL}_${ts}.md`);

  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    core_variant: CORE_VARIANT,
    aggressive_addon: AGGRESSIVE_ADDON,
    aggressive_base: { total_trades: AGGRESSIVE_TRADES, win_rate_pct: AGGRESSIVE_WIN },
    defensive_base: { total_trades: DEFENSIVE_TRADES, win_rate_pct: DEFENSIVE_WIN },
    added_trade_count: annotatedAdded.length,
    added_trade_win_rate_pct: winRatePct(annotatedAdded),
    rows_tested: rows.length,
    better_than_aggressive_count: betterThanAggressive.length,
    above_85_count: rows.filter((r) => r.combo_win_rate_pct >= 85).length,
    better_than_aggressive: betterThanAggressive.slice(0, 80),
    above_85: above85,
    rows: rows.slice(0, 200),
  }, null, 2), "utf8");

  const topRows = rows.slice(0, 80).map((r) => `| ${r.session_mode} | ${r.rsi_gate} | ${r.entry_group} | ${r.regime_filter} | ${r.score_min} | ${r.adx_min} | ${r.selected_added_trades} | ${r.selected_added_win_rate_pct}% | ${r.combo_total_trades} | ${r.combo_win_rate_pct}% | ${r.delta_vs_aggressive_trades >= 0 ? "+" : ""}${r.delta_vs_aggressive_trades} | ${r.delta_vs_aggressive_win_pct >= 0 ? "+" : ""}${r.delta_vs_aggressive_win_pct} | ${r.delta_vs_defensive_trades >= 0 ? "+" : ""}${r.delta_vs_defensive_trades} | ${r.delta_vs_defensive_win_pct >= 0 ? "+" : ""}${r.delta_vs_defensive_win_pct} | ${r.score} |`).join("\n");
  const md = `# BTCUSDT 第五轮：PA 内部新增交易再分层搜索\n\n| 项目 | 数值 |\n| --- | ---: |\n| Core Trades | ${coreTrades.length} |\n| Aggressive Base | ${AGGRESSIVE_TRADES} / ${AGGRESSIVE_WIN}% |\n| Defensive Base | ${DEFENSIVE_TRADES} / ${DEFENSIVE_WIN}% |\n| Aggressive Added Trades | ${annotatedAdded.length} |\n| Aggressive Added Win Rate | ${winRatePct(annotatedAdded)}% |\n| Rows Tested | ${rows.length} |\n| Better Than Aggressive Rows | ${betterThanAggressive.length} |\n| Combo Win >= 85% Rows | ${rows.filter((r) => r.combo_win_rate_pct >= 85).length} |\n\n> 本轮不再向外寻找 Add-on，而是直接对 Aggressive Add-on 相对 Core 多出来的新增交易做内部再分层，检查哪些细分状态值得保留。\n\n| Session | RSI Gate | Entry Group | Regime | Score Min | ADX Min | Selected Added | Added Win | Combo Trades | Combo Win | Δ Trades vs 92 | Δ Win vs 83.7 | Δ Trades vs 87 | Δ Win vs 85.06 | Score |\n| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${topRows}\n`;
  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
