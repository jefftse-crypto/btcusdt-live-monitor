import { runBacktest } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const SYMBOL = "BTCUSDT";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function normalizeBinanceRow(row: unknown[]): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Number(row[0]);
  const open = parseFloat(String(row[1]));
  const high = parseFloat(String(row[2]));
  const low = parseFloat(String(row[3]));
  const close = parseFloat(String(row[4]));
  const volume = parseFloat(String(row[5]));
  if (!isFinite(time) || !isFinite(open) || !isFinite(close)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, label: string, maxAttempts = 5): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Binance ${label} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * 365 + 400);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 24 * 4 * 365 + 1200);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", 500);

  const result = runBacktest({
    candles: candles1h,
    strategy: "pa",
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: 1.95,
    atr_tp_mult: 0.21,
    enable_mtf_filter: true,
    mtf_candles: candles1d,
    enable_adx_filter: true,
    enable_trailing_stop: true,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: false,
    pa_retest_soft_score: true,
    pa_retest_soft_bonus: 0.5,
    pa_retest_soft_min_score: 7.5,
    pa_retest_touch_tolerance_atr: 0.04,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
    pa_retest_lookback_bars: 20,
    pa_retest_reclaim_offset_atr: 0.03,
    pa_dual_tf_resonance: true,
    pa_resonance_candles_15m: candles15m,
    pa_resonance_bias_window_bars: 2,
    pa_resonance_min_score: 40,
    pa_resonance_require_key_level: true,
    pa_resonance_require_momentum: false,
  });

  const enriched = result.trades.filter((t) => t.used_15m_execution);
  const sample = enriched.slice(0, 3).map((t) => ({
    entry_time: t.entry_time,
    exit_time: t.exit_time,
    entry_price: t.entry_price,
    exit_price: t.exit_price,
    entry_type: t.entry_type,
    used_15m_execution: t.used_15m_execution,
    resonance_entry_time_15m: t.resonance_entry_time_15m,
    resonance_exit_time_15m: t.resonance_exit_time_15m,
    resonance_entry_idx_15m: t.resonance_entry_idx_15m,
    resonance_exit_idx_15m: t.resonance_exit_idx_15m,
  }));

  console.log(JSON.stringify({
    total_trades: result.total_trades,
    used_15m_execution_trades: enriched.length,
    sample,
  }, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
