import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";
import { calcAdxArr, calcRsiArr } from "../server/utils/indicators.ts";
import { analyzePaRsiSpectrum } from "../server/utils/signalQualityFilter.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";
type SessionMode = "all" | "exclude_offhours" | "london_newyork";
type RsiGateMode = "all" | "pass_or_caution" | "pass_only";
type SessionLabel = "asia" | "london" | "newyork" | "offhours";

type VariantConfig = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
};

type LiteTrade = {
  entry_time: number;
  exit_time: number;
  direction: "long" | "short";
  pnl_net_pct: number;
};

type AddedTradeState = LiteTrade & {
  session: SessionLabel;
  adx: number;
  rsi: number;
  rsi_filter: "pass" | "caution" | "reject";
};

type RuleRow = {
  session_mode: SessionMode;
  rsi_gate: RsiGateMode;
  adx_min: number;
  selected_added_trades: number;
  selected_added_win_rate_pct: number;
  combo_total_trades: number;
  combo_win_rate_pct: number;
  delta_vs_core_trades: number;
  delta_vs_core_win_pct: number;
  delta_vs_aggressive_trades: number;
  delta_vs_aggressive_win_pct: number;
  overlap_with_defensive_added: number;
  extra_vs_defensive_added: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const CORE_VARIANT = "pa_sl1.95_tp0.21_pattern_on_breakout_off_trap_on_retest_on_lb24_touch0.04_reclaim0.04_same_bar_color_on";
const AGGRESSIVE_ADDON = "pa_sl1.75_tp0.19_pattern_on_breakout_off_trap_on_retest_on_lb12_touch0.08_reclaim0.03_either_color_off";
const DEFENSIVE_SESSION_MODE: SessionMode = "exclude_offhours";
const DEFENSIVE_RSI_GATE = "avoid_reject";
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 2): number {
  return Number(value.toFixed(digits));
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function parseVariant(variant: string): VariantConfig {
  const parts = variant.split("_");
  const takeAfterPrefix = (prefix: string) => {
    const item = parts.find((p) => p.startsWith(prefix));
    if (!item) throw new Error(`variant ${variant} 缺少 ${prefix}`);
    return item.slice(prefix.length);
  };
  const has = (token: string) => parts.includes(token);
  const strategy = parts[0] as BacktestStrategy;
  return {
    key: variant,
    strategy,
    atr_sl_mult: Number(takeAfterPrefix("sl")),
    atr_tp_mult: Number(takeAfterPrefix("tp")),
    pa_allow_pattern: has("pattern") ? true : variant.includes("pattern_on"),
    pa_allow_true_breakout: variant.includes("breakout_on"),
    pa_allow_trap: variant.includes("trap_on"),
    pa_require_retest_on_continuation: variant.includes("retest_on"),
    pa_retest_lookback_bars: Number(takeAfterPrefix("lb")),
    pa_retest_touch_tolerance_atr: Number(takeAfterPrefix("touch")),
    pa_retest_reclaim_offset_atr: Number(takeAfterPrefix("reclaim")),
    pa_retest_mode: variant.includes("same_bar")
      ? "same_bar"
      : variant.includes("next_bar_confirm")
        ? "next_bar_confirm"
        : "either",
    pa_retest_require_candle_color: variant.includes("color_on"),
  };
}

function liteTrades(trades: any[]): LiteTrade[] {
  return trades.map((t) => ({
    entry_time: t.entry_time,
    exit_time: t.exit_time,
    direction: t.direction,
    pnl_net_pct: t.pnl_net_pct,
  }));
}

function tradeKey(t: LiteTrade): string {
  return `${t.entry_time}_${t.direction}`;
}

function winRatePct(trades: LiteTrade[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter((t) => t.pnl_net_pct > 0).length;
  return round((wins / trades.length) * 100, 2);
}

function getSessionLabel(timestampSec: number): SessionLabel {
  const hour = new Date(timestampSec * 1000).getUTCHours();
  if (hour >= 13 && hour < 22) return "newyork";
  if (hour >= 7 && hour < 16) return "london";
  if (hour >= 0 && hour < 8) return "asia";
  return "offhours";
}

function sessionAllowed(label: SessionLabel, mode: SessionMode): boolean {
  if (mode === "all") return true;
  if (mode === "exclude_offhours") return label !== "offhours";
  if (mode === "london_newyork") return label === "london" || label === "newyork";
  return true;
}

function rsiGateAllowed(result: "pass" | "caution" | "reject", mode: RsiGateMode): boolean {
  if (mode === "all") return true;
  if (mode === "pass_or_caution") return result !== "reject";
  if (mode === "pass_only") return result === "pass";
  return true;
}

async function runVariant(candles1h: Candle[], candles1d: Candle[], variantKey: string, extras?: { pa_session_mode?: "all" | "exclude_offhours" | "london_newyork"; pa_rsi_gate?: "off" | "avoid_reject" | "pass_only" }) {
  const v = parseVariant(variantKey);
  return runBacktest({
    candles: candles1h,
    strategy: v.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: v.atr_sl_mult,
    atr_tp_mult: v.atr_tp_mult,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: v.pa_allow_pattern,
    pa_allow_true_breakout: v.pa_allow_true_breakout,
    pa_allow_trap: v.pa_allow_trap,
    pa_require_retest_on_continuation: v.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: v.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: v.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: v.pa_retest_reclaim_offset_atr,
    pa_retest_mode: v.pa_retest_mode,
    pa_retest_require_candle_color: v.pa_retest_require_candle_color,
    pa_session_mode: extras?.pa_session_mode ?? "all",
    pa_rsi_gate: extras?.pa_rsi_gate ?? "off",
  });
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  const closes = candles1h.map((c) => c.close);
  const rsiArr = calcRsiArr(closes, 14);
  const { adx: adxArr } = calcAdxArr(candles1h, 14);
  const timeToIndex = new Map(candles1h.map((c, i) => [c.time, i]));

  console.log(`[range] ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);

  const core = await runVariant(candles1h, candles1d, CORE_VARIANT);
  const aggressiveAddon = await runVariant(candles1h, candles1d, AGGRESSIVE_ADDON);
  const defensiveAddon = await runVariant(candles1h, candles1d, AGGRESSIVE_ADDON, {
    pa_session_mode: DEFENSIVE_SESSION_MODE,
    pa_rsi_gate: DEFENSIVE_RSI_GATE,
  });

  const coreTrades = liteTrades(core.trades as any[]);
  const coreMap = new Map(coreTrades.map((t) => [tradeKey(t), t]));
  const aggressiveAdded = liteTrades(aggressiveAddon.trades as any[]).filter((t) => !coreMap.has(tradeKey(t)));
  const defensiveAdded = liteTrades(defensiveAddon.trades as any[]).filter((t) => !coreMap.has(tradeKey(t)));
  const defensiveAddedSet = new Set(defensiveAdded.map((t) => tradeKey(t)));

  const annotatedAdded: AddedTradeState[] = aggressiveAdded.map((t) => {
    const idx = timeToIndex.get(t.entry_time);
    const safeIdx = idx ?? candles1h.findIndex((c) => c.time >= t.entry_time);
    const i = safeIdx >= 0 ? safeIdx : candles1h.length - 1;
    const rsiWindow = rsiArr.slice(Math.max(0, i - 8), i + 1).filter((v) => Number.isFinite(v));
    const priceWindow = closes.slice(Math.max(0, i - 8), i + 1).filter((v) => Number.isFinite(v));
    const rsiVal = Number.isFinite(rsiArr[i]) ? rsiArr[i] : 50;
    const adxVal = Number.isFinite(adxArr[i]) ? adxArr[i] : 0;
    const spectrum = analyzePaRsiSpectrum(rsiVal, rsiWindow, closes[i] ?? 0, priceWindow, adxVal);
    return {
      ...t,
      session: getSessionLabel(t.entry_time),
      adx: round(adxVal, 2),
      rsi: round(rsiVal, 2),
      rsi_filter: spectrum.filterResult,
    };
  });

  const rows: RuleRow[] = [];
  const sessionModes: SessionMode[] = ["all", "exclude_offhours", "london_newyork"];
  const rsiModes: RsiGateMode[] = ["all", "pass_or_caution", "pass_only"];
  const adxThresholds = [0, 18, 20, 25, 30, 35];

  for (const sessionMode of sessionModes) {
    for (const rsiMode of rsiModes) {
      for (const adxMin of adxThresholds) {
        const selectedAdded = annotatedAdded.filter((t) => (
          sessionAllowed(t.session, sessionMode)
          && rsiGateAllowed(t.rsi_filter, rsiMode)
          && t.adx >= adxMin
        ));
        const comboTrades = [...coreTrades, ...selectedAdded].sort((a, b) => a.entry_time - b.entry_time);
        const comboWin = winRatePct(comboTrades);
        const overlapWithDefensive = selectedAdded.filter((t) => defensiveAddedSet.has(tradeKey(t))).length;
        rows.push({
          session_mode: sessionMode,
          rsi_gate: rsiMode,
          adx_min: adxMin,
          selected_added_trades: selectedAdded.length,
          selected_added_win_rate_pct: winRatePct(selectedAdded),
          combo_total_trades: comboTrades.length,
          combo_win_rate_pct: comboWin,
          delta_vs_core_trades: comboTrades.length - core.total_trades,
          delta_vs_core_win_pct: round(comboWin - round(core.win_rate * 100, 2), 2),
          delta_vs_aggressive_trades: comboTrades.length - (coreTrades.length + aggressiveAdded.length),
          delta_vs_aggressive_win_pct: round(comboWin - winRatePct([...coreTrades, ...aggressiveAdded]), 2),
          overlap_with_defensive_added: overlapWithDefensive,
          extra_vs_defensive_added: selectedAdded.length - overlapWithDefensive,
        });
      }
    }
  }

  rows.sort((a, b) => {
    if (b.combo_win_rate_pct !== a.combo_win_rate_pct) return b.combo_win_rate_pct - a.combo_win_rate_pct;
    return b.combo_total_trades - a.combo_total_trades;
  });

  const aggressiveComboTrades = [...coreTrades, ...aggressiveAdded].sort((a, b) => a.entry_time - b.entry_time);
  const defensiveComboTrades = [...coreTrades, ...defensiveAdded].sort((a, b) => a.entry_time - b.entry_time);

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_dual_version_switch_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_dual_version_switch_${SYMBOL}_${ts}.md`);

  const topRows = rows.slice(0, 20);
  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    core_variant: CORE_VARIANT,
    aggressive_addon: AGGRESSIVE_ADDON,
    aggressive_combo: {
      total_trades: aggressiveComboTrades.length,
      win_rate_pct: winRatePct(aggressiveComboTrades),
      added_trades: aggressiveAdded.length,
      added_win_rate_pct: winRatePct(aggressiveAdded),
    },
    defensive_combo: {
      session_mode: DEFENSIVE_SESSION_MODE,
      rsi_gate: DEFENSIVE_RSI_GATE,
      total_trades: defensiveComboTrades.length,
      win_rate_pct: winRatePct(defensiveComboTrades),
      added_trades: defensiveAdded.length,
      added_win_rate_pct: winRatePct(defensiveAdded),
    },
    annotated_added_trades: annotatedAdded,
    rows,
  }, null, 2), "utf8");

  const table = topRows.map((r) => `| ${r.session_mode} | ${r.rsi_gate} | ${r.adx_min} | ${r.selected_added_trades} | ${r.selected_added_win_rate_pct}% | ${r.combo_total_trades} | ${r.combo_win_rate_pct}% | ${r.delta_vs_aggressive_trades >= 0 ? "+" : ""}${r.delta_vs_aggressive_trades} | ${r.delta_vs_aggressive_win_pct >= 0 ? "+" : ""}${r.delta_vs_aggressive_win_pct} | ${r.overlap_with_defensive_added} | ${r.extra_vs_defensive_added} |`).join("\n");

  const md = `# BTCUSDT 双版本切换规则搜索\n\n| 项目 | 数值 |\n| --- | ---: |\n| Core Variant | ${CORE_VARIANT} |\n| Aggressive Add-on | ${AGGRESSIVE_ADDON} |\n| Core Trades | ${coreTrades.length} |\n| Core Win Rate | ${winRatePct(coreTrades)}% |\n| Aggressive Combo Trades | ${aggressiveComboTrades.length} |\n| Aggressive Combo Win Rate | ${winRatePct(aggressiveComboTrades)}% |\n| Defensive Combo Trades | ${defensiveComboTrades.length} |\n| Defensive Combo Win Rate | ${winRatePct(defensiveComboTrades)}% |\n| Aggressive Added Trades | ${aggressiveAdded.length} |\n| Defensive Added Trades | ${defensiveAdded.length} |\n\n本搜索将 **双版本切换** 等价为：\n\n> 保留 Core 全部交易；对 Aggressive Add-on 真正新增的交易，依据 **时段 / RSI 状态 / ADX** 决定是否放行。\n\n| Session Mode | RSI Gate | ADX Min | Selected Added | Added Win | Combo Trades | Combo Win | Δ Trades vs 92 | Δ Win vs 92 | Overlap w/ Defensive | Extra vs Defensive |\n| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${table}\n`;

  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
