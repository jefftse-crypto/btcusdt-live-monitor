import fs from "node:fs";
import path from "node:path";
import { runBacktest } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

type TradeRiskRow = {
  entry_time: string;
  exit_time: string;
  direction: "long" | "short";
  entry_price: number;
  sl_price: number;
  tp_price: number;
  pnl_net_pct: number;
  stop_distance_pct: number;
  exit_reason: string;
  signal_score: number | null;
  entry_type: string | null;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function maxConsecutiveLosses(pnls: number[]): number {
  let streak = 0;
  let maxStreak = 0;
  for (const pnl of pnls) {
    if (pnl < 0) {
      streak += 1;
      if (streak > maxStreak) maxStreak = streak;
    } else {
      streak = 0;
    }
  }
  return maxStreak;
}

function nearestLeverageRisk(stopDistancePct: number) {
  return {
    est_margin_at_20x_pct: Number((stopDistancePct * 20).toFixed(2)),
    est_margin_at_30x_pct: Number((stopDistancePct * 30).toFixed(2)),
    est_margin_at_50x_pct: Number((stopDistancePct * 50).toFixed(2)),
  };
}

async function main() {
  console.log(`[run] analyze high leverage fit ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);

  const result = runBacktest({
    candles: candles1h,
    strategy: "pa",
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: 3.0,
    atr_tp_mult: 0.24,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
  });

  const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
  const lossPnls = result.trades.filter((t) => t.pnl_net_pct < 0).map((t) => t.pnl_net_pct);
  const winPnls = result.trades.filter((t) => t.pnl_net_pct > 0).map((t) => t.pnl_net_pct);
  const maxLossStreak = maxConsecutiveLosses(result.trades.map((t) => t.pnl_net_pct));
  const worstTrade = Math.min(...result.trades.map((t) => t.pnl_net_pct));
  const bestTrade = Math.max(...result.trades.map((t) => t.pnl_net_pct));
  const p50Stop = percentile(stopDistances, 0.5);
  const p75Stop = percentile(stopDistances, 0.75);
  const p90Stop = percentile(stopDistances, 0.9);
  const p95Stop = percentile(stopDistances, 0.95);

  const tradeRows: TradeRiskRow[] = result.trades.map((t) => ({
    entry_time: isoTime(t.entry_time),
    exit_time: isoTime(t.exit_time),
    direction: t.direction,
    entry_price: Number(t.entry_price.toFixed(4)),
    sl_price: Number(t.sl_price.toFixed(4)),
    tp_price: Number(t.tp_price.toFixed(4)),
    pnl_net_pct: Number(t.pnl_net_pct.toFixed(4)),
    stop_distance_pct: Number((Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100).toFixed(4)),
    exit_reason: t.exit_reason,
    signal_score: t.signal_score ?? null,
    entry_type: t.entry_type ?? null,
  }));

  const summary = {
    symbol: SYMBOL,
    range: {
      start: isoTime(candles1h[0]?.time),
      end: isoTime(candles1h[candles1h.length - 1]?.time),
    },
    params: {
      strategy: "pa",
      interval: "1h",
      htf_interval: "1d",
      atr_sl_mult: 3.0,
      atr_tp_mult: 0.24,
      enable_mtf_filter: true,
      enable_adx_filter: true,
      enable_trailing_stop: false,
    },
    performance: {
      total_trades: result.total_trades,
      win_rate_pct: Number((result.win_rate * 100).toFixed(2)),
      trades_per_2d: Number((result.total_trades / (YEAR_DAYS / 2)).toFixed(2)),
      profit_factor: Number(result.profit_factor.toFixed(2)),
      total_return_net_pct: Number(result.total_return_net.toFixed(4)),
      max_drawdown_pct: Number(result.max_drawdown.toFixed(4)),
      sharpe_ratio: Number(result.sharpe_ratio.toFixed(2)),
      max_loss_streak: maxLossStreak,
    },
    trade_distribution: {
      avg_win_pct: Number(mean(winPnls).toFixed(4)),
      avg_loss_pct: Number(mean(lossPnls).toFixed(4)),
      worst_trade_pct: Number(worstTrade.toFixed(4)),
      best_trade_pct: Number(bestTrade.toFixed(4)),
      median_stop_distance_pct: Number(p50Stop.toFixed(4)),
      p75_stop_distance_pct: Number(p75Stop.toFixed(4)),
      p90_stop_distance_pct: Number(p90Stop.toFixed(4)),
      p95_stop_distance_pct: Number(p95Stop.toFixed(4)),
      avg_stop_distance_pct: Number(mean(stopDistances).toFixed(4)),
    },
    leverage_stress_estimate: {
      median_stop: nearestLeverageRisk(p50Stop),
      p75_stop: nearestLeverageRisk(p75Stop),
      p90_stop: nearestLeverageRisk(p90Stop),
      p95_stop: nearestLeverageRisk(p95Stop),
      worst_trade: {
        at_20x_pct: Number((Math.abs(worstTrade) * 20).toFixed(2)),
        at_30x_pct: Number((Math.abs(worstTrade) * 30).toFixed(2)),
        at_50x_pct: Number((Math.abs(worstTrade) * 50).toFixed(2)),
      },
    },
    trades: tradeRows,
  };

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `analyze_high_leverage_fit_1h_${SYMBOL}_${ts}.json`);
  fs.writeFileSync(jsonPath, JSON.stringify(summary, null, 2));
  console.log(`[done] JSON: ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
