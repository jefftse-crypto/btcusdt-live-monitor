import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";
type PaSessionMode = "all" | "exclude_offhours" | "london_newyork";
type BreakEvenMode = "off" | "tp1_plus_fee" | "r1";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_soft_score: boolean;
  pa_retest_soft_bonus: number;
  pa_retest_soft_min_score: number;
  pa_pattern_type_soft_bonus: boolean;
  pa_pattern_retest_extra_bonus: number;
  pa_trap_retest_extra_bonus: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_reclaim_offset_atr: number;
  pa_dual_tf_resonance: boolean;
  pa_resonance_bias_window_bars: number;
  pa_resonance_require_key_level: boolean;
  pa_resonance_require_momentum: boolean;
  pa_resonance_use_15m_sl: boolean;
  pa_resonance_15m_sl_mult: number;
  pa_resonance_15m_tp_mult: number;
  pa_resonance_max_hold_bars_15m: number;
  pa_session_mode: PaSessionMode;
  pa_resonance_break_even_mode: BreakEvenMode;
  pa_resonance_enable_partial_take_profit: boolean;
  pa_resonance_min_score: number;
  pa_resonance_min_score_strong_bias: number;
  pa_resonance_min_score_normal_bias: number;
  pa_resonance_min_score_weak_bias: number;
  pa_resonance_only_strong_bias: boolean;
  pa_resonance_require_next_bar_confirmation: boolean;
};

type Row = {
  variant: string;
  atr_sl_mult: number;
  atr_tp_mult: number;
  bias_window_1h: number;
  min_score_normal: number;
  min_score_strong: number;
  min_score_weak: number;
  require_key_level: boolean;
  require_momentum: boolean;
  use_15m_sl: boolean;
  sl_15m_mult: number;
  tp_15m_mult: number;
  max_hold_bars_15m: number;
  session_mode: PaSessionMode;
  break_even_mode: BreakEvenMode;
  partial_take_profit: boolean;
  only_strong_bias: boolean;
  next_bar_confirmation: boolean;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_50x_pct: number;
  used_15m_execution_trades: number;
  hit_wr_target: boolean;
  hit_freq_target: boolean;
  hit_dual_target: boolean;
  score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

const BASELINE_KEY = "routea_base_v2_soft_w2_mom0";
const BASELINE_WIN_RATE = 38.2;
const BASELINE_PF = 0.71;
const BASELINE_TRADES = 68;
const BASELINE_P75_50X = 50.86;

const TARGET_WIN_RATE = 80;
const TARGET_TRADES_PER_2D = 1;
const TARGET_TRADES = Math.ceil((YEAR_DAYS / 2) * TARGET_TRADES_PER_2D);

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const round = (value: number, digits = 4) => Number(value.toFixed(digits));

function normalizeBinanceRow(row: unknown[]): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Number(row[0]);
  const open = parseFloat(String(row[1]));
  const high = parseFloat(String(row[2]));
  const low = parseFloat(String(row[3]));
  const close = parseFloat(String(row[4]));
  const volume = parseFloat(String(row[5]));
  if (!isFinite(time) || !isFinite(open) || !isFinite(close)) return null;
  return { time, open, high, low, close, volume };
}

function isoTime(ts: number): string {
  return new Date(ts).toISOString().slice(0, 16);
}

async function fetchWithRetry(url: string, label: string, maxAttempts = 5): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Binance ${label} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function calcScore(row: Omit<Row, "score">): number {
  const wrProgress = Math.min(1.2, row.win_rate_pct / TARGET_WIN_RATE) * 450;
  const freqProgress = Math.min(1.2, row.trades_per_2d / TARGET_TRADES_PER_2D) * 260;
  const pfReward = Math.min(2.0, row.profit_factor) * 120;
  const ddPenalty = Math.max(0, row.max_drawdown_pct - 15) * 3;
  const marginPenalty = Math.max(0, row.p75_margin_loss_50x_pct - BASELINE_P75_50X) * 1.5;
  const underFreqPenalty = Math.max(0, TARGET_TRADES - row.total_trades) * 0.45;
  const bonus = (row.hit_wr_target ? 180 : 0) + (row.hit_freq_target ? 120 : 0) + (row.hit_dual_target ? 400 : 0);
  return round(wrProgress + freqProgress + pfReward + bonus - ddPenalty - marginPenalty - underFreqPenalty, 2);
}

const BASE_VARIANT = {
  strategy: "pa" as BacktestStrategy,
  atr_sl_mult: 1.95,
  atr_tp_mult: 0.21,
  enable_mtf_filter: true,
  enable_adx_filter: true,
  enable_trailing_stop: false,
  pa_allow_pattern: true,
  pa_allow_true_breakout: false,
  pa_allow_trap: true,
  pa_require_retest_on_continuation: false,
  pa_retest_soft_score: true,
  pa_retest_soft_bonus: 0.5,
  pa_retest_soft_min_score: 7.5,
  pa_pattern_type_soft_bonus: false,
  pa_pattern_retest_extra_bonus: 0,
  pa_trap_retest_extra_bonus: 0,
  pa_retest_touch_tolerance_atr: 0.04,
  pa_retest_mode: "same_bar" as RetestMode,
  pa_retest_require_candle_color: true,
  pa_retest_lookback_bars: 20,
  pa_retest_reclaim_offset_atr: 0.03,
  pa_dual_tf_resonance: true,
};

function buildVariants(): Variant[] {
  const variants: Variant[] = [];
  const atrPairs = [
    { sl: 1.90, tp: 0.22 },
    { sl: 1.95, tp: 0.22 },
    { sl: 1.95, tp: 0.23 },
    { sl: 1.95, tp: 0.24 },
    { sl: 2.00, tp: 0.23 },
    { sl: 2.00, tp: 0.24 },
    { sl: 2.05, tp: 0.24 },
    { sl: 2.10, tp: 0.25 },
  ];
  const biasProfiles = [
    { normal: 40, strong: 40, weak: 40 },
    { normal: 50, strong: 45, weak: 60 },
  ];
  const keyLevelFlags = [true];
  const momentumFlags = [false];
  const biasWindows = [2];
  const holdBars15m = [192];
  const sessionModes: PaSessionMode[] = ["all"];
  const mechanismModes: Array<{ breakEven: BreakEvenMode; partial: boolean }> = [
    { breakEven: "off", partial: false },
  ];
  const strongBiasOnlyFlags = [false, true];
  const nextBarConfirmationFlags = [false, true];
  const requireRetestFlags = [false, true];
  const patternRetestExtraBonuses = [0];
  const use15mSlModes = [
    { use15m: false, sl15m: 1.2, tp15m: 0.15 },
  ];

  variants.push({
    key: BASELINE_KEY,
    ...BASE_VARIANT,
    pa_resonance_bias_window_bars: 2,
    pa_resonance_min_score: 40,
    pa_resonance_min_score_strong_bias: 40,
    pa_resonance_min_score_normal_bias: 40,
    pa_resonance_min_score_weak_bias: 40,
    pa_resonance_require_key_level: true,
    pa_resonance_require_momentum: false,
    pa_resonance_use_15m_sl: false,
    pa_resonance_15m_sl_mult: 1.2,
    pa_resonance_15m_tp_mult: 0.15,
    pa_resonance_max_hold_bars_15m: 192,
    pa_session_mode: "all",
    pa_resonance_break_even_mode: "off",
    pa_resonance_enable_partial_take_profit: false,
    pa_resonance_only_strong_bias: false,
    pa_resonance_require_next_bar_confirmation: false,
  });

  for (const atr of atrPairs) {
    for (const profile of biasProfiles) {
      for (const keyLevel of keyLevelFlags) {
        for (const momentum of momentumFlags) {
          for (const windowBars of biasWindows) {
            for (const holdBars of holdBars15m) {
              for (const sessionMode of sessionModes) {
                for (const mechanism of mechanismModes) {
                    for (const strongBiasOnly of strongBiasOnlyFlags) {
                      for (const nextBarConfirmation of nextBarConfirmationFlags) {
                        for (const requireRetest of requireRetestFlags) {
                          for (const patternRetestExtraBonus of patternRetestExtraBonuses) {
                            for (const exec of use15mSlModes) {

                        const key = [
                          `routea_focus`,
                          `hsl${atr.sl.toFixed(2)}`,
                          `htp${atr.tp.toFixed(2)}`,
                          `ns${profile.normal}`,
                          `ss${profile.strong}`,
                          `ws${profile.weak}`,
                          `mom${momentum ? 1 : 0}`,
                          `w${windowBars}`,
                          `hold${holdBars}`,
                          `sess${sessionMode === "exclude_offhours" ? "xoff" : "lny"}`,
                          `be${mechanism.breakEven === "off" ? "off" : "tp1f"}`,
                          `pt${mechanism.partial ? 1 : 0}`,
                          `sb${strongBiasOnly ? 1 : 0}`,
                          `cf${nextBarConfirmation ? 1 : 0}`,
                          `rr${requireRetest ? 1 : 0}`,
                          `preb${patternRetestExtraBonus.toFixed(1)}`,
                          `15m${exec.use15m ? `on_s${exec.sl15m.toFixed(2)}_t${exec.tp15m.toFixed(2)}` : "off"}`,
                        ].join("_");
                        variants.push({
                          key,
                          ...BASE_VARIANT,
                          atr_sl_mult: atr.sl,
                          atr_tp_mult: atr.tp,
                          pa_resonance_bias_window_bars: windowBars,
                          pa_resonance_min_score: profile.normal,
                          pa_resonance_min_score_strong_bias: profile.strong,
                          pa_resonance_min_score_normal_bias: profile.normal,
                          pa_resonance_min_score_weak_bias: profile.weak,
                          pa_resonance_require_key_level: keyLevel,
                          pa_resonance_require_momentum: momentum,
                          pa_resonance_use_15m_sl: exec.use15m,
                          pa_resonance_15m_sl_mult: exec.sl15m,
                          pa_resonance_15m_tp_mult: exec.tp15m,
                          pa_resonance_max_hold_bars_15m: holdBars,
                          pa_session_mode: sessionMode,
                          pa_require_retest_on_continuation: requireRetest,
                          pa_resonance_break_even_mode: mechanism.breakEven,
                          pa_resonance_enable_partial_take_profit: mechanism.partial,
                          pa_pattern_type_soft_bonus: patternRetestExtraBonus > 0,
                          pa_pattern_retest_extra_bonus: patternRetestExtraBonus,
                          pa_trap_retest_extra_bonus: 0,
                          pa_resonance_only_strong_bias: strongBiasOnly,
                          pa_resonance_require_next_bar_confirmation: nextBarConfirmation,
                        });
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

  return variants;
}

const VARIANTS = buildVariants();

async function main() {
  console.log(`[run] route a mechanism search 1h ${SYMBOL}`);
  console.log(`[fetch] 抓取 1H K 線...`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  console.log(`[fetch] 抓取 15m K 線...`);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 24 * 4 * YEAR_DAYS);
  console.log(`[fetch] 抓取 1D K 線...`);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "hit_wr_target" | "hit_freq_target" | "hit_dual_target" | "score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_adx_filter: variant.enable_adx_filter,
      enable_trailing_stop: variant.enable_trailing_stop,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_retest_soft_bonus: variant.pa_retest_soft_bonus,
      pa_retest_soft_min_score: variant.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
      pa_pattern_type_soft_bonus: variant.pa_pattern_type_soft_bonus,
      pa_pattern_retest_extra_bonus: variant.pa_pattern_retest_extra_bonus,
      pa_trap_retest_extra_bonus: variant.pa_trap_retest_extra_bonus,
      pa_retest_mode: variant.pa_retest_mode,
      pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
      pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
      pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
      pa_dual_tf_resonance: variant.pa_dual_tf_resonance,
      pa_session_mode: variant.pa_session_mode,
      pa_resonance_candles_15m: candles15m,
      pa_resonance_bias_window_bars: variant.pa_resonance_bias_window_bars,
      pa_resonance_min_score: variant.pa_resonance_min_score,
      pa_resonance_min_score_strong_bias: variant.pa_resonance_min_score_strong_bias,
      pa_resonance_min_score_normal_bias: variant.pa_resonance_min_score_normal_bias,
      pa_resonance_min_score_weak_bias: variant.pa_resonance_min_score_weak_bias,
      pa_resonance_require_key_level: variant.pa_resonance_require_key_level,
      pa_resonance_require_momentum: variant.pa_resonance_require_momentum,
      pa_resonance_use_15m_sl: variant.pa_resonance_use_15m_sl,
      pa_resonance_15m_sl_mult: variant.pa_resonance_15m_sl_mult,
      pa_resonance_15m_tp_mult: variant.pa_resonance_15m_tp_mult,
      pa_resonance_max_hold_bars_15m: variant.pa_resonance_max_hold_bars_15m,
      pa_resonance_break_even_mode: variant.pa_resonance_break_even_mode,
      pa_resonance_enable_partial_take_profit: variant.pa_resonance_enable_partial_take_profit,
      pa_resonance_only_strong_bias: variant.pa_resonance_only_strong_bias,
      pa_resonance_require_next_bar_confirmation: variant.pa_resonance_require_next_bar_confirmation,
    });

    const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = round(percentile(stopDistances, 0.75), 4);
    const p75MarginLoss50x = round(p75Stop * 50, 2);
    const used15mExecutionTrades = result.trades.filter((t) => t.used_15m_execution).length;

    const row = {
      variant: variant.key,
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      bias_window_1h: variant.pa_resonance_bias_window_bars,
      min_score_normal: variant.pa_resonance_min_score_normal_bias,
      min_score_strong: variant.pa_resonance_min_score_strong_bias,
      min_score_weak: variant.pa_resonance_min_score_weak_bias,
      require_key_level: variant.pa_resonance_require_key_level,
      require_momentum: variant.pa_resonance_require_momentum,
      use_15m_sl: variant.pa_resonance_use_15m_sl,
      sl_15m_mult: variant.pa_resonance_15m_sl_mult,
      tp_15m_mult: variant.pa_resonance_15m_tp_mult,
      max_hold_bars_15m: variant.pa_resonance_max_hold_bars_15m,
      session_mode: variant.pa_session_mode,
      break_even_mode: variant.pa_resonance_break_even_mode,
      partial_take_profit: variant.pa_resonance_enable_partial_take_profit,
      only_strong_bias: variant.pa_resonance_only_strong_bias,
      next_bar_confirmation: variant.pa_resonance_require_next_bar_confirmation,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 1),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net * 100, 2),
      max_drawdown_pct: round(result.max_drawdown * 100, 2),
      p75_stop_distance_pct: p75Stop,
      p75_margin_loss_50x_pct: p75MarginLoss50x,
      used_15m_execution_trades: used15mExecutionTrades,
    };

    console.log(
      `[done] ${variant.key} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} htf=${row.atr_sl_mult}/${row.atr_tp_mult} 15m=${row.use_15m_sl ? `${row.sl_15m_mult}/${row.tp_15m_mult}` : "off"} session=${row.session_mode} be=${row.break_even_mode} pt=${row.partial_take_profit ? 1 : 0} sb=${row.only_strong_bias ? 1 : 0} cf=${row.next_bar_confirmation ? 1 : 0}`
    );
    rowsRaw.push(row);
  }

  const rows: Row[] = rowsRaw.map((row) => {
    const hit_wr_target = row.win_rate_pct >= TARGET_WIN_RATE;
    const hit_freq_target = row.trades_per_2d >= TARGET_TRADES_PER_2D;
    const hit_dual_target = hit_wr_target && hit_freq_target;
    const score = calcScore({
      ...row,
      hit_wr_target,
      hit_freq_target,
      hit_dual_target,
    });
    return {
      ...row,
      hit_wr_target,
      hit_freq_target,
      hit_dual_target,
      score,
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const targetCmp = Number(b.hit_dual_target) - Number(a.hit_dual_target);
    if (targetCmp !== 0) return targetCmp;
    const wrCmp = Number(b.hit_wr_target) - Number(a.hit_wr_target);
    if (wrCmp !== 0) return wrCmp;
    const freqCmp = Number(b.hit_freq_target) - Number(a.hit_freq_target);
    if (freqCmp !== 0) return freqCmp;
    const scoreCmp = b.score - a.score;
    if (Math.abs(scoreCmp) > 1e-9) return scoreCmp;
    const pfCmp = b.profit_factor - a.profit_factor;
    if (Math.abs(pfCmp) > 1e-9) return pfCmp;
    return b.win_rate_pct - a.win_rate_pct;
  });

  const best = sorted[0];
  const hitTargetRows = sorted.filter((row) => row.hit_dual_target);
  const improved = sorted.filter((row) => row.profit_factor > BASELINE_PF || row.win_rate_pct > BASELINE_WIN_RATE || row.total_trades > BASELINE_TRADES);
  const top20 = sorted.slice(0, 20);
  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `search_route_a_highwin_focus_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_route_a_highwin_focus_${SYMBOL}_${ts}.md`);

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    baseline: {
      key: BASELINE_KEY,
      win_rate_pct: BASELINE_WIN_RATE,
      profit_factor: BASELINE_PF,
      trades: BASELINE_TRADES,
      p75_margin_loss_50x_pct: BASELINE_P75_50X,
    },
    targets: {
      win_rate_pct: TARGET_WIN_RATE,
      trades_per_2d: TARGET_TRADES_PER_2D,
      annual_trades: TARGET_TRADES,
    },
    total_variants: VARIANTS.length,
    hit_target_count: hitTargetRows.length,
    improved_count: improved.length,
    rows: sorted,
  }, null, 2));

  const topTable = top20.map((row) =>
    `| ${row.variant} | ${row.total_trades} | ${row.trades_per_2d} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.total_return_net_pct}% | ${row.atr_sl_mult}/${row.atr_tp_mult} | ${row.use_15m_sl ? `${row.sl_15m_mult}/${row.tp_15m_mult}` : "off"} | ${row.session_mode} | ${row.break_even_mode} | ${row.partial_take_profit ? "on" : "off"} | ${row.only_strong_bias ? "on" : "off"} | ${row.next_bar_confirmation ? "on" : "off"} | ${row.bias_window_1h} | ${row.max_hold_bars_15m} | ${row.min_score_strong}/${row.min_score_normal}/${row.min_score_weak} | ${row.require_key_level ? "on" : "off"} | ${row.require_momentum ? "on" : "off"} | ${row.hit_dual_target ? "yes" : "no"} |`
  ).join("\n");

  const targetLines = hitTargetRows.length === 0
    ? "本輪沒有任何變體同時達到 **勝率 80%** 與 **平均每兩天至少 1 筆交易**。"
    : hitTargetRows.slice(0, 10).map((row, idx) => `${idx + 1}. **${row.variant}**：勝率 ${row.win_rate_pct}%、交易 ${row.total_trades}、PF ${row.profit_factor}、1H ATR ${row.atr_sl_mult}/${row.atr_tp_mult}、15m ATR ${row.use_15m_sl ? `${row.sl_15m_mult}/${row.tp_15m_mult}` : "off"}、Session ${row.session_mode}、BE ${row.break_even_mode}、PartialTP ${row.partial_take_profit ? "on" : "off"}、StrongOnly ${row.only_strong_bias ? "on" : "off"}、Confirm ${row.next_bar_confirmation ? "on" : "off"}。`).join("\n");

  const improvedLines = improved.length === 0
    ? "本輪未找到任何在 PF、勝率或交易頻率上超過舊基線的候選。"
    : improved.slice(0, 10).map((row, idx) => `${idx + 1}. **${row.variant}**：勝率 ${row.win_rate_pct}%、交易 ${row.total_trades}、PF ${row.profit_factor}、1H ATR ${row.atr_sl_mult}/${row.atr_tp_mult}、15m ATR ${row.use_15m_sl ? `${row.sl_15m_mult}/${row.tp_15m_mult}` : "off"}、Session ${row.session_mode}、BE ${row.break_even_mode}、PartialTP ${row.partial_take_profit ? "on" : "off"}、StrongOnly ${row.only_strong_bias ? "on" : "off"}、Confirm ${row.next_bar_confirmation ? "on" : "off"}、Strong/Normal/Weak = ${row.min_score_strong}/${row.min_score_normal}/${row.min_score_weak}。`).join("\n");

  const md = `# 路線 A：1H 高勝率參數移植 + 15m 執行聚焦搜索報告

**幣種**：${SYMBOL}  
**策略**：PA（1H 定方向 + 15m 共振執行）  
**搜索時間**：${new Date().toISOString()}  
**總變體數**：${VARIANTS.length}  
**達標候選數**：${hitTargetRows.length}  
**改良候選數**：${improved.length}

## 一、硬目標

| 指標 | 目標 |
| --- | ---: |
| 勝率 | ${TARGET_WIN_RATE}% |
| 平均每兩天成交數 | ${TARGET_TRADES_PER_2D} |
| 年化最低交易數 | ${TARGET_TRADES} |

## 二、對照基線

| 指標 | 數值 |
| --- | ---: |
| 基線變體 | ${BASELINE_KEY} |
| 年交易數 | ${BASELINE_TRADES} |
| 勝率 | ${BASELINE_WIN_RATE}% |
| PF | ${BASELINE_PF} |
| 50x P75 損耗 | ${BASELINE_P75_50X}% |

## 三、本輪機制層搜索維度

| 維度 | 候選值 |
| --- | --- |
| \`atr_sl_mult / atr_tp_mult\` | 3.00/0.22 / 3.00/0.24 / 3.25/0.22 / 3.25/0.24 / 3.50/0.24 |
| \`pa_resonance_min_score_normal/strong/weak\` | 45/40/55 / 50/45/60 / 55/50/65 / 60/55/70 |
| \`pa_resonance_require_key_level\` | true |
| \`pa_resonance_require_momentum\` | false / true |
| \`pa_resonance_bias_window_bars\` | 1 / 2 |
| \`pa_resonance_use_15m_sl\` | off |
| \`pa_resonance_15m_sl_mult / tp_mult\` | 固定為 off（本輪先驗排除） |
| \`pa_resonance_max_hold_bars_15m\` | 16 / 24 / 32 |
| \`pa_session_mode\` | exclude_offhours / london_newyork |
| \`pa_resonance_break_even_mode\` | off / tp1_plus_fee |
| \`pa_resonance_enable_partial_take_profit\` | false / true |
| \`pa_resonance_only_strong_bias\` | false / true |
| \`pa_resonance_require_next_bar_confirmation\` | false / true |

## 四、Top 20 結果

| Variant | Trades | /2d | Win Rate | PF | Net Return | 1H ATR | 15m ATR | Session | BE | PartialTP | StrongOnly | Confirm | Window | Hold15m | S/N/W | Key | Mom | HitTarget |
| --- | ---: | ---: | ---: | ---: | ---: | --- | --- | --- | --- | --- | --- | --- | ---: | ---: | --- | --- | --- | --- |
${topTable}


## 五、達標候選

${targetLines}

## 六、優於舊基線的候選

${improvedLines}

## 七、結論

本輪最佳變體為 **${best.variant}**，結果為：年交易 **${best.total_trades}**、每兩天交易 **${best.trades_per_2d}**、勝率 **${best.win_rate_pct}%**、PF **${best.profit_factor}**、淨收益 **${best.total_return_net_pct}%**、1H ATR **${best.atr_sl_mult}/${best.atr_tp_mult}**、15m ATR **${best.use_15m_sl ? `${best.sl_15m_mult}/${best.tp_15m_mult}` : "off"}**。若本輪仍未達標，代表單靠把高勝率 1H 參數直接移植到路線 A 仍不夠，下一輪就要進一步重構 15m 觸發條件本身，而不只是調整執行風控。
`;

  await fs.writeFile(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD:   ${mdPath}`);
  console.log(`[best] ${best.variant} trades=${best.total_trades} /2d=${best.trades_per_2d} win=${best.win_rate_pct}% pf=${best.profit_factor}`);
}

main().catch((err) => {
  console.error("[fatal]", err);
  process.exit(1);
});
