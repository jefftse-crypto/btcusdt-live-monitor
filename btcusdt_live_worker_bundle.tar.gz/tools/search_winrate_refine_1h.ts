import fs from "node:fs";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
};

type Row = {
  variant: string;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  avg_stop_distance_pct: number;
  median_stop_distance_pct: number;
  p75_stop_distance_pct: number;
  p90_stop_distance_pct: number;
  worst_trade_pct: number;
  avg_loss_pct: number;
  max_loss_streak: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  winrate_priority_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const MIN_WIN_RATE = 75;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function frange(start: number, end: number, step: number): number[] {
  const values: number[] = [];
  for (let cur = start; cur <= end + 1e-9; cur += step) values.push(round(cur, 3));
  return values;
}

function buildVariants(): Variant[] {
  const sls = frange(1.9, 2.05, 0.01);
  const tps = frange(0.195, 0.22, 0.005);
  const filterSets = [
    { enable_mtf_filter: true, enable_adx_filter: true, enable_trailing_stop: false, tag: "mtfOn_adxOn_tsOff" },
    { enable_mtf_filter: true, enable_adx_filter: true, enable_trailing_stop: true, tag: "mtfOn_adxOn_tsOn" },
    { enable_mtf_filter: true, enable_adx_filter: false, enable_trailing_stop: false, tag: "mtfOn_adxOff_tsOff" },
    { enable_mtf_filter: false, enable_adx_filter: true, enable_trailing_stop: false, tag: "mtfOff_adxOn_tsOff" },
  ];
  const variants: Variant[] = [];
  for (const sl of sls) {
    for (const tp of tps) {
      for (const f of filterSets) {
        variants.push({
          key: `pa_sl${sl.toFixed(2)}_tp${tp.toFixed(3)}_${f.tag}`,
          strategy: "pa",
          atr_sl_mult: sl,
          atr_tp_mult: tp,
          enable_mtf_filter: f.enable_mtf_filter,
          enable_adx_filter: f.enable_adx_filter,
          enable_trailing_stop: f.enable_trailing_stop,
        });
      }
    }
  }
  return variants;
}

const VARIANTS = buildVariants();

function isoTime(value: number | undefined): string { return value ? new Date(value * 1000).toISOString() : ""; }
function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K 線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function maxConsecutiveLosses(pnls: number[]): number {
  let streak = 0;
  let maxStreak = 0;
  for (const pnl of pnls) {
    if (pnl < 0) {
      streak += 1;
      if (streak > maxStreak) maxStreak = streak;
    } else {
      streak = 0;
    }
  }
  return maxStreak;
}

function calcMarginFractionForRiskBudget(riskBudgetPct: number, leverage: number, stopDistancePct: number): number {
  if (leverage <= 0 || stopDistancePct <= 0) return 0;
  return Math.min(100, (riskBudgetPct / (leverage * stopDistancePct)) * 100);
}

function calcWinratePriorityScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "winrate_priority_score">): number {
  const coreOk = row.total_trades >= MIN_TRADES && row.win_rate_pct >= MIN_WIN_RATE && row.profit_factor > 1;
  if (!coreOk) return -999;
  const reward = row.win_rate_pct * 5 + row.profit_factor * 35 + Math.max(0, row.total_trades - MIN_TRADES) * 0.03;
  const penalty = row.p75_stop_distance_pct * 20 + Math.max(0, row.p75_margin_loss_50x_pct - 82) * 0.7 + Math.max(0, row.max_loss_streak - 3) * 4;
  return round(reward - penalty, 2);
}

async function main() {
  console.log(`[run] winrate refine 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rows: Row[] = [];
  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_fee: true,
      enable_trailing_stop: variant.enable_trailing_stop,
      enable_adx_filter: variant.enable_adx_filter,
      htf_candles: candles1d,
      entry_candles: candles1h,
      use_true_mtf: true,
    });

    const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const lossPnls = result.trades.filter((t) => t.pnl_net_pct < 0).map((t) => Math.abs(t.pnl_net_pct) * 100);
    const p75 = percentile(stopDistances, 0.75);
    const rowBase = {
      variant: variant.key,
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_adx_filter: variant.enable_adx_filter,
      enable_trailing_stop: variant.enable_trailing_stop,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 2),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net, 4),
      max_drawdown_pct: round(result.max_drawdown, 4),
      avg_stop_distance_pct: round(mean(stopDistances), 4),
      median_stop_distance_pct: round(percentile(stopDistances, 0.5), 4),
      p75_stop_distance_pct: round(p75, 4),
      p90_stop_distance_pct: round(percentile(stopDistances, 0.9), 4),
      worst_trade_pct: round(Math.min(...result.trades.map((t) => t.pnl_net_pct * 100), 0), 4),
      avg_loss_pct: round(mean(lossPnls), 4),
      max_loss_streak: maxConsecutiveLosses(result.trades.map((t) => t.pnl_net_pct)),
      p75_margin_loss_20x_pct: round(p75 * 20, 2),
      p75_margin_loss_30x_pct: round(p75 * 30, 2),
      p75_margin_loss_50x_pct: round(p75 * 50, 2),
      recommended_margin_fraction_20x_1pct: round(calcMarginFractionForRiskBudget(1, 20, p75), 2),
      recommended_margin_fraction_30x_1pct: round(calcMarginFractionForRiskBudget(1, 30, p75), 2),
      recommended_margin_fraction_50x_1pct: round(calcMarginFractionForRiskBudget(1, 50, p75), 2),
    };
    const qualifiedCore = rowBase.total_trades >= MIN_TRADES && rowBase.win_rate_pct >= MIN_WIN_RATE && rowBase.profit_factor > 1;
    const guardOk = rowBase.p75_margin_loss_50x_pct <= 85 && rowBase.p75_stop_distance_pct <= 1.70;
    const row: Row = {
      ...rowBase,
      qualified_core_requirements: qualifiedCore,
      high_leverage_guard_ok: guardOk,
      winrate_priority_score: calcWinratePriorityScore(rowBase),
    };
    rows.push(row);
    console.log(`[done] ${row.variant} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} p75=${row.p75_stop_distance_pct}% guard=${row.high_leverage_guard_ok}`);
  }

  const qualified = rows
    .filter((row) => row.qualified_core_requirements)
    .sort((a, b) => b.win_rate_pct - a.win_rate_pct || Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok) || b.profit_factor - a.profit_factor || a.p75_stop_distance_pct - b.p75_stop_distance_pct || b.total_trades - a.total_trades);

  const qualifiedGuarded = qualified.filter((row) => row.high_leverage_guard_ok);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_winrate_refine_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_winrate_refine_1h_${SYMBOL}_${ts}.md`);

  fs.writeFileSync(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    min_trades: MIN_TRADES,
    min_win_rate: MIN_WIN_RATE,
    variants_scanned: VARIANTS.length,
    best_guarded: qualifiedGuarded.slice(0, 20),
    best_all_qualified: qualified.slice(0, 30),
    rows,
  }, null, 2));

  const tableAll = (qualified.length > 0 ? qualified.slice(0, 20) : []).map((r, i) => `| ${i + 1} | ${r.variant} | ${r.total_trades} | ${r.trades_per_2d} | ${r.win_rate_pct}% | ${r.profit_factor} | ${r.total_return_net_pct}% | ${r.p75_stop_distance_pct}% | ${r.p75_margin_loss_50x_pct}% | ${r.high_leverage_guard_ok ? "是" : "否"} |`).join("\n") || `| 1 | 無符合核心條件候選 | 0 | 0 | 0% | 0 | 0% | 0% | 0% | 否 |`;
  const tableGuarded = (qualifiedGuarded.length > 0 ? qualifiedGuarded.slice(0, 12) : []).map((r, i) => `| ${i + 1} | ${r.variant} | ${r.total_trades} | ${r.win_rate_pct}% | ${r.profit_factor} | ${r.p75_stop_distance_pct}% | ${r.p75_margin_loss_20x_pct}% | ${r.p75_margin_loss_30x_pct}% | ${r.p75_margin_loss_50x_pct}% | ${r.recommended_margin_fraction_50x_1pct}% |`).join("\n") || `| 1 | 無同時滿足高槓桿守門條件的候選 | 0 | 0% | 0 | 0% | 0% | 0% | 0% | 0% |`;

  const md = `# ${SYMBOL} 1H 勝率優先高槓桿精修搜索\n\n本報告以目前高槓桿主候選 **PA / SL 1.95 / TP 0.21** 為中心，進一步用更細粒度方式搜索 **SL 1.90–2.05**、**TP 0.195–0.220**，並有限度測試 **MTF / ADX / Trailing Stop** 組合，目標是在保留 **年交易數至少 ${MIN_TRADES} 筆、勝率至少 ${MIN_WIN_RATE}%、PF > 1** 的前提下，嘗試把勝率再往上推，同時盡量不明顯惡化 20–50 倍槓桿風控。資料來源為 Binance 公開 K 線端點 [1]。\n\n| 項目 | 值 |\n| --- | --- |\n| 標的 | ${SYMBOL} |\n| 掃描範圍 | SL 1.90–2.05、TP 0.195–0.220、有限濾網組合 |\n| 組合總數 | ${VARIANTS.length} |\n| 核心條件 | 年交易數 >= ${MIN_TRADES}、勝率 >= ${MIN_WIN_RATE}%、PF > 1 |\n| 高槓桿守門條件 | P75 止損距離 <= 1.70%，且 50x P75 保證金損耗 <= 85% |\n\n## 符合核心條件的勝率排序前列結果\n\n| 排名 | 變體 | 年交易數 | 每兩天交易數 | 勝率 | PF | 淨收益 | P75 止損距離 | 50x P75 保證金損耗 | 通過高槓桿守門 |\n| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |\n${tableAll}\n\n## 同時通過高槓桿守門條件的候選\n\n| 排名 | 變體 | 年交易數 | 勝率 | PF | P75 止損距離 | 20x P75 保證金損耗 | 30x P75 保證金損耗 | 50x P75 保證金損耗 | 50x 建議最大保證金倉位比 |\n| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n${tableGuarded}\n\n## References\n\n[1]: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data \"Binance Spot API Docs - Kline/Candlestick data\"\n`;

  fs.writeFileSync(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD: ${mdPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
