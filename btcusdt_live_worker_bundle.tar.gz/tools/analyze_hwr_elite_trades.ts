import fs from "node:fs";
import { calcAdxArr, calcEmaArr as calcEma, detectLiquiditySweep } from "../server/utils/indicators.ts";
import type { Candle } from "../shared/cryptoTypes.ts";

const REPORT_PATH = "/home/ubuntu/crypto-dashboard-v5.9/reports/backtest_all_strategies_1d1h_1y_BTCUSDT_2026-04-13T17-16-40-626Z.json";
const report = JSON.parse(fs.readFileSync(REPORT_PATH, "utf8"));
const elite = report.raw_results.find((r: any) => r.strategy === "hwr_model_a_elite");
if (!elite) throw new Error("找不到 hwr_model_a_elite");

async function fetchCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  const PAGE_LIMIT = 1000;

  while (candles.length < targetCount) {
    const params = new URLSearchParams({
      symbol,
      interval,
      limit: String(PAGE_LIMIT),
      endTime: String(endTime),
    });
    const res = await fetch(`https://api.binance.com/api/v3/klines?${params.toString()}`, {
      headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) throw new Error(`Binance 回傳 ${res.status}`);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload.map((row: any[]) => ({
      time: Math.floor(Number(row[0]) / 1000),
      open: Number(row[1]),
      high: Number(row[2]),
      low: Number(row[3]),
      close: Number(row[4]),
      volume: Number(row[5]),
    }));
    candles.unshift(...batch);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
  }
  return candles.slice(-targetCount);
}

const symbol = report.symbol as string;
const candles = await fetchCandles(symbol, "1h", 24 * 365);
const closes = candles.map(c => c.close);
const ema20 = calcEma(closes, 20);
const ema50 = calcEma(closes, 50);
const ema200 = calcEma(closes, 200);
const adx = calcAdxArr(candles, 14);

for (const trade of elite.trades) {
  const idx = candles.findIndex(c => c.time === trade.entry_time - 3600);
  const entryIdx = candles.findIndex(c => c.time === trade.entry_time);
  const signalIdx = idx >= 0 ? idx : entryIdx - 1;
  const c = candles[signalIdx];
  const sweep = detectLiquiditySweep(candles.slice(Math.max(0, signalIdx - 60), signalIdx + 1), c.close);
  const e20 = ema20[signalIdx];
  const e50 = ema50[signalIdx];
  const e200 = ema200[signalIdx];
  console.log(JSON.stringify({
    trade_time: new Date(trade.entry_time * 1000).toISOString(),
    direction: trade.direction,
    pnl_net_pct: trade.pnl_net_pct,
    exit_reason: trade.exit_reason,
    signal_close: c.close,
    ema20: Number(e20?.toFixed(2)),
    ema50: Number(e50?.toFixed(2)),
    ema200: Number(e200?.toFixed(2)),
    ema_gap_20_50_pct: Number((((e20 - e50) / e50) * 100).toFixed(3)),
    price_vs_ema50_pct: Number((((c.close - e50) / e50) * 100).toFixed(3)),
    price_vs_ema200_pct: Number((((c.close - e200) / e200) * 100).toFixed(3)),
    adx: Number((adx[signalIdx] ?? 0).toFixed(2)),
    ssl_swept: sweep.sslSwept,
    ssl_strength: sweep.sslStrength,
    bsl_swept: sweep.bslSwept,
    bsl_strength: sweep.bslStrength,
    ssl_reclaimed: sweep.sslReclaimed,
    bsl_reclaimed: sweep.bslReclaimed,
  }, null, 2));
}
