import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
};

type Row = {
  variant: string;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_main_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  delta_p75_stop_distance_pct: number;
  refine_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function buildVariants(): Variant[] {
  const lookbacks = [12, 16, 20, 24];
  const touchTolerances = [0.04, 0.08, 0.12];
  const reclaimOffsets = [0, 0.02, 0.04];
  const modes: RetestMode[] = ["same_bar", "next_bar_confirm", "either"];
  const requireColors = [true, false];
  const variants: Variant[] = [];

  for (const pa_retest_lookback_bars of lookbacks) {
    for (const pa_retest_touch_tolerance_atr of touchTolerances) {
      for (const pa_retest_reclaim_offset_atr of reclaimOffsets) {
        for (const pa_retest_mode of modes) {
          for (const pa_retest_require_candle_color of requireColors) {
            variants.push({
              key: [
                `pa_sl${BASE_SL.toFixed(2)}`,
                `tp${BASE_TP.toFixed(2)}`,
                "pattern_on",
                "breakout_off",
                "trap_on",
                "retest_on",
                `lb${pa_retest_lookback_bars}`,
                `touch${pa_retest_touch_tolerance_atr.toFixed(2)}`,
                `reclaim${pa_retest_reclaim_offset_atr.toFixed(2)}`,
                pa_retest_mode,
                pa_retest_require_candle_color ? "color_on" : "color_off",
              ].join("_"),
              strategy: "pa",
              atr_sl_mult: BASE_SL,
              atr_tp_mult: BASE_TP,
              enable_mtf_filter: true,
              enable_adx_filter: true,
              enable_trailing_stop: false,
              pa_allow_pattern: true,
              pa_allow_true_breakout: false,
              pa_allow_trap: true,
              pa_require_retest_on_continuation: true,
              pa_retest_lookback_bars,
              pa_retest_touch_tolerance_atr,
              pa_retest_reclaim_offset_atr,
              pa_retest_mode,
              pa_retest_require_candle_color,
            });
          }
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();
const MAIN_BASELINE_KEY = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_main_keep_v1`;
const RETEST_BASELINE_KEY = `pa_sl${BASE_SL.toFixed(2)}_tp${BASE_TP.toFixed(2)}_pattern_on_breakout_off_trap_on_retest_on_lb20_touch0.08_reclaim0.03_same_bar_color_on`;

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function calcMarginFractionForRiskBudget(riskBudgetPct: number, leverage: number, stopDistancePct: number): number {
  if (leverage <= 0 || stopDistancePct <= 0) return 0;
  return Math.min(100, (riskBudgetPct / (leverage * stopDistancePct)) * 100);
}

function calcRefineScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_main_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_p75_stop_distance_pct" | "refine_score">): number {
  const reward = row.win_rate_pct * 8 + row.profit_factor * 28 + Math.max(0, row.total_trades - 150) * 0.03;
  const penalty = Math.max(0, 180 - row.total_trades) * 0.25 + Math.max(0, row.p75_margin_loss_50x_pct - 82) * 1.1 + row.p75_stop_distance_pct * 18;
  return round(reward - penalty, 2);
}

async function evaluateVariant(candles1h: Candle[], candles1d: Candle[], variant: Variant) {
  const result = runBacktest({
    candles: candles1h,
    strategy: variant.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: variant.atr_sl_mult,
    atr_tp_mult: variant.atr_tp_mult,
    enable_mtf_filter: variant.enable_mtf_filter,
    enable_fee: true,
    enable_trailing_stop: variant.enable_trailing_stop,
    enable_adx_filter: variant.enable_adx_filter,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: variant.pa_allow_pattern,
    pa_allow_true_breakout: variant.pa_allow_true_breakout,
    pa_allow_trap: variant.pa_allow_trap,
    pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
    pa_retest_mode: variant.pa_retest_mode,
    pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
  });

  const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
  const p75 = percentile(stopDistances, 0.75);

  return {
    variant: variant.key,
    total_trades: result.total_trades,
    trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
    win_rate_pct: round(result.win_rate * 100, 2),
    profit_factor: round(result.profit_factor, 3),
    total_return_net_pct: round(result.total_return_net * 100, 3),
    max_drawdown_pct: round(result.max_drawdown * 100, 3),
    p75_stop_distance_pct: round(p75, 4),
    p75_margin_loss_20x_pct: round(p75 * 20, 2),
    p75_margin_loss_30x_pct: round(p75 * 30, 2),
    p75_margin_loss_50x_pct: round(p75 * 50, 2),
    recommended_margin_fraction_20x_1pct: round(calcMarginFractionForRiskBudget(1, 20, p75), 2),
    recommended_margin_fraction_30x_1pct: round(calcMarginFractionForRiskBudget(1, 30, p75), 2),
    recommended_margin_fraction_50x_1pct: round(calcMarginFractionForRiskBudget(1, 50, p75), 2),
    pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
    pa_retest_mode: variant.pa_retest_mode,
    pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
  };
}

async function main() {
  console.log(`[run] retest refine 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1D+1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const mainBaseline = await evaluateVariant(candles1h, candles1d, {
    key: MAIN_BASELINE_KEY,
    strategy: "pa",
    atr_sl_mult: BASE_SL,
    atr_tp_mult: BASE_TP,
    enable_mtf_filter: true,
    enable_adx_filter: true,
    enable_trailing_stop: false,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: false,
    pa_retest_lookback_bars: 20,
    pa_retest_touch_tolerance_atr: 0.08,
    pa_retest_reclaim_offset_atr: 0.03,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
  });

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_main_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_p75_stop_distance_pct" | "refine_score">> = [];
  for (const variant of VARIANTS) {
    const row = await evaluateVariant(candles1h, candles1d, variant);
    rowsRaw.push(row);
    console.log(`[done] ${variant.key} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor}`);
  }

  const retestBaseline = rowsRaw.find((row) => row.variant === RETEST_BASELINE_KEY) ?? null;

  const rows: Row[] = rowsRaw.map((row) => {
    const qualified_core_requirements = row.total_trades >= MIN_TRADES && row.profit_factor > 1;
    const high_leverage_guard_ok = row.p75_margin_loss_50x_pct <= 82;
    const beats_main_winrate = row.win_rate_pct > mainBaseline.win_rate_pct;
    const delta_win_rate_pct = round(row.win_rate_pct - mainBaseline.win_rate_pct, 2);
    const delta_profit_factor = round(row.profit_factor - mainBaseline.profit_factor, 3);
    const delta_total_trades = row.total_trades - mainBaseline.total_trades;
    const delta_p75_stop_distance_pct = round(row.p75_stop_distance_pct - mainBaseline.p75_stop_distance_pct, 4);
    return {
      ...row,
      qualified_core_requirements,
      high_leverage_guard_ok,
      beats_main_winrate,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      delta_p75_stop_distance_pct,
      refine_score: calcRefineScore(row),
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const qa = Number(b.qualified_core_requirements) - Number(a.qualified_core_requirements);
    if (qa !== 0) return qa;
    const ga = Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok);
    if (ga !== 0) return ga;
    if (b.win_rate_pct !== a.win_rate_pct) return b.win_rate_pct - a.win_rate_pct;
    if (b.profit_factor !== a.profit_factor) return b.profit_factor - a.profit_factor;
    return b.refine_score - a.refine_score;
  });

  const winners = sorted.filter((row) => row.qualified_core_requirements && row.high_leverage_guard_ok && row.beats_main_winrate);
  const topRows = sorted.slice(0, 15);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_retest_refine_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_retest_refine_1h_${SYMBOL}_${ts}.md`);

  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    main_baseline: mainBaseline,
    retest_baseline: retestBaseline,
    winners,
    top_rows: topRows,
    rows: sorted,
  }, null, 2), "utf8");

  const summaryTable = topRows.map((row) =>
    `| ${row.variant} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.p75_stop_distance_pct}% | ${row.p75_margin_loss_50x_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.qualified_core_requirements ? "yes" : "no"} | ${row.high_leverage_guard_ok ? "yes" : "no"} |`
  ).join("\n");

  const winnerLines = winners.length > 0
    ? winners.slice(0, 10).map((row, idx) => `${idx + 1}. **${row.variant}**：胜率 ${row.win_rate_pct}%，PF ${row.profit_factor}，年交易 ${row.total_trades}，50x P75 保证金损耗 ${row.p75_margin_loss_50x_pct}%。`).join("\n")
    : "未找到同时满足频率、PF 与高杠杆守门条件，并且胜率高于当前主版本的回踩确认精修版本。";

  const md = `# BTCUSDT 1H 回踩确认精修搜索\n\n作者：**Manus AI**\n\n本轮搜索固定当前保留主版本的外层结构：**pattern on / breakout off / trap on**，只精修方案 2 的回踩确认逻辑。扫描维度包括：**前高前低窗口**、**回踩触碰容差**、**回收关键位偏移量**、**确认模式（同根 / 下一根 / 两者皆可）**，以及**是否要求确认 K 棒颜色一致**。目标是把之前“高胜率但过度降频”的版本，往可实用区间拉回。\n\n| 项目 | 数值 |\n| --- | ---: |\n| Symbol | ${SYMBOL} |\n| 当前主版本胜率 | ${mainBaseline.win_rate_pct}% |\n| 当前主版本 PF | ${mainBaseline.profit_factor} |\n| 当前主版本年交易数 | ${mainBaseline.total_trades} |\n| 当前主版本 50x P75 保证金损耗 | ${mainBaseline.p75_margin_loss_50x_pct}% |\n| 原始回踩实验基线 | ${retestBaseline?.variant ?? "not found"} |\n| 原始回踩实验胜率 | ${retestBaseline?.win_rate_pct ?? 0}% |\n| 原始回踩实验年交易数 | ${retestBaseline?.total_trades ?? 0} |\n| 搜索变体数 | ${VARIANTS.length} |\n\n## 通过守门且胜率高于主版本的候选\n\n${winnerLines}\n\n## Top 结果总表\n\n| Variant | Trades | Win Rate | PF | P75 Stop | 50x P75 Margin Loss | Δ Win Rate | Core OK | Guard OK |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |\n${summaryTable}\n\n## 参数说明\n\n| 参数 | 含义 |\n| --- | --- |\n| lb | 回踩确认所用的前高 / 前低回看窗口 |\n| touch | 允许回踩触碰关键位的 ATR 容差 |\n| reclaim | 收盘重新站回 / 跌回关键位所需的 ATR 偏移量 |\n| same_bar | 当根 K 线内完成回踩与收回确认 |\n| next_bar_confirm | 由上一根先突破，本根再回踩并确认收盘 |\n| either | 同时接受 same_bar 与 next_bar_confirm |\n| color_on/off | 是否要求确认 K 棒颜色与方向一致 |\n\n## 输出文件\n\n| 文件 | 路径 |\n| --- | --- |\n| JSON | ${jsonPath} |\n| Markdown | ${mdPath} |\n`;

  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
