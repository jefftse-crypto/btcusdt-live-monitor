/**
 * search_resonance_enhanced_1h.ts
 * 雙框架共振深化改良搜索腳本
 *
 * 基於上一輪實驗的發現（w2/momf 最優），本輪深化三個方向：
 *   A. 15m 獨立 SL/TP：共振觸發時用 15m ATR 計算更緊湊的止損
 *   B. 動態窗口：根據 1H 信號分數動態調整偏見窗口（強信號用短窗口）
 *   C. A+B 組合：同時啟用兩個改良
 *
 * 基線（v5.9 新主版本 + w2 共振）：
 *   年交易 181，胜率 81.2%，PF 1.28，50x P75 損耗 80.53%
 *
 * 守門條件（放寬版）：
 *   年交易 ≥ 180，PF > 1.0，50x P75 ≤ 82%，胜率 > 81.1%
 *
 * 搜索維度：
 *   A. pa_resonance_use_15m_sl=true：
 *      - 15m SL 乘數：0.8 / 1.0 / 1.2 / 1.5
 *      - 15m TP 乘數：0.10 / 0.15 / 0.20
 *   B. pa_resonance_dynamic_window=true：
 *      - 強信號窗口（≥8.5）：1 / 2
 *      - 普通信號窗口（<8.5）：3 / 4 / 6
 *   C. A+B 組合：最優 A × 最優 B 組合
 *
 * 作者：Manus AI
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type Variant = {
  key: string;
  group: "baseline_w2" | "15m_sl" | "dynamic_window" | "combined";
  // 固定基線參數
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_soft_score: boolean;
  pa_retest_soft_bonus: number;
  pa_retest_soft_min_score: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_reclaim_offset_atr: number;
  // 共振基礎參數（固定 w2）
  pa_dual_tf_resonance: boolean;
  pa_resonance_bias_window_bars: number;
  pa_resonance_min_score: number;
  pa_resonance_require_key_level: boolean;
  pa_resonance_require_momentum: boolean;
  // 新改良參數（搜索維度）
  pa_resonance_use_15m_sl: boolean;
  pa_resonance_15m_sl_mult: number;
  pa_resonance_15m_tp_mult: number;
  pa_resonance_dynamic_window: boolean;
  pa_resonance_dynamic_window_strong: number;
  pa_resonance_dynamic_window_normal: number;
};

type Row = {
  variant: string;
  group: string;
  use_15m_sl: boolean;
  sl_mult_15m: number;
  tp_mult_15m: number;
  dynamic_window: boolean;
  window_strong: number;
  window_normal: number;
  total_trades: number;
  trades_per_2d: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_20x_pct: number;
  p75_margin_loss_30x_pct: number;
  p75_margin_loss_50x_pct: number;
  recommended_margin_fraction_20x_1pct: number;
  recommended_margin_fraction_30x_1pct: number;
  recommended_margin_fraction_50x_1pct: number;
  qualified_core_requirements: boolean;
  high_leverage_guard_ok: boolean;
  beats_w2_baseline_winrate: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  soft_score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const MIN_TRADES = 180; // 放寬版守門線
const BASE_SL = 1.95;
const BASE_TP = 0.21;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

// w2 共振基線（上一輪最優）
const W2_BASELINE_WIN_RATE = 81.2;
const W2_BASELINE_PF = 1.28;
const W2_BASELINE_TRADES = 181;
const W2_BASELINE_P75_50X = 80.53;
const W2_BASELINE_KEY = "resonance_w2_momf_baseline";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function normalizeBinanceRow(row: unknown[]): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Number(row[0]);
  const open = parseFloat(String(row[1]));
  const high = parseFloat(String(row[2]));
  const low = parseFloat(String(row[3]));
  const close = parseFloat(String(row[4]));
  const volume = parseFloat(String(row[5]));
  if (!isFinite(time) || !isFinite(open) || !isFinite(close)) return null;
  return { time, open, high, low, close, volume };
}

function isoTime(ts: number): string {
  return new Date(ts).toISOString().slice(0, 16);
}

async function fetchWithRetry(url: string, label: string, maxAttempts = 5): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Binance ${label} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function calcSoftScore(row: Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_w2_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "soft_score">): number {
  const winRateReward = row.win_rate_pct * 8;
  const pfReward = row.profit_factor * 30;
  const freqReward = Math.max(0, row.total_trades - MIN_TRADES) * 0.03;
  const leveragePenalty = Math.max(0, row.p75_margin_loss_50x_pct - W2_BASELINE_P75_50X) * 1.5;
  const tradePenalty = Math.max(0, MIN_TRADES - row.total_trades) * 0.3;
  return winRateReward + pfReward + freqReward - leveragePenalty - tradePenalty;
}

// 固定的共振基礎參數（w2 / momf）
const BASE_RESONANCE_PARAMS = {
  strategy: "pa" as BacktestStrategy,
  atr_sl_mult: BASE_SL,
  atr_tp_mult: BASE_TP,
  enable_mtf_filter: true,
  enable_adx_filter: true,
  enable_trailing_stop: true,
  pa_allow_pattern: true,
  pa_allow_true_breakout: false,
  pa_allow_trap: true,
  pa_require_retest_on_continuation: false,
  pa_retest_soft_score: true,
  pa_retest_soft_bonus: 0.5,
  pa_retest_soft_min_score: 7.5,
  pa_retest_touch_tolerance_atr: 0.04,
  pa_retest_mode: "same_bar" as RetestMode,
  pa_retest_require_candle_color: true,
  pa_retest_lookback_bars: 20,
  pa_retest_reclaim_offset_atr: 0.03,
  pa_dual_tf_resonance: true,
  pa_resonance_bias_window_bars: 2,
  pa_resonance_min_score: 40,
  pa_resonance_require_key_level: true,
  pa_resonance_require_momentum: false,
};

function buildVariants(): Variant[] {
  const variants: Variant[] = [];

  // 基線：w2/momf（無新改良）
  variants.push({
    key: W2_BASELINE_KEY,
    group: "baseline_w2",
    ...BASE_RESONANCE_PARAMS,
    pa_resonance_use_15m_sl: false,
    pa_resonance_15m_sl_mult: 1.2,
    pa_resonance_15m_tp_mult: 0.15,
    pa_resonance_dynamic_window: false,
    pa_resonance_dynamic_window_strong: 2,
    pa_resonance_dynamic_window_normal: 4,
  });

  // A 組：15m 獨立 SL/TP（固定 w2 靜態窗口）
  const slMults = [0.8, 1.0, 1.2, 1.5];
  const tpMults = [0.10, 0.15, 0.20];
  for (const slM of slMults) {
    for (const tpM of tpMults) {
      variants.push({
        key: `resonance_w2_15msl_sl${slM}_tp${tpM}`,
        group: "15m_sl",
        ...BASE_RESONANCE_PARAMS,
        pa_resonance_use_15m_sl: true,
        pa_resonance_15m_sl_mult: slM,
        pa_resonance_15m_tp_mult: tpM,
        pa_resonance_dynamic_window: false,
        pa_resonance_dynamic_window_strong: 2,
        pa_resonance_dynamic_window_normal: 4,
      });
    }
  }

  // B 組：動態窗口（不用 15m SL/TP）
  const strongWindows = [1, 2];
  const normalWindows = [3, 4, 6];
  for (const sw of strongWindows) {
    for (const nw of normalWindows) {
      variants.push({
        key: `resonance_dynwin_strong${sw}_normal${nw}`,
        group: "dynamic_window",
        ...BASE_RESONANCE_PARAMS,
        pa_resonance_use_15m_sl: false,
        pa_resonance_15m_sl_mult: 1.2,
        pa_resonance_15m_tp_mult: 0.15,
        pa_resonance_dynamic_window: true,
        pa_resonance_dynamic_window_strong: sw,
        pa_resonance_dynamic_window_normal: nw,
      });
    }
  }

  // C 組：A+B 組合（最優 15m SL/TP × 最優動態窗口）
  // 先用代表性組合，待 A/B 結果出來後再精化
  const combineSlMults = [0.8, 1.0, 1.2];
  const combineTpMults = [0.10, 0.15];
  const combineStrongWindows = [1, 2];
  const combineNormalWindows = [3, 4];
  for (const slM of combineSlMults) {
    for (const tpM of combineTpMults) {
      for (const sw of combineStrongWindows) {
        for (const nw of combineNormalWindows) {
          variants.push({
            key: `resonance_combined_sl${slM}_tp${tpM}_sw${sw}_nw${nw}`,
            group: "combined",
            ...BASE_RESONANCE_PARAMS,
            pa_resonance_use_15m_sl: true,
            pa_resonance_15m_sl_mult: slM,
            pa_resonance_15m_tp_mult: tpM,
            pa_resonance_dynamic_window: true,
            pa_resonance_dynamic_window_strong: sw,
            pa_resonance_dynamic_window_normal: nw,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();

async function main() {
  console.log(`[run] resonance enhanced 1h ${SYMBOL}`);
  console.log(`[fetch] 抓取 1H K 線...`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  console.log(`[fetch] 抓取 15m K 線...`);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 24 * 4 * YEAR_DAYS);
  console.log(`[fetch] 抓取 1D K 線...`);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "qualified_core_requirements" | "high_leverage_guard_ok" | "beats_w2_baseline_winrate" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "soft_score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_adx_filter: variant.enable_adx_filter,
      enable_trailing_stop: variant.enable_trailing_stop,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_retest_soft_bonus: variant.pa_retest_soft_bonus,
      pa_retest_soft_min_score: variant.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
      pa_retest_mode: variant.pa_retest_mode,
      pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
      pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
      pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
      pa_dual_tf_resonance: variant.pa_dual_tf_resonance,
      pa_resonance_candles_15m: candles15m,
      pa_resonance_bias_window_bars: variant.pa_resonance_bias_window_bars,
      pa_resonance_min_score: variant.pa_resonance_min_score,
      pa_resonance_require_key_level: variant.pa_resonance_require_key_level,
      pa_resonance_require_momentum: variant.pa_resonance_require_momentum,
      pa_resonance_use_15m_sl: variant.pa_resonance_use_15m_sl,
      pa_resonance_15m_sl_mult: variant.pa_resonance_15m_sl_mult,
      pa_resonance_15m_tp_mult: variant.pa_resonance_15m_tp_mult,
      pa_resonance_dynamic_window: variant.pa_resonance_dynamic_window,
      pa_resonance_dynamic_window_strong: variant.pa_resonance_dynamic_window_strong,
      pa_resonance_dynamic_window_normal: variant.pa_resonance_dynamic_window_normal,
    });

    const stopDistances = result.trades.map(t => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = round(percentile(stopDistances, 0.75), 4);
    const p75MarginLoss20x = round(p75Stop * 20, 2);
    const p75MarginLoss30x = round(p75Stop * 30, 2);
    const p75MarginLoss50x = round(p75Stop * 50, 2);
    const recMarginFrac20x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 20), 2) : 0;
    const recMarginFrac30x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 30), 2) : 0;
    const recMarginFrac50x = p75Stop > 0 ? round(1 / (p75Stop / 100 * 50), 2) : 0;

    const row = {
      variant: variant.key,
      group: variant.group,
      use_15m_sl: variant.pa_resonance_use_15m_sl,
      sl_mult_15m: variant.pa_resonance_15m_sl_mult,
      tp_mult_15m: variant.pa_resonance_15m_tp_mult,
      dynamic_window: variant.pa_resonance_dynamic_window,
      window_strong: variant.pa_resonance_dynamic_window_strong,
      window_normal: variant.pa_resonance_dynamic_window_normal,
      total_trades: result.total_trades,
      trades_per_2d: round(result.total_trades / (YEAR_DAYS / 2), 2),
      win_rate_pct: round(result.win_rate * 100, 1),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net * 100, 2),
      max_drawdown_pct: round(result.max_drawdown * 100, 2),
      p75_stop_distance_pct: p75Stop,
      p75_margin_loss_20x_pct: p75MarginLoss20x,
      p75_margin_loss_30x_pct: p75MarginLoss30x,
      p75_margin_loss_50x_pct: p75MarginLoss50x,
      recommended_margin_fraction_20x_1pct: recMarginFrac20x,
      recommended_margin_fraction_30x_1pct: recMarginFrac30x,
      recommended_margin_fraction_50x_1pct: recMarginFrac50x,
    };
    console.log(`[done] ${variant.group}/${variant.key.slice(-40)} trades=${result.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor}`);
    rowsRaw.push(row);
  }

  const w2Baseline = rowsRaw.find((row) => row.variant === W2_BASELINE_KEY);
  if (!w2Baseline) throw new Error(`找不到 w2 基線變體`);

  const rows: Row[] = rowsRaw.map((row) => {
    const qualified_core_requirements = row.total_trades >= MIN_TRADES && row.profit_factor > 1;
    const high_leverage_guard_ok = row.p75_margin_loss_50x_pct <= 82;
    const beats_w2_baseline_winrate = row.win_rate_pct > W2_BASELINE_WIN_RATE;
    const delta_win_rate_pct = round(row.win_rate_pct - W2_BASELINE_WIN_RATE, 1);
    const delta_profit_factor = round(row.profit_factor - W2_BASELINE_PF, 2);
    const delta_total_trades = row.total_trades - W2_BASELINE_TRADES;
    const soft_score = calcSoftScore(row);
    return {
      ...row,
      qualified_core_requirements,
      high_leverage_guard_ok,
      beats_w2_baseline_winrate,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      soft_score,
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const qa = Number(b.qualified_core_requirements) - Number(a.qualified_core_requirements);
    if (qa !== 0) return qa;
    const ga = Number(b.high_leverage_guard_ok) - Number(a.high_leverage_guard_ok);
    if (ga !== 0) return ga;
    return b.soft_score - a.soft_score;
  });

  const winners = sorted.filter((row) => row.qualified_core_requirements && row.high_leverage_guard_ok && row.beats_w2_baseline_winrate);
  const top20 = sorted.slice(0, 20);

  // 按組別統計
  const groupStats = ["baseline_w2", "15m_sl", "dynamic_window", "combined"].map(g => {
    const gRows = sorted.filter(r => r.group === g);
    const gWinners = gRows.filter(r => r.qualified_core_requirements && r.high_leverage_guard_ok && r.beats_w2_baseline_winrate);
    const best = gRows[0];
    return { group: g, total: gRows.length, winners: gWinners.length, best };
  });

  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `search_resonance_enhanced_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_resonance_enhanced_1h_${SYMBOL}_${ts}.md`);

  const jsonData = {
    symbol: SYMBOL,
    w2_baseline_key: W2_BASELINE_KEY,
    w2_baseline_win_rate: W2_BASELINE_WIN_RATE,
    w2_baseline_pf: W2_BASELINE_PF,
    w2_baseline_trades: W2_BASELINE_TRADES,
    w2_baseline_p75_margin_50x: W2_BASELINE_P75_50X,
    total_variants: VARIANTS.length,
    winners: winners.length,
    group_stats: groupStats,
    rows: sorted,
  };

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify(jsonData, null, 2));

  const winnerLines = winners.length === 0
    ? "本輪未找到超越 w2 基線的改良變體。"
    : winners.slice(0, 10).map((row, idx) =>
        `${idx + 1}. **[${row.group}] ${row.variant}**：胜率 ${row.win_rate_pct}%，PF ${row.profit_factor}，年交易 ${row.total_trades}，50x P75 損耗 ${row.p75_margin_loss_50x_pct}%，Δ胜率 ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct}，Δ交易 ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades}。`
      ).join("\n");

  const groupSummary = groupStats.map(g =>
    `| ${g.group} | ${g.total} | ${g.winners} | ${g.best?.win_rate_pct ?? "-"}% | ${g.best?.profit_factor ?? "-"} | ${g.best?.total_trades ?? "-"} | ${g.best?.p75_margin_loss_50x_pct ?? "-"}% |`
  ).join("\n");

  const summaryTable = top20.map((row) =>
    `| [${row.group}] ${row.variant.slice(-45)} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.p75_margin_loss_50x_pct}% | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} | ${row.delta_total_trades >= 0 ? "+" : ""}${row.delta_total_trades} | ${row.qualified_core_requirements ? "✓" : "✗"} | ${row.high_leverage_guard_ok ? "✓" : "✗"} |`
  ).join("\n");

  const md = `# 雙框架共振深化改良搜索報告

**幣種**：${SYMBOL}  
**策略**：PA（1H 偏見 + 15m 共振 + 深化改良）  
**w2 基線**：年交易 ${W2_BASELINE_TRADES}，胜率 ${W2_BASELINE_WIN_RATE}%，PF ${W2_BASELINE_PF}，50x P75 損耗 ${W2_BASELINE_P75_50X}%  
**搜索時間**：${new Date().toISOString()}  
**總變體數**：${VARIANTS.length}  
**通過守門數**：${winners.length}  

---

## 守門條件（放寬版）

- 年交易數 ≥ ${MIN_TRADES}
- Profit Factor > 1.0
- 50x P75 保證金損耗 ≤ 82%
- 胜率 > ${W2_BASELINE_WIN_RATE}%（超越 w2 基線）

---

## 各組別統計

| 組別 | 變體數 | 通過守門 | 最優胜率 | 最優PF | 最優年交易 | 最優50xP75 |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
${groupSummary}

---

## 通過守門的變體

${winnerLines}

---

## Top 20 詳細結果

| 變體 | 年交易 | 胜率 | PF | 50x P75損耗 | Δ胜率 | Δ交易 | 核心 | 風控 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | :---: | :---: |
${summaryTable}

---

## 分析與結論

${winners.length > 0
  ? `本輪實驗發現 **${winners.length} 個**改良變體超越了 w2 基線，深化改良方向有效。\n\n最優變體：**${winners[0].variant}**（${winners[0].group} 組）\n- 胜率：${winners[0].win_rate_pct}%（Δ${winners[0].delta_win_rate_pct >= 0 ? "+" : ""}${winners[0].delta_win_rate_pct}）\n- PF：${winners[0].profit_factor}（Δ${winners[0].delta_profit_factor >= 0 ? "+" : ""}${winners[0].delta_profit_factor}）\n- 年交易：${winners[0].total_trades}（Δ${winners[0].delta_total_trades >= 0 ? "+" : ""}${winners[0].delta_total_trades}）\n- 50x P75 損耗：${winners[0].p75_margin_loss_50x_pct}%`
  : `本輪三個改良方向均未能超越 w2 基線（胜率 ${W2_BASELINE_WIN_RATE}%）。\n\n**主要發現**：\n- 15m 獨立 SL/TP 可能改變了 SL 距離分佈，影響了 P75 保證金損耗計算\n- 動態窗口機制可能需要更精細的信號分數閾值調整\n- 建議下一步：調整動態窗口的分數閾值（嘗試 7.5 / 8.0 / 9.0）或擴大 15m TP 乘數範圍`}

### 後續建議

1. 若有通過守門的變體，建議扶正為新主版本並執行高槓桿風險評估
2. 若無通過守門的變體，建議嘗試調整動態窗口分數閾值（7.5 / 8.0 / 9.0）
3. 可考慮將 15m SL/TP 的 TP 乘數擴大至 0.25~0.35 以提升盈虧比
`;

  await fs.writeFile(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD:   ${mdPath}`);
  console.log(`[summary] 總變體=${VARIANTS.length} 通過守門=${winners.length}`);
  if (winners.length > 0) {
    console.log(`[best] ${winners[0].variant}`);
    console.log(`       胜率=${winners[0].win_rate_pct}% PF=${winners[0].profit_factor} 年交易=${winners[0].total_trades} 50xP75=${winners[0].p75_margin_loss_50x_pct}%`);
  }
}

main().catch((err) => {
  console.error("[fatal]", err);
  process.exit(1);
});
