import { runBacktest, type BacktestStrategy } from '../server/backtest.ts';

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = 'same_bar' | 'next_bar_confirm' | 'either';

const BINANCE_KLINES_URL = 'https://api.binance.com/api/v3/klines';
const PAGE_LIMIT = 1000;
const SYMBOL = 'BTCUSDT';

async function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }
function normalize(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}
async function fetchCandles(interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol: SYMBOL, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetch(`${BINANCE_KLINES_URL}?${params.toString()}`);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload.map(normalize).filter((x): x is Candle => x !== null).sort((a,b)=>a.time-b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(100);
  }
  return candles.slice(-targetCount);
}

async function run(label: string, params: {
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter?: boolean;
  enable_adx_filter?: boolean;
  enable_trailing_stop?: boolean;
  pa_allow_pattern?: boolean;
  pa_allow_true_breakout?: boolean;
  pa_allow_trap?: boolean;
  pa_require_retest_on_continuation?: boolean;
  pa_retest_soft_score?: boolean;
  pa_retest_soft_bonus?: number;
  pa_retest_soft_min_score?: number;
  pa_retest_touch_tolerance_atr?: number;
  pa_retest_mode?: RetestMode;
  pa_retest_require_candle_color?: boolean;
  pa_retest_lookback_bars?: number;
  pa_retest_reclaim_offset_atr?: number;
  pa_dual_tf_resonance?: boolean;
  pa_resonance_bias_window_bars?: number;
  pa_resonance_min_score?: number;
  pa_resonance_require_key_level?: boolean;
  pa_resonance_require_momentum?: boolean;
  pa_session_mode?: 'all' | 'exclude_offhours' | 'london_newyork';
}) {
  const candles1h = await fetchCandles('1h', 24 * 365);
  const candles1d = await fetchCandles('1d', 365);
  const candles15m = await fetchCandles('15m', 4 * 24 * 30);
  const res = runBacktest({
    candles: candles1h,
    symbol: SYMBOL,
    interval: '1h',
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_resonance_candles_15m: candles15m,
    enable_fee: true,
    ...params,
  });
  const trades = res.trades as any[];
  const last = trades[trades.length - 1];
  console.log(JSON.stringify({
    label,
    total_trades: trades.length,
    last_trade: last ? {
      entry_time: last.entry_time,
      exit_time: last.exit_time,
      entry_type: last.entry_type,
      direction: last.direction,
      used_15m_execution: last.used_15m_execution,
      resonance_entry_time_15m: last.resonance_entry_time_15m,
      resonance_exit_time_15m: last.resonance_exit_time_15m,
      pnl_net_pct: last.pnl_net_pct,
    } : null,
    latest_1h: candles1h[candles1h.length - 1],
    latest_closed_1h: candles1h[candles1h.length - 2],
    latest_15m: candles15m[candles15m.length - 1],
    latest_closed_15m: candles15m[candles15m.length - 2],
  }, null, 2));
}

await run('181', {
  strategy: 'pa',
  atr_sl_mult: 1.95,
  atr_tp_mult: 0.21,
  enable_mtf_filter: true,
  enable_adx_filter: true,
  enable_trailing_stop: true,
  pa_allow_pattern: true,
  pa_allow_true_breakout: false,
  pa_allow_trap: true,
  pa_require_retest_on_continuation: false,
  pa_retest_soft_score: true,
  pa_retest_soft_bonus: 0.5,
  pa_retest_soft_min_score: 7.5,
  pa_retest_touch_tolerance_atr: 0.04,
  pa_retest_mode: 'same_bar',
  pa_retest_require_candle_color: true,
  pa_retest_lookback_bars: 20,
  pa_retest_reclaim_offset_atr: 0.03,
  pa_dual_tf_resonance: true,
  pa_resonance_bias_window_bars: 2,
  pa_resonance_min_score: 40,
  pa_resonance_require_key_level: true,
  pa_resonance_require_momentum: false,
});

await run('90', {
  strategy: 'pa',
  atr_sl_mult: 1.75,
  atr_tp_mult: 0.19,
  enable_mtf_filter: true,
  enable_adx_filter: true,
  enable_trailing_stop: false,
  pa_allow_pattern: true,
  pa_allow_true_breakout: false,
  pa_allow_trap: true,
  pa_require_retest_on_continuation: true,
  pa_retest_touch_tolerance_atr: 0.08,
  pa_retest_mode: 'either',
  pa_retest_require_candle_color: false,
  pa_retest_lookback_bars: 12,
  pa_retest_reclaim_offset_atr: 0.03,
  pa_session_mode: 'exclude_offhours',
});
