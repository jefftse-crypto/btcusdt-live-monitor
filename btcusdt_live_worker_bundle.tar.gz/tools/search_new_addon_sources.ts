import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type RetestMode = "same_bar" | "next_bar_confirm" | "either";

type VariantConfig = {
  key: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_reclaim_offset_atr: number;
  pa_retest_mode: RetestMode;
  pa_retest_require_candle_color: boolean;
};

type LiteTrade = {
  entry_time: number;
  exit_time: number;
  direction: "long" | "short";
  pnl_net_pct: number;
};

type Candidate = {
  name: string;
  strategy: BacktestStrategy;
  atr_tp_mult: number;
  trailing: boolean;
  note: string;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const CORE_VARIANT = "pa_sl1.95_tp0.21_pattern_on_breakout_off_trap_on_retest_on_lb24_touch0.04_reclaim0.04_same_bar_color_on";
const AGGRESSIVE_ADDON = "pa_sl1.75_tp0.19_pattern_on_breakout_off_trap_on_retest_on_lb12_touch0.08_reclaim0.03_either_color_off";
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 2): number {
  return Number(value.toFixed(digits));
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K线抓取失败：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function parseVariant(variant: string): VariantConfig {
  const parts = variant.split("_");
  const takeAfterPrefix = (prefix: string) => {
    const item = parts.find((p) => p.startsWith(prefix));
    if (!item) throw new Error(`variant ${variant} 缺少 ${prefix}`);
    return item.slice(prefix.length);
  };
  const has = (token: string) => parts.includes(token);
  const strategy = parts[0] as BacktestStrategy;
  return {
    key: variant,
    strategy,
    atr_sl_mult: Number(takeAfterPrefix("sl")),
    atr_tp_mult: Number(takeAfterPrefix("tp")),
    pa_allow_pattern: has("pattern") ? true : variant.includes("pattern_on"),
    pa_allow_true_breakout: variant.includes("breakout_on"),
    pa_allow_trap: variant.includes("trap_on"),
    pa_require_retest_on_continuation: variant.includes("retest_on"),
    pa_retest_lookback_bars: Number(takeAfterPrefix("lb")),
    pa_retest_touch_tolerance_atr: Number(takeAfterPrefix("touch")),
    pa_retest_reclaim_offset_atr: Number(takeAfterPrefix("reclaim")),
    pa_retest_mode: variant.includes("same_bar")
      ? "same_bar"
      : variant.includes("next_bar_confirm")
        ? "next_bar_confirm"
        : "either",
    pa_retest_require_candle_color: variant.includes("color_on"),
  };
}

function liteTrades(trades: any[]): LiteTrade[] {
  return trades.map((t) => ({
    entry_time: t.entry_time,
    exit_time: t.exit_time,
    direction: t.direction,
    pnl_net_pct: t.pnl_net_pct,
  }));
}

function tradeKey(t: LiteTrade): string {
  return `${t.entry_time}_${t.direction}`;
}

function winRatePct(trades: LiteTrade[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter((t) => t.pnl_net_pct > 0).length;
  return round((wins / trades.length) * 100, 2);
}

async function runPaVariant(candles1h: Candle[], candles1d: Candle[], variantKey: string) {
  const v = parseVariant(variantKey);
  return runBacktest({
    candles: candles1h,
    strategy: v.strategy,
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: v.atr_sl_mult,
    atr_tp_mult: v.atr_tp_mult,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
    pa_allow_pattern: v.pa_allow_pattern,
    pa_allow_true_breakout: v.pa_allow_true_breakout,
    pa_allow_trap: v.pa_allow_trap,
    pa_require_retest_on_continuation: v.pa_require_retest_on_continuation,
    pa_retest_lookback_bars: v.pa_retest_lookback_bars,
    pa_retest_touch_tolerance_atr: v.pa_retest_touch_tolerance_atr,
    pa_retest_reclaim_offset_atr: v.pa_retest_reclaim_offset_atr,
    pa_retest_mode: v.pa_retest_mode,
    pa_retest_require_candle_color: v.pa_retest_require_candle_color,
  });
}

async function runCandidate(candles15m: Candle[], candles4h: Candle[], candidate: Candidate) {
  return runBacktest({
    candles: candles15m,
    strategy: candidate.strategy,
    symbol: SYMBOL,
    interval: "15m",
    atr_sl_mult: 2,
    atr_tp_mult: candidate.atr_tp_mult,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: candidate.trailing,
    enable_adx_filter: true,
    htf_candles: candles4h,
    entry_candles: candles15m,
    use_true_mtf: true,
  });
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 96 * YEAR_DAYS);
  const candles4h = await fetchBinanceCandles(SYMBOL, "4h", 6 * YEAR_DAYS + 10);

  console.log(`[1h range] ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[15m range] ${isoTime(candles15m[0]?.time)} -> ${isoTime(candles15m[candles15m.length - 1]?.time)}`);

  const core = await runPaVariant(candles1h, candles1d, CORE_VARIANT);
  const aggressiveAddon = await runPaVariant(candles1h, candles1d, AGGRESSIVE_ADDON);
  const baseTrades = [
    ...liteTrades(core.trades as any[]),
    ...liteTrades(aggressiveAddon.trades as any[]).filter((t) => !liteTrades(core.trades as any[]).some((c) => tradeKey(c) === tradeKey(t))),
  ].sort((a, b) => a.entry_time - b.entry_time);
  const baseSet = new Set(baseTrades.map((t) => tradeKey(t)));

  const candidates: Candidate[] = [
    { name: "hwr_model_a_tp2_trailing_off", strategy: "hwr_model_a", atr_tp_mult: 2.0, trailing: false, note: "分类报告可保留，中频候选" },
    { name: "hwr_model_b_tp2_trailing_off", strategy: "hwr_model_b", atr_tp_mult: 2.0, trailing: false, note: "需轻改，频率偏高" },
    { name: "cannonball_tp2_trailing_off", strategy: "cannonball", atr_tp_mult: 2.0, trailing: false, note: "需轻改，中频且相对稳定" },
    { name: "macd_tp2_trailing_off", strategy: "macd", atr_tp_mult: 2.0, trailing: false, note: "需轻改，基准胜率较高" },
    { name: "vwap_reversion_tp1.5_trailing_off", strategy: "vwap_reversion", atr_tp_mult: 1.5, trailing: false, note: "可保留，但样本较少" },
    { name: "bollinger_tp1.5_trailing_off", strategy: "bollinger", atr_tp_mult: 1.5, trailing: false, note: "过度交易，先做来源初筛" },
    { name: "rsi_reversal_tp2_trailing_off", strategy: "rsi_reversal", atr_tp_mult: 2.0, trailing: false, note: "可保留，但样本极少" },
    { name: "ema_cross_tp1.5_trailing_off", strategy: "ema_cross", atr_tp_mult: 1.5, trailing: false, note: "可保留，但样本极少" },
  ];

  const rows: any[] = [];
  for (const candidate of candidates) {
    const res = await runCandidate(candles15m, candles4h, candidate);
    const candidateTrades = liteTrades(res.trades as any[]);
    const addedTrades = candidateTrades.filter((t) => !baseSet.has(tradeKey(t)));
    const comboTrades = [...baseTrades, ...addedTrades].sort((a, b) => a.entry_time - b.entry_time);
    rows.push({
      candidate: candidate.name,
      strategy: candidate.strategy,
      note: candidate.note,
      standalone_trades: candidateTrades.length,
      standalone_win_rate_pct: winRatePct(candidateTrades),
      added_trades: addedTrades.length,
      added_win_rate_pct: winRatePct(addedTrades),
      combo_total_trades: comboTrades.length,
      combo_win_rate_pct: winRatePct(comboTrades),
      delta_vs_base_trades: comboTrades.length - baseTrades.length,
      delta_vs_base_win_pct: round(winRatePct(comboTrades) - winRatePct(baseTrades), 2),
    });
    console.log(`[done] ${candidate.name} -> combo ${comboTrades.length} / ${winRatePct(comboTrades)}%`);
  }

  rows.sort((a, b) => {
    if (b.combo_win_rate_pct !== a.combo_win_rate_pct) return b.combo_win_rate_pct - a.combo_win_rate_pct;
    return b.combo_total_trades - a.combo_total_trades;
  });

  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const jsonPath = path.join(OUT_DIR, `search_new_addon_sources_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_new_addon_sources_${SYMBOL}_${ts}.md`);

  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    generated_at: new Date().toISOString(),
    base_combo: {
      core_variant: CORE_VARIANT,
      aggressive_addon: AGGRESSIVE_ADDON,
      total_trades: baseTrades.length,
      win_rate_pct: winRatePct(baseTrades),
    },
    rows,
  }, null, 2), "utf8");

  const table = rows.map((r) => `| ${r.candidate} | ${r.standalone_trades} | ${r.standalone_win_rate_pct}% | ${r.added_trades} | ${r.added_win_rate_pct}% | ${r.combo_total_trades} | ${r.combo_win_rate_pct}% | ${r.delta_vs_base_trades >= 0 ? "+" : ""}${r.delta_vs_base_trades} | ${r.delta_vs_base_win_pct >= 0 ? "+" : ""}${r.delta_vs_base_win_pct} | ${r.note} |`).join("\n");
  const md = `# BTCUSDT 新 Add-on 来源初筛\n\n| 项目 | 数值 |\n| --- | ---: |\n| 当前基线组合 | 1H Core + 1H Aggressive Add-on |\n| 基线交易数 | ${baseTrades.length} |\n| 基线胜率 | ${winRatePct(baseTrades)}% |\n\n> 说明：本轮属于 **来源初筛**，目的是先看其他策略家族是否有机会作为补充模块加入当前组合。这里采用的是“与当前基线交易并列叠加”的近似评估，尚未处理资金占用冲突与跨模块排队。\n\n| Candidate | Standalone Trades | Standalone Win | Added Trades | Added Win | Combo Trades | Combo Win | Δ Trades vs Base | Δ Win vs Base | Note |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |\n${table}\n`;
  await fs.writeFile(mdPath, md, "utf8");
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
