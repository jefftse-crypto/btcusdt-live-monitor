/**
 * search_15m_exec_confirm_v2_1h.ts
 * 精化版 15m 執行確認搜索腳本 v2 — 加入冷卻機制與進場次數限制
 *
 * 改進點（相較 v1）：
 *   - 加入「每個 1H 信號後的 15m 冷卻期」（pa_15m_signal_cooldown_bars）
 *   - 加入「每個 1H 信號窗口內最多允許 N 次 15m 進場」（pa_15m_max_entries_per_1h）
 *   - 加入「1H 信號後允許 15m 進場的窗口期」（pa_15m_entry_window_bars）
 *   - 目標：解決 v1 中「信號抖動 / 過度交易」問題
 *
 * 基線：新主版本（軟評分 bonus0.5 / minscore7.5 / touch0.04 / same_bar）
 *   - 胜率 81.1%, PF 1.27, 年交易 185, 50x P75 保證金損耗 80.53%
 *
 * 守門條件：
 *   - 核心頻率：年交易數 ≥ 150（15m 框架允許較低頻率）
 *   - PF > 1
 *   - 50x P75 保證金損耗 ≤ 82%
 *   - 胜率 > 81.1%（超越新主版本基線）
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// 新主版本基線
const NEW_BASELINE = { winRate: 81.1, pf: 1.27, trades: 185, p75Margin50x: 80.53 };

// 守門條件
const GUARD_MIN_TRADES = 150;
const GUARD_MIN_PF = 1.0;
const GUARD_MAX_P75_MARGIN_50X = 82.0;
const GUARD_MIN_WINRATE = NEW_BASELINE.winRate;

// 主版本 SL/TP 參數（必須與新主版本一致）
const BASE_SL = 1.95;
const BASE_TP = 0.21;

interface Variant {
  label: string;
  use_15m_entry: boolean;
  cooldown_bars: number;
  max_entries_per_1h: number;
  entry_window_bars: number;
  pa_retest_soft_score: boolean;
  pa_min_signal_score: number;
}

const variants: Variant[] = [];

// 1. 純 1H 基線（對照組）
variants.push({
  label: "1h_baseline_soft_on",
  use_15m_entry: false,
  cooldown_bars: 0,
  max_entries_per_1h: 0,
  entry_window_bars: 0,
  pa_retest_soft_score: true,
  pa_min_signal_score: 7.5,
});

// 2. 15m 精化版：冷卻期 + 進場次數限制
for (const cooldown of [4, 8, 16]) {           // 4=1H, 8=2H, 16=4H
  for (const maxEntries of [1, 2]) {            // 每個 1H 信號最多 1 或 2 次
    for (const windowBars of [16, 24, 32]) {    // 窗口 4H, 6H, 8H
      for (const softOn of [true, false]) {
        variants.push({
          label: `15m_cool${cooldown}_max${maxEntries}_win${windowBars}_soft${softOn ? "on" : "off"}`,
          use_15m_entry: true,
          cooldown_bars: cooldown,
          max_entries_per_1h: maxEntries,
          entry_window_bars: windowBars,
          pa_retest_soft_score: softOn,
          pa_min_signal_score: softOn ? 7.5 : 0,
        });
      }
    }
  }
}

// 3. 純冷卻（不限次數）
for (const cooldown of [4, 8, 16]) {
  variants.push({
    label: `15m_cool${cooldown}_nomax_soft_on`,
    use_15m_entry: true,
    cooldown_bars: cooldown,
    max_entries_per_1h: 0,
    entry_window_bars: 0,
    pa_retest_soft_score: true,
    pa_min_signal_score: 7.5,
  });
}

// 4. 純次數限制（不設冷卻）
for (const maxEntries of [1, 2]) {
  variants.push({
    label: `15m_nocool_max${maxEntries}_win24_soft_on`,
    use_15m_entry: true,
    cooldown_bars: 0,
    max_entries_per_1h: maxEntries,
    entry_window_bars: 24,
    pa_retest_soft_score: true,
    pa_min_signal_score: 7.5,
  });
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`Binance ${interval} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function isoTime(ts: number) {
  return new Date(ts * 1000).toISOString().slice(0, 10);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

async function main() {
  console.log(`[run] 15m exec confirm v2 search 1h ${SYMBOL}`);

  // 獲取 K 線資料
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 4 * 24 * YEAR_DAYS);
  const candles1h  = await fetchBinanceCandles(SYMBOL, "1h",  24 * YEAR_DAYS);
  const candles1d  = await fetchBinanceCandles(SYMBOL, "1d",  YEAR_DAYS + 30);

  console.log(`[range] 15m: ${isoTime(candles15m[0]?.time)} -> ${isoTime(candles15m[candles15m.length - 1]?.time)}`);
  console.log(`[range] 1h:  ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[variants] ${variants.length} 個搜索變體`);

  const results: {
    label: string;
    use_15m_entry: boolean;
    cooldown_bars: number;
    max_entries_per_1h: number;
    entry_window_bars: number;
    soft_on: boolean;
    trades: number;
    winRate: number;
    pf: number;
    p75Stop: number;
    p75Margin50x: number;
    deltaWinRate: number;
    deltaTrades: number;
    coreOk: boolean;
    guardOk: boolean;
  }[] = [];

  const annualFactor1h = candles1h.length / (24 * YEAR_DAYS);

  for (const v of variants) {
    const primaryCandles = v.use_15m_entry ? candles15m : candles1h;
    const res = runBacktest({
      candles: primaryCandles as any,
      strategy: "pa" as BacktestStrategy,
      symbol: SYMBOL,
      interval: v.use_15m_entry ? "15m" : "1h",
      atr_sl_mult: BASE_SL,
      atr_tp_mult: BASE_TP,
      mtf_candles: v.use_15m_entry ? candles1h : candles1d,
      htf_candles: v.use_15m_entry ? candles1h : candles1d,
      entry_candles: primaryCandles as any,
      use_true_mtf: true,
      pa_allow_pattern: true,
      pa_allow_trap: true,
      pa_allow_true_breakout: false,
      pa_retest_soft_score: v.pa_retest_soft_score,
      pa_retest_soft_bonus: 0.5,
      pa_retest_soft_min_score: v.pa_min_signal_score,
      pa_retest_touch_tolerance_atr: 0.04,
      pa_retest_mode: "same_bar",
      pa_15m_signal_cooldown_bars: v.cooldown_bars,
      pa_15m_max_entries_per_1h: v.max_entries_per_1h,
      pa_15m_entry_window_bars: v.entry_window_bars,
    } as any);

    const trades = res.total_trades;
    const winRate = Math.round(res.win_rate * 1000) / 10;
    const pf = Math.round(res.profit_factor * 100) / 100;
    const stopPcts = res.trades.map((t: any) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = Math.round(percentile(stopPcts, 0.75) * 10000) / 10000;
    const p75Margin50x = Math.round(p75Stop * 50 * 100) / 100;

    // 統一換算為年化交易數（以 1H 資料長度為基準）
    const annualTrades = Math.round(trades / annualFactor1h);

    const coreOk = annualTrades >= GUARD_MIN_TRADES && pf > GUARD_MIN_PF;
    const guardOk = p75Margin50x <= GUARD_MAX_P75_MARGIN_50X;
    const deltaWinRate = Math.round((winRate - NEW_BASELINE.winRate) * 10) / 10;
    const deltaTrades = annualTrades - NEW_BASELINE.trades;

    console.log(`[done] ${v.label} trades=${annualTrades} win=${winRate}% pf=${pf} 50x_p75=${p75Margin50x}%`);

    results.push({
      label: v.label,
      use_15m_entry: v.use_15m_entry,
      cooldown_bars: v.cooldown_bars,
      max_entries_per_1h: v.max_entries_per_1h,
      entry_window_bars: v.entry_window_bars,
      soft_on: v.pa_retest_soft_score,
      trades: annualTrades,
      winRate,
      pf,
      p75Stop,
      p75Margin50x,
      deltaWinRate,
      deltaTrades,
      coreOk,
      guardOk,
    });
  }

  // 排序：勝率降序
  results.sort((a, b) => b.winRate - a.winRate || b.pf - a.pf);

  const winners = results.filter(r => r.coreOk && r.guardOk && r.winRate > GUARD_MIN_WINRATE);
  console.log(`[winners] ${winners.length} 個候選通過所有守門條件`);

  // 產出 Markdown 報告
  const ts = new Date().toISOString().replace(/:/g, "-").replace(/\..+/, "");
  const mdPath = path.join(OUT_DIR, `search_15m_exec_confirm_v2_1h_${SYMBOL}_${ts}.md`);
  const jsonPath = path.join(OUT_DIR, `search_15m_exec_confirm_v2_1h_${SYMBOL}_${ts}.json`);

  const top20 = results.slice(0, 20);

  const md = `# BTCUSDT 1H 精化版 15m 執行確認搜索 v2
作者：**Manus AI**

本輪搜索是對 v1 的重要改進：加入了**信號冷卻機制**與**進場次數限制**，以解決 v1 中「信號抖動 / 過度交易」導致勝率崩塌的問題。

## 基線與守門條件

| 項目 | 數值 |
| --- | ---: |
| Symbol | ${SYMBOL} |
| 新主版本基線胜率 | ${NEW_BASELINE.winRate}% |
| 新主版本基線 PF | ${NEW_BASELINE.pf} |
| 新主版本基線年交易數 | ${NEW_BASELINE.trades} |
| 新主版本基線 50x P75 保證金損耗 | ${NEW_BASELINE.p75Margin50x}% |
| 搜索變體數 | ${variants.length} |
| 通過守門並胜率超新基線的候選數 | ${winners.length} |

## 守門條件

| 條件 | 門檻 |
| --- | --- |
| 核心頻率要求 | 年交易數 ≥ ${GUARD_MIN_TRADES} 且 PF > ${GUARD_MIN_PF} |
| 高杠杆守門線 | 50x P75 保證金損耗 ≤ ${GUARD_MAX_P75_MARGIN_50X}% |
| 胜率超新基線 | 胜率 > ${GUARD_MIN_WINRATE}% |

## 通過守門的候選

${winners.length === 0 ? "本輪未找到同時滿足所有守門條件的 15m 精化版候選。" : winners.map(r => `
### ${r.label}
| 指標 | 數值 |
| --- | ---: |
| 年交易數 | ${r.trades} |
| 胜率 | ${r.winRate}% (${r.deltaWinRate >= 0 ? "+" : ""}${r.deltaWinRate}%) |
| PF | ${r.pf} |
| 50x P75 保證金損耗 | ${r.p75Margin50x}% |
| 冷卻 K 棒數 | ${r.cooldown_bars} |
| 最大進場次數/1H信號 | ${r.max_entries_per_1h} |
| 進場窗口 K 棒數 | ${r.entry_window_bars} |
`).join("\n")}

## Top 20 結果總表

| Variant | 執行框架 | Trades | Win Rate | PF | 50x P75 Margin | Δ Win Rate | Δ Trades | Core OK | Guard OK |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
${top20.map(r => `| ${r.label} | ${r.use_15m_entry ? "15m" : "1H"} | ${r.trades} | ${r.winRate}% | ${r.pf} | ${r.p75Margin50x}% | ${r.deltaWinRate >= 0 ? "+" : ""}${r.deltaWinRate} | ${r.deltaTrades >= 0 ? "+" : ""}${r.deltaTrades} | ${r.coreOk ? "yes" : "no"} | ${r.guardOk ? "yes" : "no"} |`).join("\n")}

## 冷卻機制說明

| 參數 | 說明 |
| --- | --- |
| pa_15m_signal_cooldown_bars | 每次 15m 進場後，冷卻 N 根 15m K 棒才允許下一次進場 |
| pa_15m_max_entries_per_1h | 在同一個 1H 信號窗口內，最多允許 N 次 15m 進場 |
| pa_15m_entry_window_bars | 1H 信號觸發後，允許 15m 進場的窗口期（K 棒數） |

## 輸出文件

| 文件 | 路徑 |
| --- | --- |
| JSON | ${jsonPath} |
| Markdown | ${mdPath} |
`;

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(mdPath, md, "utf-8");
  await fs.writeFile(jsonPath, JSON.stringify({ meta: { symbol: SYMBOL, baseline: NEW_BASELINE, variants: variants.length, winners: winners.length }, results }, null, 2), "utf-8");

  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch(console.error);
