import { runBacktest } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]), high = Number(row[2]), low = Number(row[3]), close = Number(row[4]), volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}
async function fetchWithRetry(url: string, interval: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" }, signal: AbortSignal.timeout(20000) });
      if (!res.ok) throw new Error(`Binance ${interval} K 線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}
async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload.map((row) => normalizeBinanceRow(row)).filter((row): row is Candle => row !== null).sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

async function main() {
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  const result = runBacktest({
    candles: candles1h,
    strategy: "pa",
    symbol: SYMBOL,
    interval: "1h",
    atr_sl_mult: 3.0,
    atr_tp_mult: 0.25,
    enable_mtf_filter: true,
    enable_fee: true,
    enable_trailing_stop: false,
    enable_adx_filter: true,
    htf_candles: candles1d,
    entry_candles: candles1h,
    use_true_mtf: true,
  });

  const trades = result.trades as Array<any>;
  const wins = trades.filter((t) => t.pnl_net_pct > 0);
  const losses = trades.filter((t) => t.pnl_net_pct <= 0);
  const summarize = (rows: Array<any>) => {
    const byType = new Map<string, { count: number; avg_net: number; avg_score: number; trailing: number; sl: number; tp: number; end: number }>();
    for (const t of rows) {
      const key = String(t.entry_type ?? "unknown");
      const cur = byType.get(key) ?? { count: 0, avg_net: 0, avg_score: 0, trailing: 0, sl: 0, tp: 0, end: 0 };
      cur.count += 1;
      cur.avg_net += Number(t.pnl_net_pct ?? 0);
      cur.avg_score += Number(t.signal_score ?? 0);
      if (t.exit_reason === "trailing") cur.trailing += 1;
      else if (t.exit_reason === "sl") cur.sl += 1;
      else if (t.exit_reason === "tp") cur.tp += 1;
      else cur.end += 1;
      byType.set(key, cur);
    }
    return Array.from(byType.entries()).map(([entry_type, v]) => ({
      entry_type,
      count: v.count,
      avg_net_pct: Number((v.avg_net / v.count).toFixed(4)),
      avg_score: Number((v.avg_score / v.count).toFixed(2)),
      sl_pct: Number((v.sl / v.count * 100).toFixed(1)),
      tp_pct: Number((v.tp / v.count * 100).toFixed(1)),
      end_pct: Number((v.end / v.count * 100).toFixed(1)),
      trailing_pct: Number((v.trailing / v.count * 100).toFixed(1)),
    })).sort((a, b) => b.count - a.count);
  };

  const scoreBuckets = [0, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 10];
  const bucketStats = scoreBuckets.slice(0, -1).map((start, idx) => {
    const end = scoreBuckets[idx + 1];
    const rows = trades.filter((t) => Number(t.signal_score ?? 0) >= start && Number(t.signal_score ?? 0) < end);
    const winRate = rows.length ? rows.filter((t) => t.pnl_net_pct > 0).length / rows.length * 100 : 0;
    const avgNet = rows.length ? rows.reduce((s, t) => s + Number(t.pnl_net_pct ?? 0), 0) / rows.length : 0;
    return { bucket: `${start}-${end}`, count: rows.length, win_rate_pct: Number(winRate.toFixed(1)), avg_net_pct: Number(avgNet.toFixed(4)) };
  }).filter((x) => x.count > 0);

  const output = {
    total_trades: trades.length,
    win_rate_pct: Number((wins.length / trades.length * 100).toFixed(2)),
    profit_factor: result.profit_factor,
    total_return_net: result.total_return_net,
    win_summary: summarize(wins),
    loss_summary: summarize(losses),
    score_buckets: bucketStats,
    sample_losses: losses.slice(0, 20),
  };
  console.log(JSON.stringify(output, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
