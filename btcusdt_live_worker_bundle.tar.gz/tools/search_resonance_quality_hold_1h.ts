import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

type Variant = {
  key: string;
  strategy: BacktestStrategy;
  pa_resonance_min_score: number;
  pa_resonance_require_momentum: boolean;
  pa_resonance_bias_window_bars: number;
  pa_resonance_max_hold_bars_15m: number;
};

type Row = {
  variant: string;
  min_score: number;
  require_momentum: boolean;
  bias_window_1h: number;
  max_hold_bars_15m: number;
  total_trades: number;
  win_rate_pct: number;
  profit_factor: number;
  total_return_net_pct: number;
  max_drawdown_pct: number;
  p75_stop_distance_pct: number;
  p75_margin_loss_50x_pct: number;
  used_15m_execution_trades: number;
  beats_baseline_pf: boolean;
  beats_baseline_winrate: boolean;
  beats_baseline_return: boolean;
  delta_win_rate_pct: number;
  delta_profit_factor: number;
  delta_total_trades: number;
  delta_return_net_pct: number;
  score: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const PAGE_LIMIT = 1000;
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");

const BASELINE_KEY = "baseline_quality40_momentum0_window2_hold192";
const BASELINE_WIN_RATE = 38.2;
const BASELINE_PF = 0.71;
const BASELINE_TRADES = 68;
const BASELINE_RETURN_NET = -18.77;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function normalizeBinanceRow(row: unknown[]): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Number(row[0]);
  const open = parseFloat(String(row[1]));
  const high = parseFloat(String(row[2]));
  const low = parseFloat(String(row[3]));
  const close = parseFloat(String(row[4]));
  const volume = parseFloat(String(row[5]));
  if (!isFinite(time) || !isFinite(open) || !isFinite(close)) return null;
  return { time, open, high, low, close, volume };
}

function isoTime(ts: number): string {
  return new Date(ts).toISOString().slice(0, 16);
}

async function fetchWithRetry(url: string, label: string, maxAttempts = 5): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Binance ${label} K線抓取失敗：HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`, interval);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function buildVariants(): Variant[] {
  const variants: Variant[] = [];
  const minScores = [40, 45, 50, 55];
  const momentumFlags = [false, true];
  const biasWindows = [1, 2, 3, 4];
  const holdBars15m = [16, 24, 32, 48, 96, 192];

  variants.push({
    key: BASELINE_KEY,
    strategy: "pa",
    pa_resonance_min_score: 40,
    pa_resonance_require_momentum: false,
    pa_resonance_bias_window_bars: 2,
    pa_resonance_max_hold_bars_15m: 192,
  });

  for (const minScore of minScores) {
    for (const momentum of momentumFlags) {
      for (const windowBars of biasWindows) {
        for (const holdBars of holdBars15m) {
          const key = `q${minScore}_mom${momentum ? 1 : 0}_w${windowBars}_hold${holdBars}`;
          if (key === BASELINE_KEY) continue;
          variants.push({
            key,
            strategy: "pa",
            pa_resonance_min_score: minScore,
            pa_resonance_require_momentum: momentum,
            pa_resonance_bias_window_bars: windowBars,
            pa_resonance_max_hold_bars_15m: holdBars,
          });
        }
      }
    }
  }

  return variants;
}

const VARIANTS = buildVariants();

function calcScore(row: Omit<Row, "score">): number {
  const pfReward = row.profit_factor * 40;
  const winReward = row.win_rate_pct * 1.2;
  const returnReward = Math.max(-30, row.total_return_net_pct) * 1.5;
  const tradeReward = Math.min(row.total_trades, 120) * 0.12;
  const ddPenalty = Math.max(0, row.max_drawdown_pct - 25) * 0.6;
  return round(pfReward + winReward + returnReward + tradeReward - ddPenalty, 2);
}

async function main() {
  console.log(`[run] resonance quality/hold refine 1h ${SYMBOL}`);
  console.log(`[fetch] 抓取 1H K 線...`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  console.log(`[fetch] 抓取 15m K 線...`);
  const candles15m = await fetchBinanceCandles(SYMBOL, "15m", 24 * 4 * YEAR_DAYS);
  console.log(`[fetch] 抓取 1D K 線...`);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] 1H ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);
  console.log(`[scan] variants=${VARIANTS.length}`);

  const rowsRaw: Array<Omit<Row, "beats_baseline_pf" | "beats_baseline_winrate" | "beats_baseline_return" | "delta_win_rate_pct" | "delta_profit_factor" | "delta_total_trades" | "delta_return_net_pct" | "score">> = [];

  for (const variant of VARIANTS) {
    const result = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: 1.95,
      atr_tp_mult: 0.21,
      enable_mtf_filter: true,
      enable_adx_filter: true,
      enable_trailing_stop: true,
      pa_allow_pattern: true,
      pa_allow_true_breakout: false,
      pa_allow_trap: true,
      pa_require_retest_on_continuation: false,
      pa_retest_soft_score: true,
      pa_retest_soft_bonus: 0.5,
      pa_retest_soft_min_score: 7.5,
      pa_retest_touch_tolerance_atr: 0.04,
      pa_retest_mode: "same_bar",
      pa_retest_require_candle_color: true,
      pa_retest_lookback_bars: 20,
      pa_retest_reclaim_offset_atr: 0.03,
      pa_dual_tf_resonance: true,
      pa_resonance_candles_15m: candles15m,
      pa_resonance_bias_window_bars: variant.pa_resonance_bias_window_bars,
      pa_resonance_min_score: variant.pa_resonance_min_score,
      pa_resonance_require_key_level: true,
      pa_resonance_require_momentum: variant.pa_resonance_require_momentum,
      pa_resonance_use_15m_sl: false,
      pa_resonance_max_hold_bars_15m: variant.pa_resonance_max_hold_bars_15m,
    });

    const stopDistances = result.trades.map((t) => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p75Stop = round(percentile(stopDistances, 0.75), 4);
    const p75MarginLoss50x = round(p75Stop * 50, 2);
    const used15mExecutionTrades = result.trades.filter((t) => t.used_15m_execution).length;

    const row = {
      variant: variant.key,
      min_score: variant.pa_resonance_min_score,
      require_momentum: variant.pa_resonance_require_momentum,
      bias_window_1h: variant.pa_resonance_bias_window_bars,
      max_hold_bars_15m: variant.pa_resonance_max_hold_bars_15m,
      total_trades: result.total_trades,
      win_rate_pct: round(result.win_rate * 100, 1),
      profit_factor: round(result.profit_factor, 2),
      total_return_net_pct: round(result.total_return_net * 100, 2),
      max_drawdown_pct: round(result.max_drawdown * 100, 2),
      p75_stop_distance_pct: p75Stop,
      p75_margin_loss_50x_pct: p75MarginLoss50x,
      used_15m_execution_trades: used15mExecutionTrades,
    };

    console.log(`[done] ${variant.key} trades=${row.total_trades} win=${row.win_rate_pct}% pf=${row.profit_factor} hold=${row.max_hold_bars_15m}`);
    rowsRaw.push(row);
  }

  const rows: Row[] = rowsRaw.map((row) => {
    const beats_baseline_pf = row.profit_factor > BASELINE_PF;
    const beats_baseline_winrate = row.win_rate_pct > BASELINE_WIN_RATE;
    const beats_baseline_return = row.total_return_net_pct > BASELINE_RETURN_NET;
    const delta_win_rate_pct = round(row.win_rate_pct - BASELINE_WIN_RATE, 1);
    const delta_profit_factor = round(row.profit_factor - BASELINE_PF, 2);
    const delta_total_trades = row.total_trades - BASELINE_TRADES;
    const delta_return_net_pct = round(row.total_return_net_pct - BASELINE_RETURN_NET, 2);
    const score = calcScore({
      ...row,
      beats_baseline_pf,
      beats_baseline_winrate,
      beats_baseline_return,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      delta_return_net_pct,
    });
    return {
      ...row,
      beats_baseline_pf,
      beats_baseline_winrate,
      beats_baseline_return,
      delta_win_rate_pct,
      delta_profit_factor,
      delta_total_trades,
      delta_return_net_pct,
      score,
    };
  });

  const sorted = [...rows].sort((a, b) => {
    const pfCmp = b.profit_factor - a.profit_factor;
    if (Math.abs(pfCmp) > 1e-9) return pfCmp;
    const wrCmp = b.win_rate_pct - a.win_rate_pct;
    if (Math.abs(wrCmp) > 1e-9) return wrCmp;
    const retCmp = b.total_return_net_pct - a.total_return_net_pct;
    if (Math.abs(retCmp) > 1e-9) return retCmp;
    return b.score - a.score;
  });

  const improved = sorted.filter((row) => row.beats_baseline_pf || row.beats_baseline_winrate || row.beats_baseline_return);
  const top20 = sorted.slice(0, 20);
  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `search_resonance_quality_hold_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `search_resonance_quality_hold_1h_${SYMBOL}_${ts}.md`);

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify({
    symbol: SYMBOL,
    baseline: {
      key: BASELINE_KEY,
      win_rate_pct: BASELINE_WIN_RATE,
      profit_factor: BASELINE_PF,
      trades: BASELINE_TRADES,
      total_return_net_pct: BASELINE_RETURN_NET,
    },
    total_variants: VARIANTS.length,
    improved_count: improved.length,
    rows: sorted,
  }, null, 2));

  const topTable = top20.map((row) =>
    `| ${row.variant} | ${row.total_trades} | ${row.win_rate_pct}% | ${row.profit_factor} | ${row.total_return_net_pct}% | ${row.bias_window_1h} | ${row.max_hold_bars_15m} | ${row.require_momentum ? "on" : "off"} | ${row.min_score} | ${row.delta_profit_factor >= 0 ? "+" : ""}${row.delta_profit_factor} | ${row.delta_win_rate_pct >= 0 ? "+" : ""}${row.delta_win_rate_pct} |`
  ).join("\n");

  const improvedLines = improved.length === 0
    ? "本輪未找到任何在 PF、勝率或淨收益上超過現行 15m 基線的候選。"
    : improved.slice(0, 10).map((row, idx) => `${idx + 1}. **${row.variant}**：PF ${row.profit_factor}、勝率 ${row.win_rate_pct}%、淨收益 ${row.total_return_net_pct}%、交易 ${row.total_trades}。`).join("\n");

  const best = sorted[0];
  const md = `# 15m 共振品質與持倉時間改良搜索報告

**幣種**：${SYMBOL}  
**策略**：PA（1H 偏見 + 15m 共振 + 真實 15m 執行）  
**搜索時間**：${new Date().toISOString()}  
**總變體數**：${VARIANTS.length}  
**改良候選數**：${improved.length}

## 一、對照基線

| 指標 | 數值 |
| --- | ---: |
| 基線變體 | ${BASELINE_KEY} |
| 年交易數 | ${BASELINE_TRADES} |
| 勝率 | ${BASELINE_WIN_RATE}% |
| PF | ${BASELINE_PF} |
| 淨收益 | ${BASELINE_RETURN_NET}% |

## 二、本輪搜索維度

| 維度 | 候選值 |
| --- | --- |
| \`pa_resonance_min_score\` | 40 / 45 / 50 / 55 |
| \`pa_resonance_require_momentum\` | false / true |
| \`pa_resonance_bias_window_bars\` | 1 / 2 / 3 / 4 |
| \`pa_resonance_max_hold_bars_15m\` | 16 / 24 / 32 / 48 / 96 / 192 |

## 三、Top 20 結果

| Variant | Trades | Win Rate | PF | Net Return | Window | Hold15m | Momentum | MinScore | ΔPF | ΔWin |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
${topTable}

## 四、優於基線的候選

${improvedLines}

## 五、結論

本輪最優候選為 **${best.variant}**，其結果為：年交易 **${best.total_trades}**、勝率 **${best.win_rate_pct}%**、PF **${best.profit_factor}**、淨收益 **${best.total_return_net_pct}%**。相對現行 15m 基線，其 PF 變化為 **${best.delta_profit_factor >= 0 ? "+" : ""}${best.delta_profit_factor}**，勝率變化為 **${best.delta_win_rate_pct >= 0 ? "+" : ""}${best.delta_win_rate_pct}**。

若最優候選主要來自 **縮短持倉時間**，則代表 15m 執行下的問題更偏向出場節奏而非信號品質；若主要來自 **提高 min_score 或啟用 momentum**，則代表 15m 共振的真正瓶頸在於信號質量控制。
`;

  await fs.writeFile(mdPath, md);
  console.log(`[done] JSON: ${jsonPath}`);
  console.log(`[done] MD:   ${mdPath}`);
  console.log(`[best] ${best.variant} trades=${best.total_trades} win=${best.win_rate_pct}% pf=${best.profit_factor}`);
}

main().catch((err) => {
  console.error("[fatal]", err);
  process.exit(1);
});
