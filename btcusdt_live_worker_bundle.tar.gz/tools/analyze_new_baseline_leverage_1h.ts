/**
 * analyze_new_baseline_leverage_1h.ts
 * 扶正後新主版本高槓桿風險評估
 *
 * 新主版本：PA / SL 1.95 / TP 0.21 / pattern_on / breakout_off / trap_on
 *           + 軟評分 bonus0.5 / minscore7.5 / touch0.04 / same_bar
 *
 * 對比：
 *   A. 舊主版本（retest_off，無軟評分）
 *   B. 新主版本（軟評分 bonus0.5 / minscore7.5）
 *   C. 硬性回踩（retest_on，作為參考）
 *
 * 作者：Manus AI
 */
import fs from "node:fs/promises";
import path from "node:path";
import { runBacktest, type BacktestStrategy } from "../server/backtest.ts";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type LeverageLevel = 20 | 30 | 50;

type Variant = {
  key: string;
  label: string;
  strategy: BacktestStrategy;
  atr_sl_mult: number;
  atr_tp_mult: number;
  enable_mtf_filter: boolean;
  enable_adx_filter: boolean;
  enable_trailing_stop: boolean;
  pa_allow_pattern: boolean;
  pa_allow_true_breakout: boolean;
  pa_allow_trap: boolean;
  pa_require_retest_on_continuation: boolean;
  pa_retest_soft_score: boolean;
  pa_retest_soft_bonus: number;
  pa_retest_soft_min_score: number;
  pa_retest_touch_tolerance_atr: number;
  pa_retest_mode: "same_bar" | "next_bar_confirm" | "either";
  pa_retest_require_candle_color: boolean;
  pa_retest_lookback_bars: number;
  pa_retest_reclaim_offset_atr: number;
};

const SYMBOL = (process.argv[2] ?? "BTCUSDT").replace("-", "").toUpperCase();
const YEAR_DAYS = 365;
const PAGE_LIMIT = 1000;
const BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines";
const OUT_DIR = path.resolve("/home/ubuntu/crypto-dashboard-v5.9/reports");
const MIN_TRADES = Math.ceil(YEAR_DAYS / 2);
const LEVERAGES: LeverageLevel[] = [20, 30, 50];

const VARIANTS: Variant[] = [
  {
    key: "old_baseline_retest_off",
    label: "舊主版本（retest_off，無軟評分）",
    strategy: "pa",
    atr_sl_mult: 1.95,
    atr_tp_mult: 0.21,
    enable_mtf_filter: true,
    enable_adx_filter: true,
    enable_trailing_stop: false,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: false,
    pa_retest_soft_score: false,
    pa_retest_soft_bonus: 0,
    pa_retest_soft_min_score: 0,
    pa_retest_touch_tolerance_atr: 0.08,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
    pa_retest_lookback_bars: 20,
    pa_retest_reclaim_offset_atr: 0.03,
  },
  {
    key: "new_baseline_soft_bonus0.5_minscore7.5",
    label: "新主版本（軟評分 bonus0.5 / minscore7.5 / touch0.04 / same_bar）",
    strategy: "pa",
    atr_sl_mult: 1.95,
    atr_tp_mult: 0.21,
    enable_mtf_filter: true,
    enable_adx_filter: true,
    enable_trailing_stop: false,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: false,
    pa_retest_soft_score: true,
    pa_retest_soft_bonus: 0.5,
    pa_retest_soft_min_score: 7.5,
    pa_retest_touch_tolerance_atr: 0.04,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
    pa_retest_lookback_bars: 20,
    pa_retest_reclaim_offset_atr: 0.03,
  },
  {
    key: "hard_retest_on_reference",
    label: "硬性回踩（retest_on，僅供參考）",
    strategy: "pa",
    atr_sl_mult: 1.95,
    atr_tp_mult: 0.21,
    enable_mtf_filter: true,
    enable_adx_filter: true,
    enable_trailing_stop: false,
    pa_allow_pattern: true,
    pa_allow_true_breakout: false,
    pa_allow_trap: true,
    pa_require_retest_on_continuation: true,
    pa_retest_soft_score: false,
    pa_retest_soft_bonus: 0,
    pa_retest_soft_min_score: 0,
    pa_retest_touch_tolerance_atr: 0.08,
    pa_retest_mode: "same_bar",
    pa_retest_require_candle_color: true,
    pa_retest_lookback_bars: 20,
    pa_retest_reclaim_offset_atr: 0.03,
  },
];

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function round(value: number, digits = 4): number {
  return Number(value.toFixed(digits));
}

function normalizeBinanceRow(row: unknown): Candle | null {
  if (!Array.isArray(row) || row.length < 6) return null;
  const time = Math.floor(Number(row[0]) / 1000);
  const open = Number(row[1]);
  const high = Number(row[2]);
  const low = Number(row[3]);
  const close = Number(row[4]);
  const volume = Number(row[5]);
  if (![time, open, high, low, close, volume].every(Number.isFinite)) return null;
  return { time, open, high, low, close, volume };
}

async function fetchWithRetry(url: string, retries = 3) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 CryptoDashboard/5.9" },
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res;
    } catch (error) {
      lastError = error;
      await sleep(500 * attempt);
    }
  }
  throw lastError;
}

async function fetchBinanceCandles(symbol: string, interval: string, targetCount: number): Promise<Candle[]> {
  const candles: Candle[] = [];
  let endTime = Date.now();
  while (candles.length < targetCount) {
    const params = new URLSearchParams({ symbol, interval, limit: String(PAGE_LIMIT), endTime: String(endTime) });
    const res = await fetchWithRetry(`${BINANCE_KLINES_URL}?${params.toString()}`);
    const payload = await res.json();
    if (!Array.isArray(payload) || payload.length === 0) break;
    const batch = payload
      .map((row) => normalizeBinanceRow(row))
      .filter((row): row is Candle => row !== null)
      .sort((a, b) => a.time - b.time);
    const earliest = candles.length > 0 ? candles[0].time : Number.POSITIVE_INFINITY;
    const unique = candles.length === 0 ? batch : batch.filter((c) => c.time < earliest);
    if (unique.length === 0) break;
    candles.unshift(...unique);
    endTime = Number(payload[0][0]) - 1;
    if (payload.length < PAGE_LIMIT) break;
    await sleep(120);
  }
  return candles.slice(-targetCount);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function maxConsecutiveLosses(pnls: number[]): number {
  let max = 0, cur = 0;
  for (const p of pnls) {
    if (p < 0) { cur++; max = Math.max(max, cur); } else cur = 0;
  }
  return max;
}

function isoTime(value: number | undefined): string {
  return value ? new Date(value * 1000).toISOString() : "";
}

async function main() {
  console.log(`[run] analyze new baseline leverage 1h ${SYMBOL}`);
  const candles1h = await fetchBinanceCandles(SYMBOL, "1h", 24 * YEAR_DAYS);
  const candles1d = await fetchBinanceCandles(SYMBOL, "1d", YEAR_DAYS);
  console.log(`[range] ${isoTime(candles1h[0]?.time)} -> ${isoTime(candles1h[candles1h.length - 1]?.time)}`);

  const results: Array<{
    key: string;
    label: string;
    total_trades: number;
    win_rate_pct: number;
    profit_factor: number;
    total_return_net_pct: number;
    max_drawdown_pct: number;
    p50_stop_pct: number;
    p75_stop_pct: number;
    p90_stop_pct: number;
    p95_stop_pct: number;
    worst_trade_pct: number;
    max_loss_streak: number;
    leverage_scenarios: Record<LeverageLevel, {
      p75_margin_loss_pct: number;
      p90_margin_loss_pct: number;
      p95_margin_loss_pct: number;
      worst_margin_loss_pct: number;
      rec_margin_frac_1pct_risk: number;
    }>;
  }> = [];

  for (const variant of VARIANTS) {
    const r = runBacktest({
      candles: candles1h,
      mtf_candles: candles1d,
      strategy: variant.strategy,
      symbol: SYMBOL,
      interval: "1h",
      atr_sl_mult: variant.atr_sl_mult,
      atr_tp_mult: variant.atr_tp_mult,
      enable_mtf_filter: variant.enable_mtf_filter,
      enable_fee: true,
      enable_trailing_stop: variant.enable_trailing_stop,
      enable_adx_filter: variant.enable_adx_filter,
      pa_allow_pattern: variant.pa_allow_pattern,
      pa_allow_true_breakout: variant.pa_allow_true_breakout,
      pa_allow_trap: variant.pa_allow_trap,
      pa_require_retest_on_continuation: variant.pa_require_retest_on_continuation,
      pa_retest_soft_score: variant.pa_retest_soft_score,
      pa_retest_soft_bonus: variant.pa_retest_soft_bonus,
      pa_retest_soft_min_score: variant.pa_retest_soft_min_score,
      pa_retest_touch_tolerance_atr: variant.pa_retest_touch_tolerance_atr,
      pa_retest_mode: variant.pa_retest_mode,
      pa_retest_require_candle_color: variant.pa_retest_require_candle_color,
      pa_retest_lookback_bars: variant.pa_retest_lookback_bars,
      pa_retest_reclaim_offset_atr: variant.pa_retest_reclaim_offset_atr,
    });

    const stopDistances = r.trades.map(t => Math.abs(t.entry_price - t.sl_price) / t.entry_price * 100);
    const p50 = round(percentile(stopDistances, 0.5), 4);
    const p75 = round(percentile(stopDistances, 0.75), 4);
    const p90 = round(percentile(stopDistances, 0.9), 4);
    const p95 = round(percentile(stopDistances, 0.95), 4);
    const worstTrade = round(Math.min(...r.trades.map(t => t.pnl_net_pct * 100), 0), 2);
    const maxLossStreak = maxConsecutiveLosses(r.trades.map(t => t.pnl_net_pct));

    const leverageScenarios: Record<LeverageLevel, {
      p75_margin_loss_pct: number;
      p90_margin_loss_pct: number;
      p95_margin_loss_pct: number;
      worst_margin_loss_pct: number;
      rec_margin_frac_1pct_risk: number;
    }> = {} as never;

    for (const lev of LEVERAGES) {
      leverageScenarios[lev] = {
        p75_margin_loss_pct: round(p75 * lev, 2),
        p90_margin_loss_pct: round(p90 * lev, 2),
        p95_margin_loss_pct: round(p95 * lev, 2),
        worst_margin_loss_pct: round(p95 * lev * 1.2, 2),
        rec_margin_frac_1pct_risk: p75 > 0 ? round(1 / (p75 / 100 * lev), 2) : 0,
      };
    }

    console.log(`[done] ${variant.key} trades=${r.total_trades} win=${round(r.win_rate * 100, 1)}% pf=${round(r.profit_factor, 2)} 50x_p75=${leverageScenarios[50].p75_margin_loss_pct}%`);

    results.push({
      key: variant.key,
      label: variant.label,
      total_trades: r.total_trades,
      win_rate_pct: round(r.win_rate * 100, 1),
      profit_factor: round(r.profit_factor, 2),
      total_return_net_pct: round(r.total_return_net * 100, 2),
      max_drawdown_pct: round(r.max_drawdown * 100, 2),
      p50_stop_pct: p50,
      p75_stop_pct: p75,
      p90_stop_pct: p90,
      p95_stop_pct: p95,
      worst_trade_pct: worstTrade,
      max_loss_streak: maxLossStreak,
      leverage_scenarios: leverageScenarios,
    });
  }

  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 23);
  const jsonPath = path.join(OUT_DIR, `analyze_new_baseline_leverage_1h_${SYMBOL}_${ts}.json`);
  const mdPath = path.join(OUT_DIR, `analyze_new_baseline_leverage_1h_${SYMBOL}_${ts}.md`);

  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(jsonPath, JSON.stringify({ symbol: SYMBOL, results }, null, 2));

  const newBaseline = results.find(r => r.key === "new_baseline_soft_bonus0.5_minscore7.5");
  const oldBaseline = results.find(r => r.key === "old_baseline_retest_off");

  const compTable = results.map(r => {
    const lev50 = r.leverage_scenarios[50];
    const lev30 = r.leverage_scenarios[30];
    return `| ${r.label} | ${r.total_trades} | ${r.win_rate_pct}% | ${r.profit_factor} | ${r.p75_stop_pct}% | ${lev30.p75_margin_loss_pct}% | ${lev50.p75_margin_loss_pct}% | ${lev50.rec_margin_frac_1pct_risk} |`;
  }).join("\n");

  const guardCheck = newBaseline ? [
    `- 核心頻率要求（年交易 ≥ ${MIN_TRADES}）：${newBaseline.total_trades >= MIN_TRADES ? "✅ 通過" : "❌ 未通過"}（${newBaseline.total_trades} 筆）`,
    `- PF > 1：${newBaseline.profit_factor > 1 ? "✅ 通過" : "❌ 未通過"}（${newBaseline.profit_factor}）`,
    `- 50x P75 保證金損耗 ≤ 82%：${newBaseline.leverage_scenarios[50].p75_margin_loss_pct <= 82 ? "✅ 通過" : "❌ 未通過"}（${newBaseline.leverage_scenarios[50].p75_margin_loss_pct}%）`,
    `- 50x P90 保證金損耗 ≤ 90%：${newBaseline.leverage_scenarios[50].p90_margin_loss_pct <= 90 ? "✅ 通過" : "❌ 未通過"}（${newBaseline.leverage_scenarios[50].p90_margin_loss_pct}%）`,
  ].join("\n") : "";

  const md = `# BTCUSDT 1H 新主版本高槓桿風險評估
作者：**Manus AI**

本報告對比舊主版本（retest_off）與扶正後新主版本（軟評分 bonus0.5 / minscore7.5 / touch0.04 / same_bar）在高槓桿場景下的風險特徵。

## 核心指標對比

| 版本 | 年交易數 | 勝率 | PF | P75 止損距離 | 30x P75 保證金損耗 | 50x P75 保證金損耗 | 50x 建議保證金比例（1%風險） |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
${compTable}

## 新主版本守門條件檢查

${guardCheck}

## 高槓桿風險詳細分析（新主版本）

${newBaseline ? `
| 槓桿倍數 | P75 保證金損耗 | P90 保證金損耗 | P95 保證金損耗 | 建議保證金比例（1%風險） |
| ---: | ---: | ---: | ---: | ---: |
| 20x | ${newBaseline.leverage_scenarios[20].p75_margin_loss_pct}% | ${newBaseline.leverage_scenarios[20].p90_margin_loss_pct}% | ${newBaseline.leverage_scenarios[20].p95_margin_loss_pct}% | ${newBaseline.leverage_scenarios[20].rec_margin_frac_1pct_risk} |
| 30x | ${newBaseline.leverage_scenarios[30].p75_margin_loss_pct}% | ${newBaseline.leverage_scenarios[30].p90_margin_loss_pct}% | ${newBaseline.leverage_scenarios[30].p95_margin_loss_pct}% | ${newBaseline.leverage_scenarios[30].rec_margin_frac_1pct_risk} |
| 50x | ${newBaseline.leverage_scenarios[50].p75_margin_loss_pct}% | ${newBaseline.leverage_scenarios[50].p90_margin_loss_pct}% | ${newBaseline.leverage_scenarios[50].p95_margin_loss_pct}% | ${newBaseline.leverage_scenarios[50].rec_margin_frac_1pct_risk} |

**止損距離分佈（新主版本）：**
- P50 止損距離：${newBaseline.p50_stop_pct}%
- P75 止損距離：${newBaseline.p75_stop_pct}%
- P90 止損距離：${newBaseline.p90_stop_pct}%
- P95 止損距離：${newBaseline.p95_stop_pct}%
- 最大連敗次數：${newBaseline.max_loss_streak} 次
- 最大回撤：${newBaseline.max_drawdown_pct}%
` : ""}

## 與舊主版本對比結論

${oldBaseline && newBaseline ? `
| 指標 | 舊主版本 | 新主版本 | 變化 |
| --- | ---: | ---: | ---: |
| 年交易數 | ${oldBaseline.total_trades} | ${newBaseline.total_trades} | ${newBaseline.total_trades - oldBaseline.total_trades >= 0 ? "+" : ""}${newBaseline.total_trades - oldBaseline.total_trades} |
| 勝率 | ${oldBaseline.win_rate_pct}% | ${newBaseline.win_rate_pct}% | ${newBaseline.win_rate_pct - oldBaseline.win_rate_pct >= 0 ? "+" : ""}${round(newBaseline.win_rate_pct - oldBaseline.win_rate_pct, 1)}% |
| PF | ${oldBaseline.profit_factor} | ${newBaseline.profit_factor} | ${round(newBaseline.profit_factor - oldBaseline.profit_factor, 2) >= 0 ? "+" : ""}${round(newBaseline.profit_factor - oldBaseline.profit_factor, 2)} |
| P75 止損距離 | ${oldBaseline.p75_stop_pct}% | ${newBaseline.p75_stop_pct}% | ${round(newBaseline.p75_stop_pct - oldBaseline.p75_stop_pct, 4) >= 0 ? "+" : ""}${round(newBaseline.p75_stop_pct - oldBaseline.p75_stop_pct, 4)}% |
| 50x P75 保證金損耗 | ${oldBaseline.leverage_scenarios[50].p75_margin_loss_pct}% | ${newBaseline.leverage_scenarios[50].p75_margin_loss_pct}% | ${round(newBaseline.leverage_scenarios[50].p75_margin_loss_pct - oldBaseline.leverage_scenarios[50].p75_margin_loss_pct, 2) >= 0 ? "+" : ""}${round(newBaseline.leverage_scenarios[50].p75_margin_loss_pct - oldBaseline.leverage_scenarios[50].p75_margin_loss_pct, 2)}% |
` : ""}

## 輸出文件

| 文件 | 路徑 |
| --- | --- |
| JSON | ${jsonPath} |
| Markdown | ${mdPath} |
`;

  await fs.writeFile(mdPath, md);
  console.log(`[saved] ${mdPath}`);
  console.log(`[saved] ${jsonPath}`);
}

main().catch((err) => {
  console.error("[error]", err);
  process.exit(1);
});
